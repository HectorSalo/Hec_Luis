package com.example.hchirinos.elmejorprecio.Variables;

import com.google.firebase.firestore.GeoPoint;

public class VariablesGenerales {
    public static String descripcionInfoProducto = null;
    public static String cantidadesInfoProducto = null;
    public static String vendedorInfoProducto = null;
    public static String imagenInfoProducto = null;
    public static String precioInfoProducto = null;
    public static String estadoInfoProducto = null;

    public static String idInfoVendedor = null;
    public static String nombreInfoVendedor = null;
    public static String telefonoInfoVendedor = null;
    public static String correoInfoVendedor = null;
    public static String imagenInfoVendedor = null;
    public static String ubicacionInfoVendedor = null;
    public static GeoPoint latlongInfoVendedor = null;

    public static boolean verProductos = true;
    public static boolean verResultadosBuscar = false;

    public static String textBuscar = null;

    public static String idChatVendedor = null;
    public static String nombreChatVendedor = null;
    public static String correoChatVendedor = null;
    public static String imagenChatVendedor = null;
}
