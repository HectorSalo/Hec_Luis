package com.example.proyectthefactoyhka.configuracion_realm_dataBase;

import android.app.Application;

import com.example.proyectthefactoyhka.modelo.ModelCliente;

import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelIdRuc;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMunicipios;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTeclado;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.facebook.stetho.Stetho;
import com.uphyca.stetho_realm.RealmInspectorModulesProvider;

import java.util.concurrent.atomic.AtomicInteger;

import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmObject;
import io.realm.RealmResults;

public class MyApplication extends Application{

    //metodo para auto incrementar las id de cada modelo
    public static AtomicInteger IdRuc = new AtomicInteger();
    public static AtomicInteger IdUsu = new AtomicInteger();
    public static AtomicInteger IdPro = new AtomicInteger();
    public static AtomicInteger IdCli = new AtomicInteger();
    public static AtomicInteger IdTeclado = new AtomicInteger();
    public static AtomicInteger IdTecl = new AtomicInteger();
    public static AtomicInteger IdImpr = new AtomicInteger();
    public static AtomicInteger IdUnidad = new AtomicInteger();
    public static AtomicInteger IdTasa = new AtomicInteger();
    public static AtomicInteger IdDocElec = new AtomicInteger();

    public static AtomicInteger IdMuni = new AtomicInteger();

    @Override
    public void onCreate() {
        setUpRealmConfig();

        Realm realm = Realm.getDefaultInstance();

        //metodo para obtener y configurar las tablas de cada modelo
        IdRuc = getIdByTable(realm, ModelIdRuc.class);
        IdUsu = getIdByTable(realm, ModelUsuario.class);
        IdPro = getIdByTable(realm, ModelProducto.class);
        IdCli = getIdByTable(realm, ModelCliente.class);
        IdTeclado =getIdByTable(realm, ModelTeclado.class);
        IdTecl = getIdByTable(realm,ModelTeclas.class);
        IdImpr = getIdByTable(realm,ModelImpresora.class);
        IdUnidad = getIdByTable(realm, ModelUnidad.class);
        IdTasa = getIdByTable(realm,ModelTasa.class);
   //     IdDocElec = getIdByTable(realm, ModelFacturasParseada.class);
    //    IdMuni  = getIdByTable(realm, ModelMunicipios.class);


        //codigo opcional unicamente implementado para poder visualizar la base de datos con sthetho realm
        //para que pueda iniciar es necesario borrar el   .deleteRealmIfMigrationNeeded() del setUpRealmConfig

        Stetho.initialize(
                Stetho.newInitializerBuilder(this)
                        .enableDumpapp(Stetho.defaultDumperPluginsProvider(this))
                        .enableWebKitInspector(RealmInspectorModulesProvider.builder(this).build())
                        .build());

        realm.close();
        super.onCreate();
    }


    //metodo configurar el realm por defecto
    private void setUpRealmConfig(){

        Realm.init(getApplicationContext());
        RealmConfiguration config = new RealmConfiguration.Builder()
        .deleteRealmIfMigrationNeeded()
        .build();
        Realm.setDefaultConfiguration(config);
    }



    //metodo singleton para obtener y configurar las tablas de cada modelo
    private <T extends RealmObject> AtomicInteger getIdByTable(Realm realm,Class<T> anyClass){
        RealmResults<T> results = realm.where(anyClass).findAll();
        return (results.size() >0)? new AtomicInteger(results.max("id").intValue()) : new AtomicInteger();

    }

}
