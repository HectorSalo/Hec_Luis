package com.example.proyectthefactoyhka.catalogo_producto.adaptadores;

import android.app.Activity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.catalogo_producto.comunicacion.Conexion_Producto;
import com.example.proyectthefactoyhka.herramienta.FormatoMiles;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;

import java.util.List;


public class ProductosAdapter extends RecyclerView.Adapter<ProductosAdapter.MiViewHolder> {


    private List<ModelProducto> producto;
    private List<ModelTasa> tasa;
    private int layout;
    private Activity activity;
    private Conexion_Producto conexion_producto;


    public ProductosAdapter(List<ModelProducto> producto, List<ModelTasa> tasa, int layout, Activity activity, Conexion_Producto conexion_producto ) {
        this.producto = producto;
        this.tasa =tasa;
        this.layout = layout;
        this.activity = activity;
        this.conexion_producto = conexion_producto;
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(producto.get(position));
    }

    @Override
    public int getItemCount() { return producto.size(); }


    public class MiViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener,MenuItem.OnMenuItemClickListener{

        private TextView descripcion;
        private TextView codigo;
        private TextView porc_impuesto;
        private TextView tipo_unidad;
        private TextView total;



        private MiViewHolder(View itemView) {
            super(itemView);

            descripcion = itemView.findViewById(R.id.card_descripcion);
            codigo =itemView.findViewById(R.id.card_codigo);
    //   porc_impuesto = itemView.findViewById(R.id.card_porci_imp);
           tipo_unidad = itemView.findViewById(R.id.card_tipoDeUnidad);
            total = itemView.findViewById(R.id.card_total);

            itemView.setOnCreateContextMenuListener(this);
        }

        private void bind(final ModelProducto producto){

           int igv = producto.getPosicionSpinnerIGV();
           double porIgv =producto.getPrecioUnitario1() * tasa.get(igv).getDecimaDelImpuesto();


           double monto =    producto.getPrecioUnitario1()+porIgv;



            descripcion.setText(producto.getDescripcion());
            codigo.setText("Codigo "+producto.getCodigo1());
           //  porc_impuesto.setText(tasa.get(igv).getPorcentajeDeImpuesto());
            tipo_unidad.setText(producto.getTipo_unidad());
            total.setText(FormatoMiles.getFormattedString(monto));

        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View v, ContextMenu.ContextMenuInfo menuInfo) {

            ModelProducto productoSeleccionado = producto.get(this.getAdapterPosition());


            contextMenu.setHeaderTitle("¿Que desea hacer con ?  "+productoSeleccionado.getDescripcion());

            MenuInflater inflater= activity.getMenuInflater();
            inflater.inflate(R.menu.menu_cardview_producto,contextMenu);

            for (int i =0; i<contextMenu.size();i++)
                contextMenu.getItem(i).setOnMenuItemClickListener(this);
        }


        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {


            switch (menuItem.getItemId()){

                case R.id.card_pro_generar_fat:

                    conexion_producto.generarFacturadeProducto(producto.get(getAdapterPosition()));

                    return true;

                case R.id.card_pro_ver_mas:

                   conexion_producto.detallesDelProducto(producto.get(getAdapterPosition()));

                    return true;

                case R.id.card_pro_editar:

                   conexion_producto.llamarVentanaEditarProducto(producto.get(getAdapterPosition()));

                    return true;

                case R.id.card_pro_borrar:

                    conexion_producto.borrarProducto(producto.get(getAdapterPosition()));

                    return true;

            }

            return false;
        }

    }







}

