package com.example.proyectthefactoyhka.ajustes.adaptador;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;

import java.util.ArrayList;


public class SettingListAdapter extends RecyclerView.Adapter<SettingListAdapter.PreferenceViewHolder> {


    private ArrayList<SettingListItem> mData;
    private View.OnClickListener listener;

    public SettingListAdapter(ArrayList<SettingListItem> preferences, View.OnClickListener listener) {
        this.mData = preferences;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PreferenceViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.layout_opcion,viewGroup,false);

        return new PreferenceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PreferenceViewHolder preferenceViewHolder, int i) {

        preferenceViewHolder.tvSettingTitle.setText(mData.get(i).getSettingTitle());
        preferenceViewHolder.tvSettingSubtitle.setText(mData.get(i).getSettingSubtitle());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class PreferenceViewHolder extends RecyclerView.ViewHolder {
        public TextView tvSettingTitle;
        public TextView tvSettingSubtitle;
        public PreferenceViewHolder(View v) {
            super(v);
            tvSettingTitle = v.findViewById(R.id.tv_preference_title);
            tvSettingSubtitle = v.findViewById(R.id.tv_preference_subtitle);
            v.setOnClickListener(listener);
            v.setTag(this);

        }
    }

}
