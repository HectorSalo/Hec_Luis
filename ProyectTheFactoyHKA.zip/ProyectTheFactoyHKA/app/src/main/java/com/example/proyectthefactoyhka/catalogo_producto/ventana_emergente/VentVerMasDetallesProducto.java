package com.example.proyectthefactoyhka.catalogo_producto.ventana_emergente;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;


public class VentVerMasDetallesProducto {

    private Dialog dialog;

    private TextView tv_vent_ver_mas_titulo,tv_vent_ver_mas_cod,tv_vent_ver_mas_uni,tv_vent_ver_mas_imp;


    public VentVerMasDetallesProducto(final Context context,String titulo,String codigo,String unidad,String impuesto) {



        configuracionDelaVentana(context);
        cast();

        tv_vent_ver_mas_titulo.setText(titulo);
        tv_vent_ver_mas_cod.setText(codigo);
        tv_vent_ver_mas_uni.setText(unidad);
        tv_vent_ver_mas_imp.setText(impuesto);

        dialog.show();

    }



    private void cast() {

        tv_vent_ver_mas_titulo = dialog.findViewById(R.id.tv_vent_ver_mas_titulo);
         tv_vent_ver_mas_cod = dialog.findViewById(R.id.tv_vent_ver_mas_cod);
         tv_vent_ver_mas_uni = dialog.findViewById(R.id.tv_vent_ver_mas_uni);
         tv_vent_ver_mas_imp = dialog.findViewById(R.id.tv_vent_ver_mas_imp);

    }

    //configuracion de la ventana para poder ser visualizada
    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_ver_mas_prod);

    }

}

