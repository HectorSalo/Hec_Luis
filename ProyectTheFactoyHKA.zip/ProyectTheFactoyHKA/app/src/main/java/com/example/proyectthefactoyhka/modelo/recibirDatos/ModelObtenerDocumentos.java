package com.example.proyectthefactoyhka.modelo.recibirDatos;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModelObtenerDocumentos {


    @SerializedName("documento")
    @Expose
    private List<ModelDocumento> documento;

    @SerializedName("mensaje")
    @Expose
    private String mensaje;


    public ModelObtenerDocumentos() {
    }


    public ModelObtenerDocumentos(List<ModelDocumento> documento) {
        this.documento = documento;
    }

    public List<ModelDocumento> getDocumento() {
        return documento;
    }


    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
