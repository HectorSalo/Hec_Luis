package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelPeticionDeProductos {

    @SerializedName("ruc")
    @Expose
    private String ruc;
    @SerializedName("serial")
    @Expose
    private String serial;
    @SerializedName("token")
    @Expose
    private String token;


    public ModelPeticionDeProductos(String ruc, String serial, String token) {
        this.ruc = ruc;
        this.serial = serial;
        this.token = token;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
