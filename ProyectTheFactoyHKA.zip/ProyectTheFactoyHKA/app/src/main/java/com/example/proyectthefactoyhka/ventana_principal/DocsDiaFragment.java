package com.example.proyectthefactoyhka.ventana_principal;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.proyectthefactoyhka.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;


public class DocsDiaFragment extends Fragment {

    private OnFragmentInteractionListener mListener;

    private BarChart barChartDia;

    public DocsDiaFragment() {
        // Required empty public constructor
    }


    public static DocsDiaFragment newInstance(String param1, String param2) {
        DocsDiaFragment fragment = new DocsDiaFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_docs_dia, container, false);

        barChartDia = view.findViewById(R.id.bargraphDia);

        cargarGraficoDia();
        // Inflate the layout for this fragment
        return view;
    }



    private void cargarGraficoDia() {
        ArrayList<String> horasDias = new ArrayList<>();
        horasDias.add(0, "00:00 - 03:59");
        horasDias.add(1, "04:00 - 07:59");
        horasDias.add(2, "08:00 - 11:59");
        horasDias.add(3, "12:00 - 15:59");
        horasDias.add(4, "16:00 - 19:59");
        horasDias.add(5, "20:00 - 23:59");


        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(0.0f, 12));
        barEntries.add(new BarEntry(1.0f, 0));
        barEntries.add(new BarEntry(2.0f, 88));
        barEntries.add(new BarEntry(3.0f, 8));
        barEntries.add(new BarEntry(4.0f, 36));
        barEntries.add(new BarEntry(5.0f, 15));


        barChartDia.animateY(3000);
        barChartDia.setDescription(null);

        BarDataSet barDataSet = new BarDataSet(barEntries, "Boletas y Facturas");

        BarData barData = new BarData(barDataSet);

        XAxis xAxis = barChartDia.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(horasDias));
        xAxis.setPosition(XAxis.XAxisPosition.TOP);
        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(315);

        barChartDia.setData(barData);
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
