package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.adaptador;

import android.app.Activity;
import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.conexion_factura.Conexion_factura;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;

import java.util.List;

public class FacturaAdaptador extends RecyclerView.Adapter<FacturaAdaptador.MiViewHolder> {

private List<ModelFacturacion> factura;
private int layout;
private Activity activity;
private Conexion_factura conexion_factura;
private MyItemClickfact itemClickFactura;
private boolean selecionado;

public FacturaAdaptador(List<ModelFacturacion> factura, int layout, Activity activity, Conexion_factura conexion_factura,boolean selecionado,MyItemClickfact itemClickFactura) {
        this.factura = factura;
        this.layout = layout;
        this.activity = activity;
        this.conexion_factura = conexion_factura;
        this.selecionado = selecionado;
        this.itemClickFactura = itemClickFactura;
        }

@Override
public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
        }

@Override
public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(factura.get(position),itemClickFactura);

        }

@Override
public int getItemCount() {
        return factura.size();
        }

class MiViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener{

    private TextView card_tv1_f_c_d;
    private TextView card_tv2_f_c_d;
    private CardView card_factura;


    MiViewHolder(View itemView) {
        super(itemView);

        card_tv1_f_c_d =itemView.findViewById(R.id.card_tv1_f_c_d);
        card_tv2_f_c_d = itemView.findViewById(R.id.card_tv2_f_c_d);
        card_factura =itemView.findViewById(R.id.card_factura);
        itemView.setOnCreateContextMenuListener(this);

    }

    void bind(final ModelFacturacion factura , final MyItemClickfact itemClickFactura){



        double valortotal = Double.parseDouble(factura.getPrecioVentaUnitarioItem())*Double.parseDouble(factura.getCantidad());



        card_tv1_f_c_d.setText(factura.getDescripcion());
        card_tv2_f_c_d.setText(valortotal+"");

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClickFactura.onItem(factura,getAdapterPosition());

                if (!selecionado){
                    card_factura.setCardBackgroundColor(ContextCompat.getColor(activity,R.color.colorgris));

                }else {
                    card_factura.setCardBackgroundColor(ContextCompat.getColor(activity,R.color.colorblanco));

                }
            }
        });


    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View v, ContextMenu.ContextMenuInfo menuInfo) {

        ModelFacturacion facturaSeleccionada = factura.get(this.getAdapterPosition());
        contextMenu.setHeaderTitle("¿Que desea hacer con ?  "+facturaSeleccionada.getDescripcion());

        MenuInflater inflater= activity.getMenuInflater();
        inflater.inflate(R.menu.menu_nota_y_factura,contextMenu);

        for (int i =0; i<contextMenu.size();i++)
            contextMenu.getItem(i).setOnMenuItemClickListener(this);

    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {

        switch (menuItem.getItemId()){

            case R.id.menu_nota_factura_porc:

                conexion_factura.funcionDePorcentaje(getAdapterPosition(),factura.get(getAdapterPosition()));

                break;

            case R.id.menu_nota_factura_eliminar:

                conexion_factura.borrarFactura(getAdapterPosition(),factura.get(getAdapterPosition()).getPrecioVentaUnitarioItem());

                break;

        }
        return false;
    }
}





public interface MyItemClickfact{
    void onItem(ModelFacturacion factura, int position);
}

}


