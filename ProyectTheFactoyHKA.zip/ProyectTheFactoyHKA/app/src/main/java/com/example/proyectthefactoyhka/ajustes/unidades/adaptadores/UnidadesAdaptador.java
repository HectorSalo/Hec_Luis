package com.example.proyectthefactoyhka.ajustes.unidades.adaptadores;

import android.app.Activity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;

import java.util.List;

public class UnidadesAdaptador extends RecyclerView.Adapter<UnidadesAdaptador.MiViewHolder>  {

    private List<ModelUnidad> unidad;
    private int layout;
    private Activity activity;
    private MyItemClickUnidad itemClickUnidad;



    public UnidadesAdaptador(List<ModelUnidad> unidad, int layout, Activity activity,MyItemClickUnidad itemClickUnidad) {
        this.unidad = unidad;
        this.layout = layout;
        this.activity = activity;
        this.itemClickUnidad = itemClickUnidad;
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);

        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(unidad.get(position),itemClickUnidad);



    }

    @Override
    public int getItemCount() { return unidad.size(); }


    public class MiViewHolder extends RecyclerView.ViewHolder {

        private CheckBox card_unidades_check;
        private TextView card_tv_unidades;


        public MiViewHolder(View itemView) {
            super(itemView);

            card_unidades_check = itemView.findViewById(R.id.card_unidades_check);
            card_tv_unidades = itemView.findViewById(R.id.card_tv_unidades);

        }

        public void bind(final ModelUnidad unidad,final MyItemClickUnidad itemClickUnidad) {

            card_unidades_check.setChecked(unidad.isCheck());
            card_tv_unidades.setText(unidad.getDescripcion());
            card_unidades_check.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    itemClickUnidad.onItem(unidad,getAdapterPosition());
                }
            });


        }


    }


    public interface MyItemClickUnidad{
        void onItem(ModelUnidad unidad, int position);

    }

}




