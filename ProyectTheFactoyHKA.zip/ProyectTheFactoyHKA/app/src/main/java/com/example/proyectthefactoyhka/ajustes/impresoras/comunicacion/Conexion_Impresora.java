package com.example.proyectthefactoyhka.ajustes.impresoras.comunicacion;

public interface Conexion_Impresora {

    void crear_impresora(String interfaz, String nombre, String direccion, String ancho_papel, String caracter_por_linea, String gaveta, String pagina_de_codigo, String tipo_de_qr, String logo);

    void activar_impresora(boolean activado,int posicion);


}
