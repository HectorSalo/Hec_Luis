package com.example.proyectthefactoyhka.modelo;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ModelCliente extends RealmObject implements Parcelable {


    @PrimaryKey
    private int id;
    @Expose
    @SerializedName("codigoPais")
    private String codigoPais;
    @Expose
    @SerializedName("departamento")
    private String correginmiento;
    @Expose
    private String distrito;
    @Expose
    @SerializedName("domicilioFiscal")
    private String direccion;
    @Expose
    @SerializedName("nombreComercial")
    private String nombre;
    @Expose
    @SerializedName("ruc")
    private String identificacion;
    @Expose
    private String tipoId;
    @Expose
    private String provincia;
    @Expose
    private String apellido;
    @Expose
    private String jurisdiccion;
    @Expose
    private String telefono;
    @Expose
    private String datoVerificador;
    @Expose
    private String correo;

    private String ubigeo;


    public ModelCliente() {
    }


    public ModelCliente(String codigoPais, String correginmiento, String distrito, String direccion, String nombre, String identificacion, String provincia, String ubigeo) {
        this.codigoPais = codigoPais;
        this.correginmiento = correginmiento;
        this.distrito = distrito;
        this.direccion = direccion;
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.provincia = provincia;
        this.ubigeo = ubigeo;
    }

//    public ModelCliente(String codigoPais, String correginmiento, String distrito, String direccion, String nombre, String apellido, String identificacion, String ubigeo) {
//        this.codigoPais = codigoPais;
//        this.correginmiento = correginmiento;
//        this.distrito = distrito;
//        this.direccion = direccion;
//        this.nombre = nombre;
//        this.apellido = apellido;
//        this.identificacion = identificacion;
//        this.ubigeo = ubigeo;
//    }


    public ModelCliente(String codigoPais, String correginmiento, String distrito,
                        String direccion, String nombre, String identificacion, String provincia,
                        String apellido, String jurisdiccion,String tipoId,String telefono,
                        String datoVerificador, String correo, String ubigeo) {

        this.id = MyApplication.IdCli.incrementAndGet();
        this.codigoPais = codigoPais;
        this.correginmiento = correginmiento;
        this.distrito = distrito;
        this.direccion = direccion;
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.provincia = provincia;
        this.apellido = apellido;
        this.jurisdiccion = jurisdiccion;
        this.tipoId = tipoId;
        this.telefono = telefono;
        this.datoVerificador = datoVerificador;
        this.correo = correo;
        this.ubigeo = ubigeo;
    }


    protected ModelCliente(Parcel in) {
        id = in.readInt();
        codigoPais = in.readString();
        correginmiento = in.readString();
        distrito = in.readString();
        direccion = in.readString();
        nombre = in.readString();
        identificacion = in.readString();
        tipoId = in.readString();
        provincia = in.readString();
        apellido = in.readString();
        jurisdiccion = in.readString();
        telefono = in.readString();
        datoVerificador = in.readString();
        correo = in.readString();
        ubigeo = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(codigoPais);
        dest.writeString(correginmiento);
        dest.writeString(distrito);
        dest.writeString(direccion);
        dest.writeString(nombre);
        dest.writeString(identificacion);
        dest.writeString(tipoId);
        dest.writeString(provincia);
        dest.writeString(apellido);
        dest.writeString(jurisdiccion);
        dest.writeString(telefono);
        dest.writeString(datoVerificador);
        dest.writeString(correo);
        dest.writeString(ubigeo);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelCliente> CREATOR = new Creator<ModelCliente>() {
        @Override
        public ModelCliente createFromParcel(Parcel in) {
            return new ModelCliente(in);
        }

        @Override
        public ModelCliente[] newArray(int size) {
            return new ModelCliente[size];
        }
    };

    public int getId() {
        return id;
    }


    public String getCodigoPais() {
        return codigoPais;
    }

    public void setCodigoPais(String codigoPais) {
        this.codigoPais = codigoPais;
    }

    public String getCorreginmiento() {
        return correginmiento;
    }

    public void setCorreginmiento(String correginmiento) {
        this.correginmiento = correginmiento;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getJurisdiccion() {
        return jurisdiccion;
    }

    public void setJurisdiccion(String jurisdiccion) {
        this.jurisdiccion = jurisdiccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDatoVerificador() {
        return datoVerificador;
    }

    public void setDatoVerificador(String datoVerificador) {
        this.datoVerificador = datoVerificador;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUbigeo() {
        return ubigeo;
    }

    public void setUbigeo(String ubigeo) {
        this.ubigeo = ubigeo;
    }

    public String getTipoId() {
        return tipoId;
    }

    public void setTipoId(String tipoId) {
        this.tipoId = tipoId;
    }
}
