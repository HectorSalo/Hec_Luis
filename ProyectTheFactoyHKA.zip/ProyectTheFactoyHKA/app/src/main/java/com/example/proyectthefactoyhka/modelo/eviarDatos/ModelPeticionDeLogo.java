package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelPeticionDeLogo {
    @SerializedName("clave")
    @Expose
    private String clave;
    @SerializedName("extension")
    @Expose
    private String extension;
    @SerializedName("logo")
    @Expose
    private String logo;
    @SerializedName("ruc")
    @Expose
    private String ruc;
    @SerializedName("usuario")
    @Expose
    private String usuario;

    public ModelPeticionDeLogo(String clave, String extension, String logo, String ruc, String usuario) {
        this.clave = clave;
        this.extension = extension;
        this.logo = logo;
        this.ruc = ruc;
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
