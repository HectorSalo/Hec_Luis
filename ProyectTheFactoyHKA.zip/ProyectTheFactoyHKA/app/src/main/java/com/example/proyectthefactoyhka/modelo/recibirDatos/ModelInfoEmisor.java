package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.google.gson.annotations.SerializedName;

public class ModelInfoEmisor {

    @SerializedName("ruc")
    private String ruc;

    @SerializedName("codigoPais")
    private String codigoPais;

    @SerializedName("departamento")
    private String departamento;

    @SerializedName("distrito")
    private String distrito;

    @SerializedName("domicilioFiscal")
    private String domicilioFiscal;

    @SerializedName("lugarExpedicion")
    private String lugarExpedicion;

    @SerializedName("nombreComercial")
    private String nombreComercial;

    @SerializedName("provincia")
    private String provincia;

    @SerializedName("razonSocial")
    private String razonSocial;

    @SerializedName("ubigeo")
    private String ubigeo;

    @SerializedName("urbanizacion")
    private String urbanizacion;

    public ModelInfoEmisor() {
    }

    public ModelInfoEmisor(String ruc, String codigoPais, String departamento, String distrito,
                           String domicilioFiscal, String lugarExpedicion, String nombreComercial,
                           String provincia, String razonSocial, String ubigeo, String urbanizacion) {
        this.ruc = ruc;
        this.codigoPais = codigoPais;
        this.departamento = departamento;
        this.distrito = distrito;
        this.domicilioFiscal = domicilioFiscal;
        this.lugarExpedicion = lugarExpedicion;
        this.nombreComercial = nombreComercial;
        this.provincia = provincia;
        this.razonSocial = razonSocial;
        this.ubigeo = ubigeo;
        this.urbanizacion = urbanizacion;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getCodigoPais() {
        return codigoPais;
    }

    public void setCodigoPais(String codigoPais) {
        this.codigoPais = codigoPais;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getDomicilioFiscal() {
        return domicilioFiscal;
    }

    public void setDomicilioFiscal(String domicilioFiscal) {
        this.domicilioFiscal = domicilioFiscal;
    }

    public String getLugarExpedicion() {
        return lugarExpedicion;
    }

    public void setLugarExpedicion(String lugarExpedicion) {
        this.lugarExpedicion = lugarExpedicion;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getUbigeo() {
        return ubigeo;
    }

    public void setUbigeo(String ubigeo) {
        this.ubigeo = ubigeo;
    }

    public String getUrbanizacion() {
        return urbanizacion;
    }

    public void setUrbanizacion(String urbanizacion) {
        this.urbanizacion = urbanizacion;
    }
}
