package com.example.proyectthefactoyhka.modelo.modelos_APP;

import io.realm.RealmObject;

public class ModelOpciones extends RealmObject {

    private String tipo_de_dispositivo;
    private boolean enviar_correo;
    private String sucursal;
    private String impuesto_por_defecto;
    private String codigo_boleta_de_venta;
    private String codigo_facturas;
    private String codigo_nota_credito;
    private String codigo_nota_debito;

    public ModelOpciones() {
    }

    public ModelOpciones(String tipo_de_dispositivo, boolean enviar_correo,
                         String sucursal, String impuesto_por_defecto, String codigo_boleta_de_venta,
                         String codigo_facturas, String codigo_nota_credito, String codigo_nota_debito) {
        this.tipo_de_dispositivo = tipo_de_dispositivo;
        this.enviar_correo = enviar_correo;
        this.sucursal = sucursal;
        this.impuesto_por_defecto = impuesto_por_defecto;
        this.codigo_boleta_de_venta = codigo_boleta_de_venta;
        this.codigo_facturas = codigo_facturas;
        this.codigo_nota_credito = codigo_nota_credito;
        this.codigo_nota_debito = codigo_nota_debito;
    }


    public String getTipo_de_dispositivo() {
        return tipo_de_dispositivo;
    }

    public void setTipo_de_dispositivo(String tipo_de_dispositivo) {
        this.tipo_de_dispositivo = tipo_de_dispositivo;
    }

    public boolean isEnviar_correo() {
        return enviar_correo;
    }

    public void setEnviar_correo(boolean enviar_correo) {
        this.enviar_correo = enviar_correo;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public String getImpuesto_por_defecto() {
        return impuesto_por_defecto;
    }

    public void setImpuesto_por_defecto(String impuesto_por_defecto) {
        this.impuesto_por_defecto = impuesto_por_defecto;
    }

    public String getCodigo_boleta_de_venta() {
        return codigo_boleta_de_venta;
    }

    public void setCodigo_boleta_de_venta(String codigo_boleta_de_venta) {
        this.codigo_boleta_de_venta = codigo_boleta_de_venta;
    }

    public String getCodigo_facturas() {
        return codigo_facturas;
    }

    public void setCodigo_facturas(String codigo_facturas) {
        this.codigo_facturas = codigo_facturas;
    }

    public String getCodigo_nota_credito() {
        return codigo_nota_credito;
    }

    public void setCodigo_nota_credito(String codigo_nota_credito) {
        this.codigo_nota_credito = codigo_nota_credito;
    }

    public String getCodigo_nota_debito() {
        return codigo_nota_debito;
    }

    public void setCodigo_nota_debito(String codigo_nota_debito) {
        this.codigo_nota_debito = codigo_nota_debito;
    }
}
