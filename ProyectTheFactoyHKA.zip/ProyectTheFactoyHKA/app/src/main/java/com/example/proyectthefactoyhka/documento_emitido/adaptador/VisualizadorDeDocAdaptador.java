package com.example.proyectthefactoyhka.documento_emitido.adaptador;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelVisDoc;

import java.util.List;

public class VisualizadorDeDocAdaptador extends RecyclerView.Adapter<VisualizadorDeDocAdaptador.MiViewHolder> {

    private List<ModelVisDoc> visDoc;
    private int layout;


    public VisualizadorDeDocAdaptador(List<ModelVisDoc> visDoc, int layout) {
        this.visDoc = visDoc;
        this.layout = layout;
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(visDoc.get(position));

    }

    @Override
    public int getItemCount() {
        return visDoc.size();
    }

    class MiViewHolder extends RecyclerView.ViewHolder {

        private TextView card_vis_doc_prod;
        private TextView card_vis_doc_total;
        private TextView card_vis_doc_canxventa;


        MiViewHolder(View itemView) {
            super(itemView);

            card_vis_doc_prod =itemView.findViewById(R.id.card_vis_doc_prod);
            card_vis_doc_total = itemView.findViewById(R.id.card_vis_doc_total);
            card_vis_doc_canxventa = itemView.findViewById(R.id.card_vis_doc_canxventa);



        }

        void bind(final ModelVisDoc visdoc ){

            card_vis_doc_prod.setText(visdoc.getProducto());
            card_vis_doc_total.setText(visdoc.getTotal());
            card_vis_doc_canxventa.setText(visdoc.getCantidad());



        }





    }







}
