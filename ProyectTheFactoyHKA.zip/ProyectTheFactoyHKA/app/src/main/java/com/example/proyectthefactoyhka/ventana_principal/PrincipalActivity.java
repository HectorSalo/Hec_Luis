package com.example.proyectthefactoyhka.ventana_principal;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.acerca_de.Acerca_de;
import com.example.proyectthefactoyhka.ajustes.Ajustes;
import com.example.proyectthefactoyhka.ajustes.unidades.activity.UnidadesMain;
import com.example.proyectthefactoyhka.catalogo_cliente.activity.ClientesMain;
import com.example.proyectthefactoyhka.catalogo_producto.activity.ProductosMain;
import com.example.proyectthefactoyhka.documento_emitido.activity.DocumentosMain;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity.Factura;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PrincipalActivity extends AppCompatActivity implements View.OnClickListener {

    private BottomNavigationView bottonbar;
    private int posicionUsuario;
    private LinearLayout nav_view_layout_catalogo, linearPuntos, layoutPrincipal;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private FrameLayout containerFragments;
    private DocumentosFragment documentosFragment;
    private ClientesFragment clientesFragment;
    private ProductosFragment productosFragment;
    private CuentasFragment cuentasFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager(), this);
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        linearPuntos = findViewById(R.id.linear_puntos);


        mostrarToolbar();
        cast();
        activarToogle();
        opcionesDeBotonesDelBarButtom();
        recibirDatosDeOtrosActivitys();
        insertarFecha();

        iniciarPuntosSlide(0);
        viewPager.addOnPageChangeListener(viewListener);

    }



    private void iniciarPuntosSlide(int pos) {
        TextView[] puntosSlide = new TextView[3];
        linearPuntos.removeAllViews();

        for (int i=0; i < puntosSlide.length; i++) {
            puntosSlide[i] = new TextView(this);
            puntosSlide[i].setText(Html.fromHtml("&#8226;"));
            puntosSlide[i].setTextSize(35);
            puntosSlide[i].setTextColor(getResources().getColor(R.color.colorAccent));
            linearPuntos.addView(puntosSlide[i]);
        }

        if (puntosSlide.length > 0) {
            puntosSlide[pos].setTextColor(getResources().getColor(R.color.md_blue_800));
        }
    }

    private ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            iniciarPuntosSlide(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    private String insertarFecha() {
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        return dateFormat.format(date);
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.bt_barra_principal_nuevo_doc:
                enviarDatos(Factura.class);
                break;

            case R.id.bt_barra_principal_doc:
                bottonbar.setSelectedItemId(R.id.btb_documentos);
                irFragments(documentosFragment);
                break;

            case R.id.bt_barra_principal_productos:
                bottonbar.setSelectedItemId(R.id.btb_productos);
                irFragments(productosFragment);
                break;

            case R.id.bt_barra_principal_cuenta:
                bottonbar.setSelectedItemId(R.id.btb_cuentas);
                irFragments(cuentasFragment);
                break;

            case R.id.bt_barra_principal_cli:
                bottonbar.setSelectedItemId(R.id.btb_clientes);
                irFragments(clientesFragment);
                break;

         // botones del navigation view

            case R.id.bt_nav_catalogo:

                if(nav_view_layout_catalogo.getVisibility()== View.GONE){
                    nav_view_layout_catalogo.setVisibility(View.VISIBLE);
                }else {
                    nav_view_layout_catalogo.setVisibility(View.GONE);
                }

                break;

            case R.id.bt_nav_unidades:

                enviarDatos(UnidadesMain.class);

                break;

            case R.id.bt_nav_ajustes:

                enviarDatos(Ajustes.class);

                break;

            case R.id.bt_nav_acerca_De:

                enviarDatos(Acerca_de.class);

                break;

            case R.id.bt_nav_cerrar_sesion:

                cerrarActividad();

                break;


        }
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente ubicados en la barra inferior de la app

    private void opcionesDeBotonesDelBarButtom() {



        bottonbar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.btb_home:
                        containerFragments.setVisibility(View.GONE);
                        bottonbar.setVisibility(View.GONE);
                        layoutPrincipal.setVisibility(View.VISIBLE);
                        break;
                    case R.id.btb_documentos:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragments, documentosFragment).commit();
                        break;

                    case R.id.btb_clientes:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragments, clientesFragment).commit();
                        break;

                    case R.id.btb_productos:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragments, productosFragment).commit();
                        break;

                    case R.id.btb_cuentas:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragments, cuentasFragment).commit();
                        break;
                }

                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void enviarDatos(Class clase) {

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START); }

        Intent enviar = new Intent(PrincipalActivity.this, clase);
        enviar.putExtra(getString(R.string.enviar_usuario), posicionUsuario);
        enviar.putExtra("tipoDocumento","03");
        startActivity(enviar);

    }

    private void irFragments(Fragment fragment) {
        containerFragments.setVisibility(View.VISIBLE);
        bottonbar.setVisibility(View.VISIBLE);
        layoutPrincipal.setVisibility(View.GONE);
        getSupportFragmentManager().beginTransaction().replace(R.id.container_fragments, fragment).commit();
    }


    private void recibirDatosDeOtrosActivitys() {
        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            posicionUsuario = extra.getInt(getString(R.string.enviar_usuario));
        }
    }



    //habilita boton para abrir/cerrar el drawer
    private void activarToogle(){
        ActionBarDrawerToggle toogle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toogle);
        toogle.syncState();
    }

    //metodo donde se castea todos los elementos que tendran interacion con el usuario

    private void cast() {

        layoutPrincipal = findViewById(R.id.layout_principal);

        containerFragments = findViewById(R.id.container_fragments);

        bottonbar = findViewById(R.id.bottonbar);

        //funciones del navigation view

        drawerLayout = findViewById(R.id.drawer_activity_principal);

        ImageView ivUsuario = findViewById(R.id.nav_view_imagen_usuario);
        Glide.with(this).load(R.drawable.ic_image_user).apply(RequestOptions.circleCropTransform()).into(ivUsuario);

        TextView tvUsuario = findViewById(R.id.nav_view_titulo_nombre_empres);
        tvUsuario.setText("The Factory HKA");
        TextView tvFolios = findViewById(R.id.nav_view_cantidad_folios);
        tvFolios.setText("4687");

        View bt_nav_catalogo = findViewById(R.id.bt_nav_catalogo);
        bt_nav_catalogo.setOnClickListener(this);

        nav_view_layout_catalogo = findViewById(R.id.nav_view_layout_catalogo);


        View bt_nav_unidades = findViewById(R.id.bt_nav_unidades);
        bt_nav_unidades.setOnClickListener(this);

        View bt_nav_ajustes = findViewById(R.id.bt_nav_ajustes);
        bt_nav_ajustes.setOnClickListener(this);

        View bt_nav_acerca_De = findViewById(R.id.bt_nav_acerca_De);
        bt_nav_acerca_De.setOnClickListener(this);

        View bt_nav_cerrar_sesion = findViewById(R.id.bt_nav_cerrar_sesion);
        bt_nav_cerrar_sesion.setOnClickListener(this);


        //--------------------------------------------------------------------------------------


        Button bt_barra_principal_nuevo_doc = findViewById(R.id.bt_barra_principal_nuevo_doc);
        bt_barra_principal_nuevo_doc.setOnClickListener(this);

        Button bt_barra_principal_doc = findViewById(R.id.bt_barra_principal_doc);
        bt_barra_principal_doc.setOnClickListener(this);

        Button bt_barra_principal_cli = findViewById(R.id.bt_barra_principal_cli);
        bt_barra_principal_cli.setOnClickListener(this);

        Button bt_barra_principal_pro = findViewById(R.id.bt_barra_principal_productos);
        bt_barra_principal_pro.setOnClickListener(this);

        Button bt_barra_principal_cuenta = findViewById(R.id.bt_barra_principal_cuenta);
        bt_barra_principal_cuenta.setOnClickListener(this);

        TextView ventana_principal_fecha = findViewById(R.id.ventana_principal_fecha);
        ventana_principal_fecha.setText(insertarFecha());


        documentosFragment = new DocumentosFragment();
        clientesFragment = new ClientesFragment();
        productosFragment = new ProductosFragment();
        cuentasFragment = new CuentasFragment();
    }

    //opciones del toolbar

    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbar_principal);

        setSupportActionBar(toolbar);
        PrincipalActivity.this.setTitle(R.string.toolbar_principal);
    }


    @Override
    public void onBackPressed() {


        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            if (layoutPrincipal.getVisibility() == View.VISIBLE) {
                cerrarActividad();
            } else {
                containerFragments.setVisibility(View.GONE);
                bottonbar.setVisibility(View.GONE);
                layoutPrincipal.setVisibility(View.VISIBLE);
            }

        }
    }


    private void cerrarActividad(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(PrincipalActivity.this);
        dialog.setTitle("Confirmar");
        dialog.setMessage("¿Desea cerrar sesión?");
        //dialog.setIcon(R.drawable.ic_advertencia);
        dialog.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();

            }
        });
        dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();


    }



}