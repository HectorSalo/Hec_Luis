package com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente;

import java.util.ArrayList;

public class ArrayDeSpinnerClientes {

    public static ArrayList<String> todosLosCorregimiento(){

        return new ArrayList<String>(){{
            add("Bastimientos");
            add("Bocas del toro (Cabecera)");
            add("Cauchero");
            add("Punta Laurel");
            add("Tierra Oscura");

        }};
    }


    public static ArrayList<String> todosLosDistritos(){

        return new ArrayList<String>(){{
            add("Bocas del Toro");
            add("Changuinola");
            add("Chiquiri Grande");
        }};
    }


    public static ArrayList<String> todasLasProvincias(){

        return new ArrayList<String>(){{
            add("Bocas del Toro");
            add("Chiriqui");
            add("Cocle");
            add("Colon");
            add("Comarca Embera-Wounaan");
            add("Comarca Kuna Yala");
            add("Comarca Ngabe-Bugle");
            add("Darien");
            add("Herrera");
            add("Los Santos");
            add("Panama");
            add("Panama Oeste");
            add("Veraguas");
        }};
    }

}
