package com.example.proyectthefactoyhka.ajustes.teclado.ventana_emergente;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.teclado.comunicacion.Conexion;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import yuku.ambilwarna.AmbilWarnaDialog;

public class VentModificarTeclas implements View.OnClickListener  ,AdapterView.OnItemSelectedListener {

    private Dialog dialog;
    private RealmList<ModelProducto> producto;

    private ModelTeclas tecla;
    private ModelUsuario usuarios;
    private Spinner spinner_modf_teclas;
    private List<String> lista;
    private String datoSpinner,codigo;
    private int colorPorDefecto;
    private Conexion conexion;
    private int idUsuario;



    public VentModificarTeclas(final Context context , Conexion conexion, int color ,  int  idPosicion) {

        configuracionDelaVentana(context);
        this.colorPorDefecto=color;
        this.conexion=conexion;
        this.idUsuario = idPosicion;
        cast();
        baseDeDatos();
        lista=new ArrayList<>();
        implemetarSpinnerArray(context, R.layout.support_simple_spinner_dropdown_item,lista);

        dialog.show();


    }



    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.bt_paleta_teclado:

                paletaDeColores();

                break;

            case R.id.bt_teclado_aceptar:

                try {

                    conexion.enviarDatos(datoSpinner,codigo,colorPorDefecto);

                }catch (Exception e)
                {
                    Log.w("errores",e);
                }

                dialog.dismiss();

                break;

            case R.id.bt_teclado_cancelar:
                dialog.dismiss();
                break;


        }
    }


    //dato que se obtendra el spinner
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()){

            case R.id.spinner_modf_teclas:
                datoSpinner=parent.getItemAtPosition(position).toString();
                codigo = producto.get(position).getCodigo1();
                break;


        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }




    private void baseDeDatos() {
        Realm realm = Realm.getDefaultInstance();

        usuarios = realm.where(ModelUsuario.class).equalTo("id",idUsuario).findFirst();
        if (usuarios!=null)
            producto = usuarios.getDatos_producto();

    }



    private void implemetarSpinnerArray(Context context,int tipoSpiner,List<String> dato) {

        for (int i =0;i<producto.size();i++) {

            ModelProducto listaProducto = usuarios.getDatos_producto().get(i);
            if (listaProducto != null) {
                lista.add(listaProducto.getDescripcion());

            }
        }

        ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<>(context, tipoSpiner, dato);
        spinner_modf_teclas.setAdapter(stringArrayAdapter);

    }




    private void cast() {
        spinner_modf_teclas = dialog.findViewById(R.id.spinner_modf_teclas);
        spinner_modf_teclas.setOnItemSelectedListener(this);

        Button bt_paleta_teclado = dialog.findViewById(R.id.bt_paleta_teclado);
        bt_paleta_teclado.setOnClickListener(this);

        Button bt_teclado_aceptar = dialog.findViewById(R.id.bt_teclado_aceptar);
        bt_teclado_aceptar.setOnClickListener(this);

        Button bt_teclado_cancelar = dialog.findViewById(R.id.bt_teclado_cancelar);
        bt_teclado_cancelar.setOnClickListener(this);

    }




    //esto se implenta gracias a la libreria com.github.yukuku:ambilwarna la cual llama una paleta de colores
    private void paletaDeColores(){

        AmbilWarnaDialog colorSeleccionado = new AmbilWarnaDialog(dialog.getContext(), colorPorDefecto, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {

                colorPorDefecto = color;



            }
        });

        colorSeleccionado.show();
    }







    private void configuracionDelaVentana(Context context) {
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_teclado);
    }









}
