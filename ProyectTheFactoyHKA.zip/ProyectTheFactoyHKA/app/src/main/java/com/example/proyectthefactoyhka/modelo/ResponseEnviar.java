package com.example.proyectthefactoyhka.modelo;

        import com.google.gson.annotations.Expose;
        import com.google.gson.annotations.SerializedName;

        public class ResponseEnviar {

            @SerializedName("codigo")
            @Expose
            private Integer codigo;
            @SerializedName("crc")
            @Expose
            private String crc;
            @SerializedName("estatus")
            @Expose
            private Boolean estatus;
            @SerializedName("hora")
            @Expose
            private String hora;
            @SerializedName("idtransaccion")
            @Expose
            private String idtransaccion;
            @SerializedName("mensaje")
            @Expose
            private String mensaje;
            @SerializedName("numeracion")
            @Expose
            private String numeracion;
            @SerializedName("xml")
            @Expose
            private String xml;




            public Integer getCodigo() {
                return codigo;
            }

            public void setCodigo(Integer codigo) {
                this.codigo = codigo;
            }

            public String getCrc() {
                return crc;
            }

            public void setCrc(String crc) {
                this.crc = crc;
            }

            public Boolean getEstatus() {
                return estatus;
            }

            public void setEstatus(Boolean estatus) {
                this.estatus = estatus;
            }

            public String getHora() {
                return hora;
            }

            public void setHora(String hora) {
                this.hora = hora;
            }

            public String getIdtransaccion() {
                return idtransaccion;
            }

            public void setIdtransaccion(String idtransaccion) {
                this.idtransaccion = idtransaccion;
            }

            public String getMensaje() {
                return mensaje;
            }

            public void setMensaje(String mensaje) {
                this.mensaje = mensaje;
            }

            public String getNumeracion() {
                return numeracion;
            }

            public void setNumeracion(String numeracion) {
                this.numeracion = numeracion;
            }

            public String getXml() {
                return xml;
            }

            public void setXml(String xml) {
                this.xml = xml;
            }

            @Override
            public String toString() {
                return "ResponseEnviar{" +
                        "codigo=" + codigo +
                        ", crc='" + crc + '\'' +
                        ", estatus=" + estatus +
                        ", hora='" + hora + '\'' +
                        ", idtransaccion='" + idtransaccion + '\'' +
                        ", mensaje='" + mensaje + '\'' +
                        ", numeracion='" + numeracion + '\'' +
                        ", xml='" + xml + '\'' +
                        '}';
            }
        }
