package com.example.proyectthefactoyhka.ventana_principal;

public class TestVariablesGenerales {

    public static int idUsuario;
}
