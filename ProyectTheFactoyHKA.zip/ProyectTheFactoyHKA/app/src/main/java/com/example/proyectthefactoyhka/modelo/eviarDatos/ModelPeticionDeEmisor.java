package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.SerializedName;

public class ModelPeticionDeEmisor {

    @SerializedName("ruc")
    private String ruc;

    @SerializedName("token")
    private String token;

    @SerializedName("serial")
    private String serial;


    public ModelPeticionDeEmisor(String ruc, String token, String serial) {
        this.ruc = ruc;
        this.token = token;
        this.serial = serial;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }
}
