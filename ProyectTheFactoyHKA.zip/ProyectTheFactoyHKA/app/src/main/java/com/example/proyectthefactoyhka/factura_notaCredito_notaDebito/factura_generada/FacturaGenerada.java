package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura_generada;

import android.content.Intent;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.documento_emitido.activity.DocumentosMain;
import com.example.proyectthefactoyhka.herramienta.ConexionInternet;
import com.example.proyectthefactoyhka.herramienta.Conexion_calendario;
import com.example.proyectthefactoyhka.herramienta.Ventana_calendario;
import com.example.proyectthefactoyhka.impresion.PrintService;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.ModelPago;
import com.example.proyectthefactoyhka.modelo.ModelReceptor;
import com.example.proyectthefactoyhka.modelo.ModelSubTotal;
import com.example.proyectthefactoyhka.modelo.ModelTotales;
import com.example.proyectthefactoyhka.modelo.RequestEnviar;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDescuentosGlobales;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ResponseEnviar;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMetodosDePago;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelOpciones;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelInfoEmisor;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class FacturaGenerada extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener, Conexion_calendario {

    private Realm realm;
    private RealmList<ModelCliente> listaclientes;
    private RealmList<ModelProducto> listaproductos;
    private TextView tv_fact_gen_subtotal, tv_fact_gen_totalfinal, edi_fact_gen_pago, tv_fact_gen_fecha;
    private LinearLayout layout_pago_mixto_plazo;
    private Spinner sp_tipo_de_pago, sp_forma_pago, sp_cantidad_pagos, sp_periodo_pagos;
    private String tipo_de_pago, forma_pago, cantidad_pagos, periodo_pagos;
    private RealmResults<ModelImpresora> impresoras;
    private ModelCliente cliente;
    private int posicionUsuario;
    private String  tipoDocumento;
    private ModelCliente clientereceptor;
    private Toolbar toolbar;
    private ModelUsuario usuarios;
    private ModelDocumentoElectronico documentoElectronico;
    private ModelOpciones opcionesFactura;

    private List<ModelFacturacion> datosProductos;
    private ProgressBar fact_gen_progressBar;
    private DatosTemporales datosTemporales;

    private Button bt_fact_generar_factura;
    private ModelTotales datosTotales;
    private RealmList<ModelFacturasParseada> listaDeFacturasParseada;
    private  ModelReceptor receptor;
    private ModelDescuentosGlobales descuentosGlobales;


    private ArrayList<String>listaDepagos;
    private ModelMetodosDePago modelmetodosDePagos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factura_generada);

        cast();
        implementarSpiner();
        recibirDatosDeOtrosActivitys();
        mostrarToolbar();
        datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));

    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo

    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", posicionUsuario).findFirst();
        if (usuarios != null) {
            listaclientes = usuarios.getDatos_clientes();
            listaproductos = usuarios.getDatos_producto();
            opcionesFactura = usuarios.getOpciones();
            listaDeFacturasParseada = usuarios.getLista_de_facturas();
            impresoras = realm.where(ModelImpresora.class).findAll();
        }
    }


    //metodo utilizado para agregar todos los datos tanto proveniente de otras actividades como de la base de datos local al metodo documento electronico

    private ModelDocumentoElectronico getDocumentoElectronico() {

        Date date = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        String serie = "";

        switch (tipoDocumento) {

            case "03":
                serie = opcionesFactura.getCodigo_boleta_de_venta();
                break;

            case "01":
                serie = opcionesFactura.getCodigo_facturas();
                break;

            case "07":
                serie = opcionesFactura.getCodigo_nota_credito();
                break;

            case "08":
                serie = opcionesFactura.getCodigo_nota_debito();
                break;
        }

        documentoElectronico = new ModelDocumentoElectronico("0101", dateFormat.format(date), dateFormat.format(date), serie, tipoDocumento);

        //agregamos los datos iniciales
        documentoElectronico.setFechaEmision(dateFormat.format(date));
        documentoElectronico.setHoraEmision(timeFormat.format(date));

        //----------------------------------------------------------------------------------------------------------------------
        //datos de emisor
        DatosTemporales  datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));

        ModelInfoEmisor emisor = datosTemporales.obtenerInfoEmisor();

        ModelCliente datosEmisor = new ModelCliente(emisor.getCodigoPais(),emisor.getDepartamento(),emisor.getDistrito(),emisor.getDomicilioFiscal(),emisor.getNombreComercial(),datosTemporales.odtenerRuc(),"LiMA",emisor.getUbigeo());

        documentoElectronico.setEmisor(datosEmisor);

        //----------------------------------------------------------------------------------------------------------------------
        //datos del receptor

            if(laFacturaEsUnaBoleta()){
                receptor = new ModelReceptor(clientereceptor.getIdentificacion(), clientereceptor.getNombre() + " " + clientereceptor.getApellido(), clientereceptor.getTipoId());
            }else {
                receptor = new ModelReceptor(clientereceptor.getIdentificacion(),clientereceptor.getNombre() + " " + clientereceptor.getApellido(),clientereceptor.getTipoId(),clientereceptor.getCorreo(),"NO");
            }
            documentoElectronico.setReceptor(receptor);

        //----------------------------------------------------------------------------------------------------------------------
        // datos del producto
        documentoElectronico.setProducto(datosProductos);

        //----------------------------------------------------------------------------------------------------------------------

        //Agregamos informacion de pago
        ModelPago pago = new ModelPago("009", "PEN");

        documentoElectronico.setPago(pago);

        //----------------------------------------------------------------------------------------------------------------------

        //agregamos informacion de totales de la factura
        ModelTotales totales = new ModelTotales(edi_fact_gen_pago.getText().toString(), datosTotales.getImporteTotalVenta(), datosTotales.getMontoTotalImpuestos(), datosTotales.getSubtotalValorVenta());
        ModelSubTotal subtotal = new ModelSubTotal(datosTotales.getSubtotalValorVenta());
        totales.setSubtotal(subtotal);
      //  totales.setTotalIGV("0.00");


        if (descuentosGlobales!=null){
            documentoElectronico.setDescuentosGlobales(descuentosGlobales);

        }

        documentoElectronico.setTotales(totales);


        return documentoElectronico;
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.bt_facura_generada_calendario:

                new Ventana_calendario(this, this);

                break;

            case R.id.bt_fact_generar_factura:

                if (!ConexionInternet.checkConnection(getApplicationContext())) {

                    Snackbar.make(findViewById(R.id.layout_facturagenerada), getString(R.string.sin_conexion), Snackbar.LENGTH_INDEFINITE).show();

                } else {
                    esperaDeDatos();

                    RequestEnviar requestEnviar = new RequestEnviar(usuarios.getClave(), datosTemporales.odtenerRuc(), usuarios.getUsuario());

                    requestEnviar.setDocumentoElectronico(getDocumentoElectronico());

                    servicioRetrofi2(requestEnviar);

                }

                break;
        }


    }



    private void finalizar(){
        Intent intent = getIntent();
        setResult(RESULT_OK,intent);
        this.finish();

    }

    private void enviarDatos(boolean estatus) {

        Intent enviar = new Intent(this, DocumentosMain.class);
        Bundle bundle = new Bundle();
        bundle.putInt(getString(R.string.enviar_usuario), posicionUsuario);
        bundle.putString("total", edi_fact_gen_pago.getText().toString());
        bundle.putBoolean("estatus", estatus);
        enviar.putExtra("factura", documentoElectronico);
        enviar.putExtras(bundle);
        startActivity(enviar);
    }

    private void guardarDatos(String id){
        Gson gson = new Gson();
        String documentoParseado = gson.toJson(documentoElectronico);
        realm.beginTransaction();
        ModelFacturasParseada ss = new ModelFacturasParseada(id,documentoParseado);
        listaDeFacturasParseada.add(ss);
        realm.copyToRealm(listaDeFacturasParseada);
        realm.commitTransaction();



    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(String mensaje) {
        Toast.makeText(FacturaGenerada.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    //metodo el cual efectuara las acciones de los spiners
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {

            case R.id.sp_tipo_de_pago:
                tipo_de_pago = parent.getItemAtPosition(position).toString();

                if (tipo_de_pago.equals("Pago Mixto") || tipo_de_pago.equals("Pago por plazos")) {

                    this.layout_pago_mixto_plazo.setVisibility(View.VISIBLE);

                } else {

                    this.layout_pago_mixto_plazo.setVisibility(View.GONE);

                }

                break;

            case R.id.sp_forma_pago:
                forma_pago = parent.getItemAtPosition(position).toString();


                break;

            case R.id.sp_cantidad_pagos:
                cantidad_pagos = parent.getItemAtPosition(position).toString();

                break;

            case R.id.sp_periodo_pagos:
                periodo_pagos = parent.getItemAtPosition(position).toString();

                break;
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    private void implementarSpiner() {
        adapterDelosSpiner(R.array.tipoDePago, sp_tipo_de_pago);
        adapterDelosSpiner(R.array.formaDePago, sp_forma_pago);
        adapterDelosSpiner(R.array.cantidadDePago, sp_cantidad_pagos);
        adapterDelosSpiner(R.array.periodoDeLosPago, sp_periodo_pagos);
    }


    //metodo singleton para los spinner
    private void adapterDelosSpiner(int array, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (this, array, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario

    private void cast() {

        tv_fact_gen_subtotal = findViewById(R.id.tv_fact_gen_subtotal);
        tv_fact_gen_totalfinal = findViewById(R.id.tv_fact_gen_totalfinal);
        edi_fact_gen_pago = findViewById(R.id.edi_fact_gen_pago);
        tv_fact_gen_fecha = findViewById(R.id.tv_fact_gen_fecha);

        Button bt_facura_generada_calendario = findViewById(R.id.bt_facura_generada_calendario);
        bt_facura_generada_calendario.setOnClickListener(this);

        bt_fact_generar_factura = findViewById(R.id.bt_fact_generar_factura);
        bt_fact_generar_factura.setOnClickListener(this);

        layout_pago_mixto_plazo = findViewById(R.id.layout_pago_mixto_plazo);

        sp_tipo_de_pago = findViewById(R.id.sp_tipo_de_pago);
        sp_tipo_de_pago.setOnItemSelectedListener(this);

        sp_forma_pago = findViewById(R.id.sp_forma_pago);
        sp_forma_pago.setOnItemSelectedListener(this);

        sp_cantidad_pagos = findViewById(R.id.sp_cantidad_pagos);
        sp_cantidad_pagos.setOnItemSelectedListener(this);

        sp_periodo_pagos = findViewById(R.id.sp_periodo_pagos);
        sp_periodo_pagos.setOnItemSelectedListener(this);

        fact_gen_progressBar = findViewById(R.id.fact_gen_progressBar);
        fact_gen_progressBar.setVisibility(View.GONE);

    }


    //metodo para mostrar u oculta el progress bar mientra se ejecuta alguna peticion de carga de datos
    private void esperaDeDatos() {

        if (fact_gen_progressBar.getVisibility() == View.GONE) {
            fact_gen_progressBar.setVisibility(View.VISIBLE);
            bt_fact_generar_factura.setEnabled(false);

        } else {
            fact_gen_progressBar.setVisibility(View.GONE);
            bt_fact_generar_factura.setEnabled(true);
        }
    }


    private void recibirDatosDeOtrosActivitys() {

        final Intent intent = getIntent();
        Bundle extra = intent.getExtras();
        if (extra != null) {
            //   String datostotal = extra.getString("datosTotal");

            datosProductos = intent.getParcelableArrayListExtra("factura");
            posicionUsuario = extra.getInt(getString(R.string.enviar_usuario));
            tipoDocumento = extra.getString("tipoDocumento");
            datosTotales = intent.getParcelableExtra("datosTotal");

            baseDeDatos();

            clientereceptor = intent.getParcelableExtra("datosCli");

             descuentosGlobales = intent.getParcelableExtra("descuentoglobal");




            //totaDeVentas = extra.getString("datosTotal");
            //totalImpuesto = extra.getString("montoTotalImpuesto");
            //subTotalDeVentas = extra.getString("subTotalDeVentas");

            tv_fact_gen_subtotal.setText(datosTotales.getSubtotalValorVenta());
            tv_fact_gen_totalfinal.setText(datosTotales.getImporteTotalVenta());
            edi_fact_gen_pago.setText(datosTotales.getImporteTotalVenta());
        }


    }

    //metodo el cual inicia servicio del retrofic este traera del servidor  todos los datos que se alojan en el servido
    private void servicioRetrofi2(RequestEnviar model) {

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);

        Call<ResponseEnviar> regUsuario = service.savePost(model);

        regUsuario.enqueue(new Callback<ResponseEnviar>() {

            ResponseEnviar datosFactura = new ResponseEnviar();

            @Override
            public void onResponse(Call<ResponseEnviar> call, Response<ResponseEnviar> response) {

                datosFactura = response.body();

                if (datosFactura != null)

                    if (datosFactura.getEstatus()) {
                        mostrarToast(datosFactura.getMensaje());
                        guardarDatos(datosFactura.getNumeracion());
//                        enviarDatos(datosFactura.getEstatus());
                        finalizar();

                    } else {
                        mostrarToast(datosFactura.getMensaje());
                    }
                esperaDeDatos();
            }

            @Override
            public void onFailure(Call<ResponseEnviar> call, Throwable t) {

                esperaDeDatos();
                Toast.makeText(FacturaGenerada.this, R.string.fallo_retroit, Toast.LENGTH_SHORT).show();
            }
        });


    }



    //Crea el Service Intent para la impresión de documentos
    private void iniciarServicioImpresion(String DatosDeimpresion){

        Intent intent = new Intent(getApplicationContext(), PrintService.class);
        intent.setAction(PrintService.ACTION_PRINT);
        intent.putExtra(PrintService.EXTRA_DOC, String.valueOf(getIntent().getParcelableExtra(DatosDeimpresion)));
        intent.putExtra(PrintService.EXTRA_PRINTERS,obtenerImpresoras());
        startService(intent);
    }


    //Crea una lista de impresoras del Arreglo Realm para poder ser enviada al servicio de impresión
    private ArrayList<ModelImpresora> obtenerImpresoras(){
        ArrayList<ModelImpresora> impresoras = new ArrayList<>();
        for(ModelImpresora impresora: this.impresoras){
            impresoras.add(new ModelImpresora(impresora));
        }
        return impresoras;
    }

    // metodo que recibe datos del Ventana_calendario ubicado en la carpeta herramientas ... y dichos datos son ubicados en el textview correspondiente a la fecha

    @Override
    public void datosDelCalendario(String dia, String mes, String year) {
        tv_fact_gen_fecha.setText(String.format("%s/%s/%s", dia, mes, year));
    }

    private boolean laFacturaEsUnaBoleta() {
        return tipoDocumento.equals("03");
    }



    //metodo que  configura el toolbar
    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbarfacturagenerada);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        FacturaGenerada.this.setTitle(R.string.toolbar_factura);
    }




    private void llenarSpinerDemetodosDePago(String item){



        listaDepagos = new ArrayList<String>() {
            {
                RealmResults<ModelMetodosDePago> metodosDePagos = realm.where(ModelMetodosDePago.class).equalTo("codigo_departamento", modelmetodosDePagos.getDescripcion()).findAll();
                if(metodosDePagos!=null){
                    for (int i =0; i<metodosDePagos.size(); i++){
                        add(metodosDePagos.get(i).getDescripcion());
                    }
                }
            }
        };


    }



}

