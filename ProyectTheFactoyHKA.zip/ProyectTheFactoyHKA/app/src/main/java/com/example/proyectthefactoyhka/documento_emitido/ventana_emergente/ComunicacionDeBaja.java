package com.example.proyectthefactoyhka.documento_emitido.ventana_emergente;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionComunicacionDeBaja;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerComunicacionDeBaja;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;

import io.realm.Realm;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;
import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class ComunicacionDeBaja extends DialogFragment implements View.OnClickListener , AdapterView.OnItemSelectedListener {

    private Spinner spinner_razon_de_baja;
    private Button bt_comunicacion_de_baja;
    private Realm realm;
    private ModelUsuario usuarios;
    private DatosTemporales datosTemporales;
    private int idUsuario;
    private ProgressBar progressBar;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_comunicacion_de_baja, container, false);
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);


        cast(view);
        recibirDatosDeOtrosActivitys();
        datosTemporales = DatosTemporales.getIntance(getDialog().getContext().getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));
        adapterDelosSpiner();

        return view;

    }



    private void baseDeDatos() {

        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
    }

    private void recibirDatosDeOtrosActivitys() {


        if (getArguments() != null) {
            idUsuario = getArguments().getInt(getString(R.string.enviar_usuario));




        }

        baseDeDatos();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.bt_comunicacion_de_baja:

                esperaDeDatos();
                servicioRetrofit2();

                break;


        }

    }
    private void cast(View view) {

        spinner_razon_de_baja = view.findViewById(R.id.spinner_razon_de_baja);
        spinner_razon_de_baja.setOnItemSelectedListener(this);

        bt_comunicacion_de_baja = view.findViewById(R.id.bt_comunicacion_de_baja);
        bt_comunicacion_de_baja.setOnClickListener(this);

        progressBar = view.findViewById(R.id.progressBar);

    }


    //metodo singleton para los spinner
    private void adapterDelosSpiner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (getDialog().getContext(), R.array.razones_baja, android.R.layout.simple_spinner_item);
        spinner_razon_de_baja.setAdapter(adapter);
    }





    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()){

            case R.id.spinner_razon_de_baja:



            break;


        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }



    private void servicioRetrofit2(){



        ModelPeticionComunicacionDeBaja peticionComunicacionDeBaja = new ModelPeticionComunicacionDeBaja(datosTemporales.obtenerUsuario().getClave(),getArguments().getString("documento"),"",datosTemporales.odtenerRuc(),datosTemporales.obtenerUsuario().getUsuario(),"0");

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelObtenerComunicacionDeBaja> obtenerPDF = service.peticionDeComunicacionDeBaja(peticionComunicacionDeBaja);
        obtenerPDF.enqueue(new Callback<ModelObtenerComunicacionDeBaja>() {

            ModelObtenerComunicacionDeBaja comunicacionDeBaja = new ModelObtenerComunicacionDeBaja();

            @Override
            public void onResponse(Call<ModelObtenerComunicacionDeBaja> call, Response<ModelObtenerComunicacionDeBaja> response) {



                comunicacionDeBaja= response.body();
                    if (comunicacionDeBaja.getCodigo()==0){

                        Toast.makeText(getDialog().getContext(), "codigo 0", Toast.LENGTH_SHORT).show();

                    }

                        Toast.makeText(getDialog().getContext(), comunicacionDeBaja.getMensaje(), Toast.LENGTH_SHORT).show();
                    esperaDeDatos();
            getDialog().dismiss();

            }



            @Override
            public void onFailure(Call<ModelObtenerComunicacionDeBaja> call, Throwable t) {
                Toast.makeText(getDialog().getContext(), getString(R.string.fallo_retroit), Toast.LENGTH_SHORT).show();
                esperaDeDatos();

            }
        });

    }



    private void esperaDeDatos() {

        if (progressBar.getVisibility() == View.GONE) {
            progressBar.setVisibility(View.VISIBLE);

        } else {

            progressBar.setVisibility(View.GONE);

        }

    }


}
