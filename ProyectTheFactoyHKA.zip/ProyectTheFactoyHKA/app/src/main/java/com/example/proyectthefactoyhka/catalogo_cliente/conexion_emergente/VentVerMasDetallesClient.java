package com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;


public class VentVerMasDetallesClient {

    private Dialog dialog;

    private TextView tv_vent_ver_cli_nomb,tv_vent_ver_cli_ape,tv_vent_ver_cli_tipo_per,tv_vent_ver_cli_telf,
            tv_vent_ver_cli_ident,tv_vent_ver_cli_datoVer,tv_vent_ver_cli_correo,tv_vent_ver_cli_ubicacion,tv_vent_ver_cli_direccion,tv_vent_ver_cli_contribuyente;

    public VentVerMasDetallesClient(final Context context,String nombre,String apellido,String jurisdiccion,String telefono,String identificacion,String datoVerificador
    ,String correo ,String pais,String provincia, String distrito,String correginmiento,String direccion,String contribuyente){

        configuracionDelaVentana(context);



        cast();

        tv_vent_ver_cli_nomb.setText(nombre);
        tv_vent_ver_cli_ape.setText(apellido);
        tv_vent_ver_cli_tipo_per.setText(jurisdiccion);
        tv_vent_ver_cli_telf.setText(telefono);
        tv_vent_ver_cli_ident.setText(identificacion);
        tv_vent_ver_cli_datoVer.setText(datoVerificador);
        tv_vent_ver_cli_correo.setText(correo);
        tv_vent_ver_cli_ubicacion.setText(String.format("%s/%s/%s/%s", pais, provincia, distrito, correginmiento));
        tv_vent_ver_cli_direccion.setText(direccion);
        tv_vent_ver_cli_contribuyente.setText(contribuyente);
        dialog.show();


    }

    private void cast() {

        tv_vent_ver_cli_nomb=dialog.findViewById(R.id.tv_vent_ver_cli_nomb);
        tv_vent_ver_cli_ape=dialog.findViewById(R.id.tv_vent_ver_cli_ape);
        tv_vent_ver_cli_tipo_per=dialog.findViewById(R.id.tv_vent_ver_cli_tipo_per);
        tv_vent_ver_cli_telf=dialog.findViewById(R.id.tv_vent_ver_cli_telf);
        tv_vent_ver_cli_ident=dialog.findViewById(R.id.tv_vent_ver_cli_ident);
        tv_vent_ver_cli_datoVer=dialog.findViewById(R.id.tv_vent_ver_cli_datoVer);
        tv_vent_ver_cli_correo=dialog.findViewById(R.id.tv_vent_ver_cli_correo);
        tv_vent_ver_cli_ubicacion=dialog.findViewById(R.id.tv_vent_ver_cli_ubicacion);
        tv_vent_ver_cli_direccion=dialog.findViewById(R.id.tv_vent_ver_cli_direccion);
        tv_vent_ver_cli_contribuyente=dialog.findViewById(R.id.tv_vent_ver_cli_contribuyente);


    }


    //configuracion de la ventana para poder ser visualizada
    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_ver_mas_client);

    }

}


