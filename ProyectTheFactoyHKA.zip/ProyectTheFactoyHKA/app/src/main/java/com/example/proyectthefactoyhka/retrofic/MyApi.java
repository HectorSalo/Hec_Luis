package com.example.proyectthefactoyhka.retrofic;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyApi {

    private static final String BASE_URL = "http://testint.thefactoryhka.com.pe/";
    private static Retrofit retrofit = null;
    private static MyApi instacia;


    private MyApi (){
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient.Builder httpClientBuilder = new OkHttpClient.Builder().addInterceptor(loggingInterceptor);
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(httpClientBuilder.build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

    }



    public  static synchronized  MyApi getInstacia(){
        if (instacia == null){
            instacia = new MyApi();
        }

        return instacia;

    }


    public <S> S crearServicio(Class<S> ServiciosGenericos){

        return  retrofit.create(ServiciosGenericos);
    }

}
