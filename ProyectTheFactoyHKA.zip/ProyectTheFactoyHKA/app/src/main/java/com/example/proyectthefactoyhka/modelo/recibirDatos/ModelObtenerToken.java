package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelObtenerToken {

    @SerializedName("fechaExpiracion")
    @Expose
    private String fechaExpiracion;

    @SerializedName("mensaje")
    @Expose
    private String mensaje;

    @SerializedName("token")
    @Expose
    private String token;



    public ModelObtenerToken() {
    }


    public String getFechaExpiracion() {
        return fechaExpiracion;
    }

    public void setFechaExpiracion(String fechaExpiracion) {
        this.fechaExpiracion = fechaExpiracion;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
