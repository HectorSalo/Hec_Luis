package com.example.proyectthefactoyhka.configuracion_realm_dataBase;

import android.content.res.Resources;
import android.util.Log;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelCiudades;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelDepartamentos;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMetodosDePago;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMunicipios;

import java.io.InputStream;

import io.realm.Realm;

/**
 * From json to realm database
 */
public class RealmImporter {

    public static void importFromJson(final Resources resources) {
        Realm realm = Realm.getDefaultInstance();

        //transaction timer
        final TransactionTime transactionTime = new TransactionTime(System.currentTimeMillis());

        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                InputStream inputStream = resources.openRawResource(R.raw.departamentos);
                InputStream inputStream2 = resources.openRawResource(R.raw.municipios);
                InputStream inputStream3 = resources.openRawResource(R.raw.ciudades);
                InputStream inputStream4 = resources.openRawResource(R.raw.metodosdepago);


                try {

                    realm.createAllFromJson(ModelDepartamentos.class, inputStream);
                    transactionTime.setEnd(System.currentTimeMillis());

                    realm.createAllFromJson(ModelMunicipios.class, inputStream2);
                    transactionTime.setEnd(System.currentTimeMillis());

                    realm.createAllFromJson(ModelCiudades.class, inputStream3);
                    transactionTime.setEnd(System.currentTimeMillis());

                    realm.createAllFromJson(ModelMetodosDePago.class, inputStream4);
                    transactionTime.setEnd(System.currentTimeMillis());

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    realm.close();
                }
            }
        });
        Log.d("Realm", "createAllFromJson Task completed in " + transactionTime.getDuration() + "ms");
    }
}
