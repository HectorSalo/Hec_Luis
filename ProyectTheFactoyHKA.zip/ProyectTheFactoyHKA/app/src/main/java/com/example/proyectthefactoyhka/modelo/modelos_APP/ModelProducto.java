package com.example.proyectthefactoyhka.modelo.modelos_APP;


import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import io.realm.RealmObject;
import io.realm.annotations.Ignore;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class ModelProducto extends RealmObject implements Serializable {

    @PrimaryKey
    private int id;

    private String tipo_producto;

    @SerializedName("codigo1")
    private String codigo1;

    @SerializedName("codigo2")
    private String codigo2;

    @Ignore
    private String codigo3;

    @SerializedName("descripcion")
    private String descripcion;

    @SerializedName("precio1")
    private double precioUnitario1;

    @SerializedName("precio2")
    private double precioUnitario2;

    @SerializedName("unidad")
    private String tipo_unidad;

    private int posicionSpinnerIGV;

    private String cantidadDePorcISC;


    public ModelProducto() {
    }


    public ModelProducto( String tipo_producto, String codigo1, String codigo2, String descripcion, double precioUnitario1, String tipo_unidad, int posicionSpinnerIGV, String cantidadDePorcISC) {
        this.id = MyApplication.IdPro.incrementAndGet();
        this.tipo_producto = tipo_producto;
        this.codigo1 = codigo1;
        this.codigo2 = codigo2;
        this.descripcion = descripcion;
        this.precioUnitario1 = precioUnitario1;
        this.tipo_unidad = tipo_unidad;
        this.posicionSpinnerIGV = posicionSpinnerIGV;
        this.cantidadDePorcISC = cantidadDePorcISC;
    }

    public ModelProducto(String tipo_producto, String codigo1, String codigo2, String codigo3,
                         String descripcion, double precioUnitario1, double precioUnitario2, String tipo_unidad,
                         int posicionSpinnerIGV, String cantidadDePorcISC) {
        this.id = MyApplication.IdPro.getAndIncrement();
        this.tipo_producto = tipo_producto;
        this.codigo1 = codigo1;
        this.codigo2 = codigo2;
        this.codigo3 = codigo3;
        this.descripcion = descripcion;
        this.precioUnitario1 = precioUnitario1;
        this.precioUnitario2 = precioUnitario2;
        this.tipo_unidad = tipo_unidad;
        this.posicionSpinnerIGV = posicionSpinnerIGV;
        this.cantidadDePorcISC = cantidadDePorcISC;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo_producto() {
        return tipo_producto;
    }

    public void setTipo_producto(String tipo_producto) {
        this.tipo_producto = tipo_producto;
    }

    public String getCodigo1() {
        return codigo1;
    }

    public void setCodigo1(String codigo1) {
        this.codigo1 = codigo1;
    }

    public String getCodigo2() {
        return codigo2;
    }

    public void setCodigo2(String codigo2) {
        this.codigo2 = codigo2;
    }

    public String getCodigo3() {
        return codigo3;
    }

    public void setCodigo3(String codigo3) {
        this.codigo3 = codigo3;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioUnitario1() {
        return precioUnitario1;
    }

    public void setPrecioUnitario1(double precioUnitario1) {
        this.precioUnitario1 = precioUnitario1;
    }

    public double getPrecioUnitario2() {
        return precioUnitario2;
    }

    public void setPrecioUnitario2(double precioUnitario2) {
        this.precioUnitario2 = precioUnitario2;
    }

    public String getTipo_unidad() {
        return tipo_unidad;
    }

    public void setTipo_unidad(String tipo_unidad) {
        this.tipo_unidad = tipo_unidad;
    }

    public int getPosicionSpinnerIGV() {
        return posicionSpinnerIGV;
    }

    public void setPosicionSpinnerIGV(int posicionSpinnerIGV) {
        this.posicionSpinnerIGV = posicionSpinnerIGV;
    }

    public String getCantidadDePorcISC() {
        return cantidadDePorcISC;
    }

    public void setCantidadDePorcISC(String cantidadDePorcISC) {
        this.cantidadDePorcISC = cantidadDePorcISC;
    }
}
