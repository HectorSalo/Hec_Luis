package com.example.proyectthefactoyhka.retrofic;


import com.example.proyectthefactoyhka.modelo.RequestEnviar;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelAutentificar;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionComunicacionDeBaja;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeClientes;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeDocumentos;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeEmisor;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeLogo;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDePDF;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeProductos;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ResponseEnviar;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelRecibirListaProductos;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerComunicacionDeBaja;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerDocumentos;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerEmisor;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerListaDeClientes;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerLogo;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerPDF;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerToken;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface WebServiceApi {

        @POST("/ApiRest/Service.svc/Enviar")
        Call<ResponseEnviar> savePost(@Body RequestEnviar requestEnviar);

        @POST("/ApiRest/Service.svc/Autenticacion")
        Call<ModelObtenerToken> hacerLlamada(@Body ModelAutentificar user);

        @POST("/ApiRest/Service.svc/ListadoDocumentos")
        Call<ModelObtenerDocumentos> peticionDocumentos(@Body ModelPeticionDeDocumentos doc);

        @POST("/ApiRest/Service.svc/ListadoProductos")
        Call<ModelRecibirListaProductos> peticionProducto(@Body ModelPeticionDeProductos producto);

        @POST("/ApiRest/Service.svc/InfoEmisor")
        Call<ModelObtenerEmisor> peticionDeEmisor(@Body ModelPeticionDeEmisor emisor);

        @POST("/ApiRest/Service.svc/DescargaArchivo")
        Call<ModelObtenerPDF> peticionDePDF(@Body ModelPeticionDePDF request);

        @POST("/ApiRest/Service.svc/ComunicacionBaja")
        Call<ModelObtenerComunicacionDeBaja> peticionDeComunicacionDeBaja(@Body ModelPeticionComunicacionDeBaja comunicacionDeBaja);

        @POST("/ApiRest/Service.svc/Logo")
        Call<ModelObtenerLogo> peticionDeLogo(@Body ModelPeticionDeLogo logo);

        @POST("/ApiRest/Service.svc/ListadoClientes)")
        Call<ModelObtenerListaDeClientes> peticionDeClientes(@Body ModelPeticionDeClientes request);



}
