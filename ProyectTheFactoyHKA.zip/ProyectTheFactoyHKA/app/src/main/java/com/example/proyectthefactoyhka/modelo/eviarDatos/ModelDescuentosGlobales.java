package com.example.proyectthefactoyhka.modelo.eviarDatos;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelDescuentosGlobales implements Parcelable {

    private String baseImponible;
    private String monto;
    private String motivo;
    private String porcentaje;

    public ModelDescuentosGlobales(String baseImponible, String monto, String motivo, String porcentaje) {
        this.baseImponible = baseImponible;
        this.monto = monto;
        this.motivo = motivo;
        this.porcentaje = porcentaje;
    }

    protected ModelDescuentosGlobales(Parcel in) {
        baseImponible = in.readString();
        monto = in.readString();
        motivo = in.readString();
        porcentaje = in.readString();
    }

    public static final Creator<ModelDescuentosGlobales> CREATOR = new Creator<ModelDescuentosGlobales>() {
        @Override
        public ModelDescuentosGlobales createFromParcel(Parcel in) {
            return new ModelDescuentosGlobales(in);
        }

        @Override
        public ModelDescuentosGlobales[] newArray(int size) {
            return new ModelDescuentosGlobales[size];
        }
    };

    public String getBaseImponible() {
        return baseImponible;
    }

    public void setBaseImponible(String baseImponible) {
        this.baseImponible = baseImponible;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(String porcentaje) {
        this.porcentaje = porcentaje;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(baseImponible);
        dest.writeString(monto);
        dest.writeString(motivo);
        dest.writeString(porcentaje);
    }
}
