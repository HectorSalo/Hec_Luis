package com.example.proyectthefactoyhka.modelo.modelos_APP;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import io.realm.RealmObject;

public class ModelFacturasParseada extends RealmObject implements Parcelable {

    private String id;
    private String factura ;

    public ModelFacturasParseada() {
    }

    public ModelFacturasParseada(String id ,String factura) {
        this.id= id;
        this.factura = factura;
    }

    protected ModelFacturasParseada(Parcel in) {
        id = in.readString();
        factura = in.readString();
    }

    public static final Creator<ModelFacturasParseada> CREATOR = new Creator<ModelFacturasParseada>() {
        @Override
        public ModelFacturasParseada createFromParcel(Parcel in) {
            return new ModelFacturasParseada(in);
        }

        @Override
        public ModelFacturasParseada[] newArray(int size) {
            return new ModelFacturasParseada[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFactura() {
        return factura;
    }

    public void setFactura(String factura) {
        this.factura = factura;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(factura);
    }
}
