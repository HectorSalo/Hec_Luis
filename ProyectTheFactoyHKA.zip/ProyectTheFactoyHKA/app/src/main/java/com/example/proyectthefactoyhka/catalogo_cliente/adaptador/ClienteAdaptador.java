package com.example.proyectthefactoyhka.catalogo_cliente.adaptador;

import android.app.Activity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion.Conexion_Cliente;
import com.example.proyectthefactoyhka.modelo.ModelCliente;

import java.util.List;


public class ClienteAdaptador extends RecyclerView.Adapter<ClienteAdaptador.MiViewHolder> {

    private List<ModelCliente> cliente;
    private int layout;
    private Activity activity;
    private Conexion_Cliente conexion_cliente;


    public ClienteAdaptador(List<ModelCliente> cliente, int layout, Activity activity, Conexion_Cliente conexion_cliente) {
        this.cliente = cliente;
        this.layout = layout;
        this.activity = activity;
        this.conexion_cliente = conexion_cliente;

    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout, parent, false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(cliente.get(position));

    }

    @Override
    public int getItemCount() {
        return cliente.size();
    }

    public class MiViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {

        private TextView card_cli_nombre;
        private TextView card_cli_tipo_persona;
        private TextView card2_numero_id;
        private TextView card_cli_numero_dv;

        private MiViewHolder(View itemView) {
            super(itemView);

            card_cli_nombre = itemView.findViewById(R.id.card_cli_nombre);
            card_cli_tipo_persona = itemView.findViewById(R.id.card_cli_tipo_persona);
            card2_numero_id = itemView.findViewById(R.id.card2_numero_id);
            card_cli_numero_dv = itemView.findViewById(R.id.card_cli_numero_dv);

            itemView.setOnCreateContextMenuListener(this);

        }

        private void bind(final ModelCliente cliente) {
            card_cli_nombre.setText(cliente.getNombre());
            card_cli_tipo_persona.setText(cliente.getJurisdiccion());
            card2_numero_id.setText(cliente.getIdentificacion());
            card_cli_numero_dv.setText(cliente.getDatoVerificador());
        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View v, ContextMenu.ContextMenuInfo menuInfo) {

            ModelCliente clienteSeleccionado = cliente.get(this.getAdapterPosition());
            contextMenu.setHeaderTitle("¿Que desea hacer con ?  " + clienteSeleccionado.getNombre());

            MenuInflater inflater = activity.getMenuInflater();
            inflater.inflate(R.menu.menu_cardview_cliente, contextMenu);

            for (int i = 0; i < contextMenu.size(); i++)
                contextMenu.getItem(i).setOnMenuItemClickListener(this);
        }


        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {

            switch (menuItem.getItemId()) {


                case R.id.card_client_generar_fat:
                    conexion_cliente.generarFacturadeCliente(cliente.get(getAdapterPosition()));
                    return true;

                case R.id.card_client_ver_mas:
                    conexion_cliente.detallesDelCliente(cliente.get(getAdapterPosition()));
                    return true;

                case R.id.card_client_editar:
                    conexion_cliente.llamarVentanaEditarCliente(cliente.get(getAdapterPosition()));

                    return true;

                case R.id.card_client_borrar:

                    conexion_cliente.borrarCliente(cliente.get(getAdapterPosition()));

                    return true;

            }

            return false;
        }
    }







}
