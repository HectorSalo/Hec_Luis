package com.example.proyectthefactoyhka.ajustes.unidades;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.proyectthefactoyhka.R;

public class Unidades extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unidades);




    }
}
