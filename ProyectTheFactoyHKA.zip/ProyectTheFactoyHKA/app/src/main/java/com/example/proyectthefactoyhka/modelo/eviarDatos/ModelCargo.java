package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.SerializedName;

public class ModelCargo {

    @SerializedName("baseImponible")
    private String baseImponible;

    @SerializedName("codigo")
    private String codigo;

    @SerializedName("monto")
    private String monto;

    @SerializedName("porcentaje")
    private String porcentaje;

    public ModelCargo(String baseImponible, String codigo, String monto, String porcentaje) {
        this.baseImponible = baseImponible;
        this.codigo = codigo;
        this.monto = monto;
        this.porcentaje = porcentaje;
    }

    public String getBaseImponible() {
        return baseImponible;
    }

    public void setBaseImponible(String baseImponible) {
        this.baseImponible = baseImponible;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(String porcentaje) {
        this.porcentaje = porcentaje;
    }
}
