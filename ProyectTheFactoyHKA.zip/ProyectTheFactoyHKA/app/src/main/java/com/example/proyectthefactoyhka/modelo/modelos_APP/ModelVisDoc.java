package com.example.proyectthefactoyhka.modelo.modelos_APP;

public class ModelVisDoc {

    private String producto;
    private String cantidadXventa;
    private String total;


    public ModelVisDoc(String producto, String cantidadXventa, String total) {
        this.producto = producto;
        this.cantidadXventa = cantidadXventa;
        this.total = total;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getCantidad() {
        return cantidadXventa;
    }

    public void setCantidad(String cantidad) {
        this.cantidadXventa = cantidad;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
