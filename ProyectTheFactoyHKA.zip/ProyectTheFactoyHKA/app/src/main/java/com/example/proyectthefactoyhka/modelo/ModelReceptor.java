package com.example.proyectthefactoyhka.modelo;

public class ModelReceptor {
    private String numDocumento;
    private String razonSocial;
    private String tipoDocumento;
    private String email;
    private String notificar;


    public ModelReceptor() {
    }

    public ModelReceptor(String numDocumento, String razonSocial, String tipoDocumento) {
        this.numDocumento = numDocumento;
        this.razonSocial = razonSocial;
        this.tipoDocumento = tipoDocumento;
    }

    public ModelReceptor(String numDocumento, String razonSocial, String tipoDocumento, String email, String notificar) {
        this.numDocumento = numDocumento;
        this.razonSocial = razonSocial;
        this.tipoDocumento = tipoDocumento;
        this.email = email;
        this.notificar = notificar;
    }

    public String getNumDocumento() {
        return numDocumento;
    }

    public void setNumDocumento(String numDocumento) {
        this.numDocumento = numDocumento;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNotificar() {
        return notificar;
    }

    public void setNotificar(String notificar) {
        this.notificar = notificar;
    }
}
