package com.example.proyectthefactoyhka.catalogo_producto.ventana_emergente;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.herramienta.ArrayGeneralApp;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;

import static android.Manifest.permission.CAMERA;

public class VentanaProducto extends DialogFragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, View.OnFocusChangeListener {

    private Realm realm;
    private ModelUsuario usuarios;
    private RealmList<ModelProducto> listaproducto;
    private RealmList<ModelUnidad> listaUnidades;
    private RealmResults<ModelTasa> tasas;
    private int idUsuario;
    private ModelProducto producto;
    private String tipo_producto, tipo_unidad;
    private EditText ediDescripcion, ediCodigo, ediPrecio, edi_porc_impuesto_isc;
    private Spinner spinner_tipo_producto, spinner_porc_impuesto_igv, spinner_tipo_unidad;
    private Button addpro_bt_agregar;
    private ImageButton addpro_Scan;
    private int posicionSpinnerIGV;
    private final int CODIGO_PERMISO = 696;
    private String codigoPro;
    private ArrayList<String> datosIGV = new ArrayList<>();
    private List<String> listaunidadcheckeada;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.ventana_add_producto, container, false);

        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        cast(view);
        adapterDelosSpiner(spinner_tipo_producto);
        recibirDatosDeOtrosActivitys();
        implemetarSpinnerArray();
        elCodigoEsUnaEdicion();
        implemetarSpinnerArray(datosIGV,spinner_porc_impuesto_igv);
        implemetarSpinnerArray(listaunidadcheckeada,spinner_tipo_unidad);

        return view;



    }



    private void implemetarSpinnerArray() {

             listaunidadcheckeada = new ArrayList<>();

        if (listaUnidades.size() == 0) {

            List<ModelUnidad> arrayUnidades = ArrayGeneralApp.todasLasUnidades();

            realm.beginTransaction();
            listaUnidades.addAll(arrayUnidades);
            usuarios.setDatosunidad(listaUnidades);
            realm.copyToRealm(listaUnidades);
            realm.commitTransaction();
        }

        for (int i=0; i<listaUnidades.size();i++){

            if (listaUnidades.get(i).isCheck()){

                listaunidadcheckeada.add(listaUnidades.get(i).getDescripcion());
            }
        }

        for (int i = 0; i < tasas.size(); i++) {

            ModelTasa listaTasa = tasas.get(i);
            if (listaTasa != null && i==0) {
                datosIGV.add(listaTasa.getPorcentajeDeImpuesto());
            }else if(listaTasa != null && !listaTasa.getPorcentajeDeImpuesto().equals("0")){
                datosIGV.add(listaTasa.getPorcentajeDeImpuesto());

            }
        }




    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.addpro_bt_agregar:

                if (TieneCamposVacios()) {

                    validarCampoIndividual();

                } else {
                    if (verificaSiElCodigoExiste() && codigoPro == null) {

                        mostrarToast(R.string.toast_codigo);

                    } else {
                        double monto = Double.parseDouble(ediPrecio.getText().toString());

                        if (producto != null) {

                            realm.beginTransaction();
                            producto.setCodigo1(ediCodigo.getText().toString());
                            producto.setDescripcion(ediDescripcion.getText().toString());
                            producto.setTipo_producto(tipo_producto);
                            producto.setPrecioUnitario1(monto);
                            producto.setTipo_unidad(tipo_unidad);
                            producto.setPosicionSpinnerIGV(posicionSpinnerIGV);
                            producto.setCantidadDePorcISC(edi_porc_impuesto_isc.getText().toString());
                            realm.commitTransaction();
                            realm.close();

                        } else {

                            ModelProducto modelo = new ModelProducto(tipo_producto, ediCodigo.getText().toString(), "", ediDescripcion.getText().toString(), monto, tipo_unidad, posicionSpinnerIGV, edi_porc_impuesto_isc.getText().toString());

                            realm.beginTransaction();
                            realm.copyToRealm(modelo);
                            listaproducto.add(0, modelo);
                            realm.commitTransaction();
                            realm.close();
                        }
                        getDialog().dismiss();
                    }
                }

                break;

            case R.id.addpro_Scan:

                permisosCamara();

                break;
        }

    }


    //metodo el cual recibira datos del activity ProductosMain .. este si en dado caso recibe un codigo valido , este  detectara que es una edicion de lo contrario inicializara como un producto nuevo
    private void recibirDatosDeOtrosActivitys() {
        if (getArguments() != null) {

            idUsuario = getArguments().getInt(getString(R.string.enviar_usuario));
            codigoPro = getArguments().getString("codigo");

            baseDeDatos();

            if (codigoPro != null) {
                RealmQuery<ModelProducto> query = listaproducto.where().contains("codigo1", codigoPro);
                producto = query.findFirst();
            }
        }

    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast(View view) {

        ediDescripcion = view.findViewById(R.id.addpro_descripcion);
        ediCodigo = view.findViewById(R.id.addpro_codigo);

        addpro_Scan = view.findViewById(R.id.addpro_Scan);
        addpro_Scan.setOnClickListener(this);

        ediPrecio = view.findViewById(R.id.addpro_preciounitario);
        ediPrecio.setText("0");
        ediPrecio.setOnFocusChangeListener(this);

        edi_porc_impuesto_isc = view.findViewById(R.id.edi_porc_impuesto_isc);
        edi_porc_impuesto_isc.setText("0");
        edi_porc_impuesto_isc.setOnFocusChangeListener(this);

        spinner_tipo_producto = view.findViewById(R.id.spinner_tipo_producto);
        spinner_tipo_producto.setOnItemSelectedListener(this);

        spinner_porc_impuesto_igv = view.findViewById(R.id.spinner_porc_impuesto_igv);
        spinner_porc_impuesto_igv.setOnItemSelectedListener(this);

        spinner_tipo_unidad = view.findViewById(R.id.addpro_tipo_unidad);
        spinner_tipo_unidad.setOnItemSelectedListener(this);

        addpro_bt_agregar = view.findViewById(R.id.addpro_bt_agregar);
        addpro_bt_agregar.setOnClickListener(this);
    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        tasas = realm.where(ModelTasa.class).findAll();
        if (usuarios != null){
            listaproducto = usuarios.getDatos_producto();
            listaUnidades = usuarios.getDatosunidad();
        }
    }

    //metodo principal utilizado para verificar si algun campo esta vacio al presionar el boton registrar
    private boolean TieneCamposVacios() {
        return ediDescripcion.getText().toString().isEmpty() ||
                ediCodigo.getText().toString().isEmpty() ||
                ediPrecio.getText().toString().isEmpty();
    }


    //metodo el cual identificara de manera individual cual de todos los elemento es el que posee un campo vacio
    private void validarCampoIndividual() {

        if (ediCodigo.getText().toString().isEmpty()) {
            mostrarToast(R.string.toast_codigo);
        } else {
            if (ediDescripcion.getText().toString().isEmpty()) {
                mostrarToast(R.string.toast_descripcion);
            }
        }
    }


    // metodo que verificara en los campos numericos si este posee un 0 al presionar vaciara el campo , si el usuario no coloca ningun valor este nuevamente rellenara el campo con un 0
    @Override
    public void onFocusChange(View v, boolean hasFocus) {

        if (ediPrecio.hasFocus() && ediPrecio.getText().toString().equals("0")) {
            ediPrecio.setText("");
        } else if (!ediPrecio.hasFocus() && ediPrecio.getText().length() == 0) {
            ediPrecio.setText("0");
        }

        if (edi_porc_impuesto_isc.hasFocus() && edi_porc_impuesto_isc.getText().toString().equals("0")) {
            edi_porc_impuesto_isc.setText("");
        } else if (!edi_porc_impuesto_isc.hasFocus() && edi_porc_impuesto_isc.getText().length() == 0) {
            edi_porc_impuesto_isc.setText("0");
        }
    }


    //metodo que verificara la ubicacion de cada spinner de la ventana .. enviado la ubicacion de esto o un dato especifico
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {

            case R.id.spinner_tipo_producto:

                tipo_producto = parent.getItemAtPosition(position).toString();

                break;

            case R.id.spinner_porc_impuesto_igv:

                posicionSpinnerIGV = spinner_porc_impuesto_igv.getSelectedItemPosition();

                break;

            case R.id.addpro_tipo_unidad:

                tipo_unidad = parent.getItemAtPosition(position).toString();

                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    //metodo que se encargara de verificar los permiso de ususario tanto de versiones por debajo de 6.0 a superiores de 6.0 esten ya registrado para la inicializacion de la actividad de escaneo de codigo
    private void permisosCamara() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso()) {
                //ha aceptado

                Intent intent = new Intent(getDialog().getContext(), CodigoScanner.class);
                startActivityForResult(intent, 1);

            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{CAMERA}, CODIGO_PERMISO);
                } else {
                    //ha rechazado
                    requestPermissions(new String[]{CAMERA}, CODIGO_PERMISO);
                }
            }
        } else {
            viejaVersionpermisoCamara();
        }
    }


    private void viejaVersionpermisoCamara() {

        if (chequearPermiso()) {

            Intent intent = new Intent(getDialog().getContext(), CodigoScanner.class);
            startActivityForResult(intent, 1);
        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo para registrar los permisos de camara para versiones 6.0 o superior

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CODIGO_PERMISO) {
            if (grantResults.length > 0) {

                String permission = permissions[0];
                int result = grantResults[0];

                if (permission.equals(CAMERA)) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(getDialog().getContext(), CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso();
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso() {
        int result = getDialog().getContext().checkCallingOrSelfPermission(Manifest.permission.CAMERA);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    //metodo que se encargara de recibir la respuesta de la actividad de escaneo de barra  y enviara su resultado al campo de texto perteneciente al ediCodigo
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1) {

            if (resultCode == Activity.RESULT_OK) {

                final String result = data.getStringExtra("barra");

                ediCodigo.setText(result);
            }
        }
    }

    private void implemetarSpinnerArray(List<String> dato ,Spinner spiner) {
        ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<>(getDialog().getContext(), R.layout.support_simple_spinner_dropdown_item, dato);
        spiner.setAdapter(stringArrayAdapter);
    }


    //metodo singleton para los spinner
    private void adapterDelosSpiner(Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (getDialog().getContext(), R.array.tipoproducto, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
    }


    //metodo para verificar si el codigo del producto esta en existencia en la base de datos
    private boolean verificaSiElCodigoExiste() {

        for (int i = 0; i < listaproducto.size(); ) {

            ModelProducto verificar = usuarios.getDatos_producto().get(i);

            if (verificar != null) {

                if (!ediCodigo.getText().toString().equals(verificar.getCodigo1())) {
                    i++;
                } else {
                    return true;
                }
            }
        }
        return false;
    }


    //metodo el cual se encargara de enviar los datos a cada editex si este resulta ser una edicion y bloqueando el editext perteneciente al codigo
    private void elCodigoEsUnaEdicion() {

        if (producto != null) {

            ediCodigo.setText(producto.getCodigo1());
            ediCodigo.setEnabled(false);
            ediDescripcion.setText(producto.getDescripcion());
            ediPrecio.setText(String.format("%s", producto.getPrecioUnitario1()));
            edi_porc_impuesto_isc.setText(producto.getCantidadDePorcISC());
            spinner_porc_impuesto_igv.setSelection(producto.getPosicionSpinnerIGV());
            addpro_bt_agregar.setText(R.string.bt_actualizar);
            addpro_Scan.setEnabled(false);
        } else {
            addpro_bt_agregar.setText(R.string.vent_agregar_producto);
        }

    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(getDialog().getContext(), mensaje, Toast.LENGTH_SHORT).show();
    }



}
