package com.example.proyectthefactoyhka.modelo;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelTotales implements Parcelable {

    private String importeTotalPagar;
    private String importeTotalVenta;
    private String montoTotalImpuestos;
    private ModelSubTotal subtotal;
    private String subtotalValorVenta;
    private String totalIGV;

    public ModelTotales(String importeTotalPagar, String importeTotalVenta, String montoTotalImpuestos,String subtotalValorVenta) {
        this.importeTotalPagar = importeTotalPagar;
        this.importeTotalVenta = importeTotalVenta;
        this.montoTotalImpuestos = montoTotalImpuestos;
        this.subtotalValorVenta = subtotalValorVenta;

    }


    protected ModelTotales(Parcel in) {
        importeTotalPagar = in.readString();
        importeTotalVenta = in.readString();
        montoTotalImpuestos = in.readString();
        subtotal = in.readParcelable(ModelSubTotal.class.getClassLoader());
        subtotalValorVenta = in.readString();
        totalIGV = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(importeTotalPagar);
        dest.writeString(importeTotalVenta);
        dest.writeString(montoTotalImpuestos);
        dest.writeParcelable(subtotal, flags);
        dest.writeString(subtotalValorVenta);
        dest.writeString(totalIGV);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelTotales> CREATOR = new Creator<ModelTotales>() {
        @Override
        public ModelTotales createFromParcel(Parcel in) {
            return new ModelTotales(in);
        }

        @Override
        public ModelTotales[] newArray(int size) {
            return new ModelTotales[size];
        }
    };

    public String getImporteTotalPagar() {
        return importeTotalPagar;
    }

    public void setImporteTotalPagar(String importeTotalPagar) {
        this.importeTotalPagar = importeTotalPagar;
    }

    public String getImporteTotalVenta() {
        return importeTotalVenta;
    }

    public void setImporteTotalVenta(String importeTotalVenta) {
        this.importeTotalVenta = importeTotalVenta;
    }

    public String getMontoTotalImpuestos() {
        return montoTotalImpuestos;
    }

    public void setMontoTotalImpuestos(String montoTotalImpuestos) {
        this.montoTotalImpuestos = montoTotalImpuestos;
    }

    public ModelSubTotal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(ModelSubTotal subtotal) {
        this.subtotal = subtotal;
    }

    public String getSubtotalValorVenta() {
        return subtotalValorVenta;
    }

    public void setSubtotalValorVenta(String subtotalValorVenta) {
        this.subtotalValorVenta = subtotalValorVenta;
    }

    public String getTotalIGV() {
        return totalIGV;
    }

    public void setTotalIGV(String totalIGV) {
        this.totalIGV = totalIGV;
    }
}
