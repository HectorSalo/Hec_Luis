package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelPeticionDeDocumentos {

    @SerializedName("fechaFin")
    @Expose
    private String fechaFin;
    @SerializedName("fechaInicio")
    @Expose
    private String fechaInicio;
    @SerializedName("rangoFin")
    @Expose
    private String rangoFin;
    @SerializedName("rangoInicio")
    @Expose
    private String rangoInicio;
    @SerializedName("ruc")
    @Expose
    private String ruc;
    @SerializedName("serial")
    @Expose
    private String serial;
    @SerializedName("tipoDocumento")
    @Expose
    private String tipoDocumento;
    @SerializedName("token")
    @Expose
    private String token;

    public ModelPeticionDeDocumentos(String fechaFin, String fechaInicio, String rangoFin, String rangoInicio, String ruc, String serial, String tipoDocumento, String token) {
        this.fechaFin = fechaFin;
        this.fechaInicio = fechaInicio;
        this.rangoFin = rangoFin;
        this.rangoInicio = rangoInicio;
        this.ruc = ruc;
        this.serial = serial;
        this.tipoDocumento = tipoDocumento;
        this.token = token;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getRangoFin() {
        return rangoFin;
    }

    public void setRangoFin(String rangoFin) {
        this.rangoFin = rangoFin;
    }

    public String getRangoInicio() {
        return rangoInicio;
    }

    public void setRangoInicio(String rangoInicio) {
        this.rangoInicio = rangoInicio;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
