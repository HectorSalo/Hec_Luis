package com.example.proyectthefactoyhka.modelo;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;

public class RequestEnviar {

    private String clave;
    private ModelDocumentoElectronico documentoElectronico;
    private String ruc;
    private String usuario;


    public RequestEnviar(String clave, String ruc, String usuario) {
        this.clave = clave;
        this.ruc = ruc;
        this.usuario = usuario;
    }


    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public ModelDocumentoElectronico getDocumentoElectronico() {
        return documentoElectronico;
    }

    public void setDocumentoElectronico(ModelDocumentoElectronico documentoElectronico) {
        this.documentoElectronico = documentoElectronico;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
