package com.example.proyectthefactoyhka.documento_emitido.adaptador;

import android.app.Activity;

import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.herramienta.FormatoMiles;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelDocumento;

import java.util.List;

public class DocumentoEmitidoAdaptador extends RecyclerView.Adapter<DocumentoEmitidoAdaptador.MiViewHolder>  {

    private List<ModelDocumento> documentos;
    private int layout;
    private Activity activity;
    private MyOnItemClick itemClick;


    public DocumentoEmitidoAdaptador(List<ModelDocumento> documentos, int layout, Activity activity, MyOnItemClick itemClick) {
        this.documentos = documentos;
        this.layout = layout;
        this.activity = activity;
        this.itemClick = itemClick;
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(documentos.get(position),itemClick);

    }

    @Override
    public int getItemCount() { return documentos.size(); }


    public class MiViewHolder extends RecyclerView.ViewHolder {

        private TextView card_doc_consumidor_final;
        private TextView card_num_doc;

        private TextView card_doc_fecha;
        private TextView card_doc_total;
        private TextView card_doc_estado;
        private CardView card_documetos;



        public MiViewHolder(View itemView) {
            super(itemView);

            card_doc_consumidor_final = itemView.findViewById(R.id.card_doc_consumidor_final);
            card_num_doc = itemView.findViewById(R.id.card_num_doc);
            card_doc_fecha = itemView.findViewById(R.id.card_doc_fecha);
            card_doc_total = itemView.findViewById(R.id.card_doc_total);
            card_doc_estado = itemView.findViewById(R.id.card_doc_estado);
            card_documetos = itemView.findViewById(R.id.card_documetos);


        }

        public void bind(final ModelDocumento documento, final MyOnItemClick itemClick){
            card_doc_consumidor_final.setText(documento.getNombreCliente() );
             card_num_doc.setText(documento.getSerieCorrelativo());

           card_doc_fecha.setText(documento.getFechaEmision());

           card_doc_total.setText(FormatoMiles.getFormattedString(documento.getTotal()));
            card_doc_estado.setText(documento.getEstatus());

            if(documento.getEstatus()!=null)
                if (documento.getEstatus().equals("enviado")){

                    card_documetos.setCardBackgroundColor(ContextCompat.getColor(activity,R.color.colorblanco));
                }else {
                    card_documetos.setCardBackgroundColor(ContextCompat.getColor(activity,R.color.doc_no_emitido));

                }

           itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {



                   itemClick.onItem(documento,getAdapterPosition());
               }
           });

        }



    }

    public interface MyOnItemClick{
        void onItem(ModelDocumento documento, int position);
    }



}
