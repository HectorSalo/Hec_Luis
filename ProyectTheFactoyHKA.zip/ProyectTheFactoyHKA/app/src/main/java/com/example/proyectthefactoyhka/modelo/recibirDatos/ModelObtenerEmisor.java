package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.google.gson.annotations.SerializedName;

public class ModelObtenerEmisor {

    @SerializedName("infoEmisor")
    private ModelInfoEmisor modelInfoEmisor;

    public ModelInfoEmisor getModelInfoEmisor() {
        return modelInfoEmisor;
    }

    public void setModelInfoEmisor(ModelInfoEmisor modelInfoEmisor) {
        this.modelInfoEmisor = modelInfoEmisor;
    }
}
