package com.example.proyectthefactoyhka.modelo.modelos_APP;

import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelRecibirProductos;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModelRecibirListaProductos {

    @SerializedName("productos")
    private List<ModelRecibirProductos> productos ;


    public List<ModelRecibirProductos> getProductos() {
        return productos;
    }


    public void setProductos(List<ModelRecibirProductos> productos) {
        this.productos = productos;
    }
}
