package com.example.proyectthefactoyhka.ajustes.teclado.adaptador;

import android.app.Activity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;

import java.util.List;


public class TecladoAdaptador extends RecyclerView.Adapter<TecladoAdaptador.MiViewHolder>{

    private List<ModelTeclas> teclas;
    private Activity activity;
    private int layout;
    private int ubicacion;
    private MyItemClick listener;

    public TecladoAdaptador(List<ModelTeclas> teclas, Activity activity, int layout,int ubicacion,MyItemClick listener) {
        this.teclas = teclas;
        this.activity = activity;
        this.layout = layout;
        this.ubicacion = ubicacion;
        this.listener = listener;
    }

    @Override
    public TecladoAdaptador.MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        TecladoAdaptador.MiViewHolder vh = new TecladoAdaptador.MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(TecladoAdaptador.MiViewHolder holder, int position) {
        holder.bind(teclas.get(position),listener);

    }

    @Override
    public int getItemCount() {
        return teclas.size();
    }

    class MiViewHolder extends RecyclerView.ViewHolder  {

        private TextView card2_nombre;

        MiViewHolder(View itemView) {
            super(itemView);

            if (ubicacion==0) {

                card2_nombre = itemView.findViewById(R.id.card_tecla_panel_teclado_ajustes);
            }else if (ubicacion==1){

                card2_nombre = itemView.findViewById(R.id.card_tecla_panel_teclado_factura);
            }

            else if (ubicacion==2){

                card2_nombre = itemView.findViewById(R.id.card_tecla_panel_teclado_numerico);
            }

        }

        void bind(final ModelTeclas tecla, final MyItemClick listener){

            card2_nombre.setText(tecla.getTexto());
            card2_nombre.setBackgroundColor(tecla.getFondo());




            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.listener(tecla,getAdapterPosition());
                }
            });


        }
    }

    public interface MyItemClick{

        void listener(ModelTeclas modelTeclas, int position);
    }





}
