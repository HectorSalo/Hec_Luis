package com.example.proyectthefactoyhka.modelo.modelos_APP;
import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;
import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ModelTeclado extends RealmObject {

    @PrimaryKey
    private int id;
    private boolean tecladoPordefecto;
    private RealmList<ModelTeclas> teclas;

    public ModelTeclado() {
    }


    ModelTeclado(boolean tecladoPordefecto) {
        this.id = MyApplication.IdTeclado.incrementAndGet();
        this.tecladoPordefecto = tecladoPordefecto;
        this.teclas = new RealmList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isTecladoPordefecto() {
        return tecladoPordefecto;
    }

    public void setTecladoPordefecto(boolean tecladoPordefecto) {
        this.tecladoPordefecto = tecladoPordefecto;
    }

    public RealmList<ModelTeclas> getTeclas() {
        return teclas;
    }

    public void setTeclas(RealmList<ModelTeclas> teclas) {
        this.teclas = teclas;
    }
}
