package com.example.proyectthefactoyhka.ajustes.recibo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;

import com.example.proyectthefactoyhka.R;


public class Recibo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recibo);


        mostrarToolbar();

    }


    //metodo que  configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_recibo);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Recibo.this.setTitle(R.string.toolbar_recibo);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}