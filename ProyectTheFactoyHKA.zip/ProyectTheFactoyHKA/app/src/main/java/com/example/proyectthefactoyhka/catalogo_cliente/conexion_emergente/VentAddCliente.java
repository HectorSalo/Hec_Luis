package com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente;


import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;

import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelCiudades;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelDepartamentos;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMunicipios;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.ArrayList;

import in.galaxyofandroid.spinerdialog.OnSpinerItemClick;
import in.galaxyofandroid.spinerdialog.SpinnerDialog;
import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;


public class VentAddCliente extends DialogFragment implements AdapterView.OnItemSelectedListener, View.OnClickListener {


    private RealmList<ModelCliente> listaClientes;
    private RealmResults<ModelDepartamentos> listaDeDepartamento;
    private RealmResults<ModelMunicipios>  listaDeMunicipios;
    private RealmResults<ModelCiudades>  listaDeCiudades;

    private String tipo_persona, pais, tipo_documento;
    private ModelCliente cliente;
    private ArrayList<String> departamento, municipio, ciudad;
    private EditText edi_cli_apellido, edi_cli_nombre, edi_cli_nro_id, edi_cli_correo, edi_cli_direccion, edi_cli_telefono;
    private Spinner spinner_tipo_persona, spinner_cli_tipo_documento, spinner_cli_pais;
    private SpinnerDialog ventana_spinner;
    private Realm realm;
    private ModelUsuario usuarios;
    private TextView spinner_cli_departamento, spinner_cli_municipio, spinner_cli_ciudad;
    private int idUsuario;
    private String codigocli;
    private Button bt_cli_agregar;
    private ModelMunicipios modelMunicipios;
    private ModelDepartamentos modelDepartamentos;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.ventana_agregar_cliente, container, false);


        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        cast(view);
        recibirDatosDeOtrosActivitys();
        baseDeDatos();
        arrayDeLosSeacheableSpinner();
        implementarSpiner();
        elClienteEsUnaEdicion();

        return view;
    }


    private void recibirDatosDeOtrosActivitys() {
        if (getArguments() != null) {

            idUsuario = getArguments().getInt(getString(R.string.enviar_usuario));
            codigocli = getArguments().getString("ruc");

            baseDeDatos();

            if (codigocli != null) {
                RealmQuery<ModelCliente> query = listaClientes.where().contains("identificacion", codigocli);
                cliente = query.findFirst();
            }
        }

    }


    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();

        listaDeDepartamento =realm.where(ModelDepartamentos.class).findAll();
        listaDeMunicipios = realm.where(ModelMunicipios.class).findAll();
        listaDeCiudades = realm.where(ModelCiudades.class).findAll();

        if (usuarios != null)
            listaClientes = usuarios.getDatos_clientes();
    }


//metodo para darle accion a todos los botones en la ventana

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            //en todos los casos que inician por spinner llamara a un metodo singleton adaptadorSearchableSpinner
            //el cual llenara los spinner selecionado
            // opc 1 donde obtendra los datos , opc 2 a donde seran dirigidos
            //luego se llamara a la ventana de dialigo

            case R.id.spinner_cli_departamento:

                adaptadorSearchableSpinner(departamento, spinner_cli_departamento);
                ventana_spinner.showSpinerDialog();

                break;


            case R.id.spinner_cli_municipio:

                adaptadorSearchableSpinner(municipio, spinner_cli_municipio);
                ventana_spinner.showSpinerDialog();

                break;

            case R.id.spinner_cli_ciudad:

                adaptadorSearchableSpinner(ciudad, spinner_cli_ciudad);
                ventana_spinner.showSpinerDialog();

                break;

            case R.id.bt_cli_agregar:


/*                if (TieneCamposVacios()) {
                    validarCampoIndividual();

                } else {*/

                if(validarCampos()){

                    if (verificaSiElCodigoExiste() && codigocli == null) {

                        mostrarToast(R.string.toast_validar_identificado);

                    } else {


                        if (cliente != null) {

                            realm.beginTransaction();
                            cliente.setNombre(edi_cli_nombre.getText().toString());
                            cliente.setApellido(edi_cli_apellido.getText().toString());
                            cliente.setJurisdiccion(tipo_persona);
                            cliente.setTelefono(edi_cli_telefono.getText().toString());
                            cliente.setIdentificacion(edi_cli_nro_id.getText().toString());
                            //                  cliente.setDatoVerificador(edi_cli_dv.getText().toString());
                            cliente.setCorreo(edi_cli_correo.getText().toString());
                            cliente.setProvincia(spinner_cli_departamento.getText().toString());
                            cliente.setDistrito(spinner_cli_municipio.getText().toString());
                            cliente.setCorreginmiento(spinner_cli_ciudad.getText().toString());
                            cliente.setDireccion(edi_cli_direccion.getText().toString());
                            realm.commitTransaction();
                            realm.close();

                            //           conexion_cliente.adaptador();

                        } else {

                            ModelCliente modelo = new ModelCliente(pais, spinner_cli_ciudad.getText().toString(), spinner_cli_municipio.getText().toString(), edi_cli_direccion.getText().toString(), edi_cli_nombre.getText().toString(),
                                    edi_cli_nro_id.getText().toString(), spinner_cli_departamento.getText().toString(), edi_cli_apellido.getText().toString(), tipo_persona, tipo_documento, edi_cli_telefono.getText().toString()
                                    , tipo_documento, edi_cli_correo.getText().toString(), "");


                            realm.beginTransaction();
                            realm.copyToRealmOrUpdate(modelo);
                            listaClientes.add(0, modelo);
                            realm.commitTransaction();

                            //usuarios.getDatos_clientes().add(modelo);

                            //        conexion_cliente.adaptador();

                        }

                        getDialog().dismiss();
                    }
                }

                break;

        }

    }


    //metodo para rellenar los spinner la opcion 1 sera de donde vendra los datos del spinner
    // la opcion 2 sera en donde seran ubicados

    private void implementarSpiner() {
        adapterDelosSpiner(R.array.tipo, spinner_tipo_persona);
        adapterDelosSpiner(R.array.pais, spinner_cli_pais);
        adapterDelosSpiner(R.array.tiposdedocumentos, spinner_cli_tipo_documento);

    }


    private void arrayDeLosSeacheableSpinner() {
        departamento =new ArrayList<String>() {
            {
                for (int i = 0; i < listaDeDepartamento.size(); i++) {

                    ModelDepartamentos obtenerDepartamento = listaDeDepartamento.get(i);

                    if (obtenerDepartamento != null) {

                        add(obtenerDepartamento.getDepartamento());
                    }

                }
            }
        };
    }




    private void llenarSpinerDeMunicipios(String item){




            RealmQuery<ModelDepartamentos> departamentosRealmQuery=realm.where(ModelDepartamentos.class).equalTo("departamento",item);
            modelDepartamentos=departamentosRealmQuery.findFirst();

            municipio = new ArrayList<String>() {
                {
                    RealmResults<ModelMunicipios> municipios = realm.where(ModelMunicipios.class).equalTo("codigo_departamento", modelDepartamentos.getCodigo_departamento()).findAll();
                    if(municipios!=null){
                        for (int i =0; i<municipios.size(); i++){
                            add(municipios.get(i).getMunicipio());
                        }
                    }
                }
            };


    }




    private void llenarSpinerCiudades(String item) {


        RealmQuery<ModelMunicipios> municipiosRealmQuery=realm.where(ModelMunicipios.class).equalTo("municipio",item);
        modelMunicipios=municipiosRealmQuery.findFirst();

        ciudad = new ArrayList<String>() {
            {

                RealmResults<ModelCiudades> ciudades = realm.where(ModelCiudades.class).equalTo("codigo_departamento", modelDepartamentos.getCodigo_departamento()).findAll();
                if(ciudades!=null){

                    for (int i =0; i<ciudades.size(); i++){
                        add(ciudades.get(i).getCiudad());
                    }
                }

            }
        };


    }






    //metodo que obtiene de manera dinamica el dato que esta seleccionado en los spinner y los
    // envia a una variable global String

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {

            case R.id.spinner_cli_tipo_persona:
                tipo_persona = parent.getItemAtPosition(position).toString();

                if (position == 0) {

                    edi_cli_apellido.setVisibility(View.VISIBLE);

                } else {

                    edi_cli_apellido.setVisibility(View.GONE);
                }

                break;
            case R.id.spinner_cli_pais:
                pais = parent.getItemAtPosition(position).toString();

                break;

            case R.id.spinner_cli_tipo_documento:

                if (position == 0) {
                    tipo_documento = "0";
                } else if (position == 1) {
                    tipo_documento = "1";
                } else if (position == 2) {
                    tipo_documento = "4";
                } else if (position == 3) {
                    tipo_documento = "6";
                } else if (position == 4) {
                    tipo_documento = "7";
                } else if (position == 5) {
                    tipo_documento = "A";
                }
                break;

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    //metodo principal utilizado para verificar si algun campo esta vacio al presionar el boton registrar

    private boolean TieneCamposVacios() {

        return edi_cli_apellido.getText().toString().isEmpty() && edi_cli_apellido.getVisibility() == View.VISIBLE ||
                edi_cli_nombre.getText().toString().isEmpty() ||
                edi_cli_nro_id.getText().toString().isEmpty() ||
                edi_cli_correo.getText().toString().isEmpty() ||
                edi_cli_direccion.getText().toString().isEmpty() ||
                edi_cli_telefono.getText().toString().isEmpty();
    }


    private void elClienteEsUnaEdicion() {

        if (cliente != null) {

            edi_cli_apellido.setText(cliente.getApellido());
            edi_cli_nombre.setText(cliente.getNombre());
            edi_cli_nro_id.setText(cliente.getIdentificacion());
            edi_cli_nro_id.setEnabled(false);

            edi_cli_correo.setText(cliente.getCorreo());
            edi_cli_direccion.setText(cliente.getDireccion());
            edi_cli_telefono.setText(cliente.getTelefono());
            spinner_cli_departamento.setText(cliente.getProvincia());
            spinner_cli_municipio.setText(cliente.getDistrito());
            spinner_cli_ciudad.setText(cliente.getCorreginmiento());
            bt_cli_agregar.setText(R.string.actualizar_cliente);
        } else {
            bt_cli_agregar.setText(R.string.agregar_cliente);
        }

    }


    private boolean verificaSiElCodigoExiste() {

        for (int i = 0; i < listaClientes.size(); ) {

            ModelCliente verificar = usuarios.getDatos_clientes().get(i);

            if (verificar != null) {

                if (!edi_cli_nro_id.getText().toString().equals(verificar.getIdentificacion())) {
                    i++;
                } else {
                    return true;
                }
            }
        }
        return false;

    }


    //metodo filtro utilizado para verificar de manera individual para ver si algun campo esta vacio
    //y asi enviar un toast al usuario este metodo sera llamado por validarCamposVacios si en dado caso este envia
    //un true como resultado

    /*
     * Este tipo de validacion es confusa, y complica el manejo individual de cada validacion
     * Se reemplaza por método validarCampos()
     * */

    private void validarCampoIndividual() {

        if (edi_cli_apellido.getText().toString().isEmpty() && edi_cli_apellido.getVisibility() == View.VISIBLE) {
            mostrarToast(R.string.validar_client_apellido);

        } else {
            if (edi_cli_nombre.getText().toString().isEmpty()) {
                mostrarToast(R.string.validar_client_nombre);
            } else {
                if (edi_cli_nro_id.getText().toString().isEmpty()) {
                    mostrarToast(R.string.validar_client_nro_id);
                } else {
                    //      if (edi_cli_dv.getText().toString().isEmpty()){
                    //        mostrarToast(R.string.validar_client_dv);
                    //   }else {
                    if (edi_cli_correo.getText().toString().isEmpty()) {
                        mostrarToast(R.string.validar_client_correo);
                    } else {

                        if (spinner_cli_departamento.getText().toString().isEmpty()) {
                            mostrarToast(R.string.validar_localidad_provincia);
                        } else {

                            if (spinner_cli_municipio.getText().toString().isEmpty()) {
                                mostrarToast(R.string.validar_localidad_distrito);

                            } else {

                                if (spinner_cli_ciudad.getText().toString().isEmpty()) {

                                    mostrarToast(R.string.validar_localidad_corregimiento);
                                } else {

                                    if (edi_cli_direccion.getText().toString().isEmpty()) {
                                        mostrarToast(R.string.validar_client_direccion);
                                    } else {
                                        if (edi_cli_telefono.getText().toString().isEmpty()) {
                                            mostrarToast(R.string.validar_client_telf);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    //}


    private boolean validarCampos() {


        if (edi_cli_apellido.getText().toString().isEmpty() && edi_cli_apellido.getVisibility() == View.VISIBLE) {
            mostrarToast(R.string.validar_client_apellido);
            return false;
        }
        if (edi_cli_nombre.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_nombre);
            return false;
        }

        if (edi_cli_nro_id.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_nro_id);
            return false;
        }

/*        if (edi_cli_dv.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_dv);
            return false;
        }*/
        if (edi_cli_correo.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_correo);
            return false;
        }
        if (spinner_cli_departamento.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_localidad_provincia);
            return false;
        }

        if (spinner_cli_municipio.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_localidad_distrito);
            return false;
        }
        if (spinner_cli_ciudad.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_localidad_corregimiento);
            return false;
        }

        if (edi_cli_direccion.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_direccion);
            return false;
        }
        if (edi_cli_telefono.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_client_telf);
            return false;
        }

        return true;
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast(View view) {

        edi_cli_apellido = view.findViewById(R.id.edi_cli_apellido);
        edi_cli_nombre = view.findViewById(R.id.edi_cli_nombre);
        edi_cli_nro_id = view.findViewById(R.id.edi_cli_nro_id);
        edi_cli_correo = view.findViewById(R.id.edi_cli_correo);
        edi_cli_direccion = view.findViewById(R.id.edi_cli_direccion);
        edi_cli_telefono = view.findViewById(R.id.edi_cli_telefono);

        spinner_cli_tipo_documento = view.findViewById(R.id.spinner_cli_tipo_documento);
        spinner_cli_tipo_documento.setOnItemSelectedListener(this);


        spinner_tipo_persona = view.findViewById(R.id.spinner_cli_tipo_persona);
        spinner_tipo_persona.setOnItemSelectedListener(this);

        spinner_cli_pais = view.findViewById(R.id.spinner_cli_pais);
        spinner_cli_pais.setOnItemSelectedListener(this);

        spinner_cli_departamento = view.findViewById(R.id.spinner_cli_departamento);
        spinner_cli_departamento.setOnClickListener(this);


        spinner_cli_municipio = view.findViewById(R.id.spinner_cli_municipio);
        spinner_cli_municipio.setOnClickListener(this);
        spinner_cli_municipio.setEnabled(false);

        spinner_cli_ciudad = view.findViewById(R.id.spinner_cli_ciudad);
        spinner_cli_ciudad.setOnClickListener(this);
        spinner_cli_ciudad.setEnabled(false);

        bt_cli_agregar = view.findViewById(R.id.bt_cli_agregar);
        bt_cli_agregar.setOnClickListener(this);
    }


    //metodo singleton para pode llenar los Searcheable spinner

    private void adaptadorSearchableSpinner(ArrayList<String> datosSpinner, final TextView spinnerTexto) {

        ventana_spinner = new SpinnerDialog(getActivity(), datosSpinner, "Selecciona");
        ventana_spinner.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {
                spinnerTexto.setText(item);

                if (spinnerTexto== spinner_cli_departamento){


                    llenarSpinerDeMunicipios(item);
                    spinner_cli_municipio.setEnabled(true);
                    spinner_cli_municipio.setText("");
                    spinner_cli_ciudad.setEnabled(false);
                    spinner_cli_ciudad.setText("");

                }else if (spinnerTexto== spinner_cli_municipio){

                    llenarSpinerCiudades(item);
                    spinner_cli_ciudad.setText("");
                    spinner_cli_ciudad.setEnabled(true);
                }

            }
        });

    }


    //metodo singleton para los spinner
    private void adapterDelosSpiner(int array, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (getDialog().getContext(), array, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);

    }

    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {

        Toast.makeText(getDialog().getContext(), mensaje, Toast.LENGTH_SHORT).show();
    }


}






