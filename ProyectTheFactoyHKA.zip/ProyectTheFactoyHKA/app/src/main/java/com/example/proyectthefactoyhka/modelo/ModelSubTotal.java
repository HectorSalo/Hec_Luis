package com.example.proyectthefactoyhka.modelo;

import android.os.Parcel;
import android.os.Parcelable;

public class ModelSubTotal implements Parcelable {


    private String iGV;

    private String iSC;

    private String iVAP;

    private String exoneradas;

    private String exportacion;

    private String gratuitas;

    private String inafectas;

    private String otrosTributos;

    public ModelSubTotal(String iGV) {
        this.iGV = iGV;

    }

    protected ModelSubTotal(Parcel in) {
        iGV = in.readString();
        iSC = in.readString();
        iVAP = in.readString();
        exoneradas = in.readString();
        exportacion = in.readString();
        gratuitas = in.readString();
        inafectas = in.readString();
        otrosTributos = in.readString();
    }

    public static final Creator<ModelSubTotal> CREATOR = new Creator<ModelSubTotal>() {
        @Override
        public ModelSubTotal createFromParcel(Parcel in) {
            return new ModelSubTotal(in);
        }

        @Override
        public ModelSubTotal[] newArray(int size) {
            return new ModelSubTotal[size];
        }
    };

    public String getiGV() {
        return iGV;
    }

    public void setiGV(String iGV) {
        this.iGV = iGV;
    }

    public String getiSC() {
        return iSC;
    }

    public void setiSC(String iSC) {
        this.iSC = iSC;
    }

    public String getiVAP() {
        return iVAP;
    }

    public void setiVAP(String iVAP) {
        this.iVAP = iVAP;
    }

    public String getExoneradas() {
        return exoneradas;
    }

    public void setExoneradas(String exoneradas) {
        this.exoneradas = exoneradas;
    }

    public String getExportacion() {
        return exportacion;
    }

    public void setExportacion(String exportacion) {
        this.exportacion = exportacion;
    }

    public String getGratuitas() {
        return gratuitas;
    }

    public void setGratuitas(String gratuitas) {
        this.gratuitas = gratuitas;
    }

    public String getInafectas() {
        return inafectas;
    }

    public void setInafectas(String inafectas) {
        this.inafectas = inafectas;
    }

    public String getOtrosTributos() {
        return otrosTributos;
    }

    public void setOtrosTributos(String otrosTributos) {
        this.otrosTributos = otrosTributos;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(iGV);
        dest.writeString(iSC);
        dest.writeString(iVAP);
        dest.writeString(exoneradas);
        dest.writeString(exportacion);
        dest.writeString(gratuitas);
        dest.writeString(inafectas);
        dest.writeString(otrosTributos);
    }
}
