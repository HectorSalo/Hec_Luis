package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModelObtenerListaDeClientes {

    @SerializedName("clientes")
    @Expose
    private List<ModelCliente> clientes = null;
    @SerializedName("codigoError")
    @Expose
    private String codigoError;
    @SerializedName("mensajeError")
    @Expose
    private String mensajeError;
    @SerializedName("procesado")
    @Expose
    private Boolean procesado;

    public ModelObtenerListaDeClientes() {
    }

    public List<ModelCliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<ModelCliente> clientes) {
        this.clientes = clientes;
    }

    public String getCodigoError() {
        return codigoError;
    }

    public void setCodigoError(String codigoError) {
        this.codigoError = codigoError;
    }

    public String getMensajeError() {
        return mensajeError;
    }

    public void setMensajeError(String mensajeError) {
        this.mensajeError = mensajeError;
    }

    public Boolean getProcesado() {
        return procesado;
    }

    public void setProcesado(Boolean procesado) {
        this.procesado = procesado;
    }
}
