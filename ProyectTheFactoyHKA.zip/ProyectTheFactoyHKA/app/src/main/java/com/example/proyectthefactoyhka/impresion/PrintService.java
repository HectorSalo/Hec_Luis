package com.example.proyectthefactoyhka.impresion;

import android.app.IntentService;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;


public class PrintService extends IntentService {


    public static final String PRINTER_BLUETOOTH = "0";
    public static final String PRINTER_ETHERNET = "1";
    private static final String TAG = "PrintService";
    public static final String ACTION_PRINT= "PRINT";
    public static final String ACTION_PRINT_RECEIPT = "PRINT_RECEIPT";
    private static final String ACTION_STOP = "STOP";

    // TODO: Rename parameters
    public static final String EXTRA_DOC = "PARAM1";
    public static final String EXTRA_PRINTERS = "PARAM2";


    private Handler mHandler;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothSocket mmSocket;
    private BluetoothDevice mmDevice;
    private OutputStream mmOutputStream;
    private InputStream mmInputStream;
    private boolean btOpen = false;
    private volatile boolean stopWorker;


    public PrintService() {
        super("PrintService");
        mHandler = new Handler();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (action.equals(ACTION_PRINT) ||action.equals(ACTION_PRINT_RECEIPT)) {
                    final ModelFacturasParseada param1 = intent.getParcelableExtra(EXTRA_DOC);
                    ArrayList<ModelImpresora> printerItems = (ArrayList<ModelImpresora>) intent.getSerializableExtra(EXTRA_PRINTERS);
                    handleActionPrint(new Gson().toJson(param1), printerItems, action);

            } else if (ACTION_STOP.equals(action)) {
                handleActionStop();

            }
        }
    }

    @Override
    public void onDestroy() {
        if(btOpen)
        {
            try {
                closeBT();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        super.onDestroy();

    }

    /**
     * Handle action Foo in the provided background thread with the provided
     * parameters.
     */
    private void handleActionPrint(String jsonObject, ArrayList<ModelImpresora> printers, String action) {
        Log.d(TAG, "handleActionPrint: impresion");
//        handler.post(new PrintDocument(this,jsonObject,printers));

        Gson gson = new Gson();
        ModelFacturasParseada electronicDocument = gson.fromJson(jsonObject,ModelFacturasParseada.class);
        for (ModelImpresora printerItem:printers) {
            try {
                ArrayList<byte[]> bytes=null;
                if(action.equals(ACTION_PRINT))
                    bytes = PrinterFormat.printTicket(getApplicationContext(), electronicDocument, printerItem);
                else if(action.equals(ACTION_PRINT_RECEIPT))
                    bytes = PrinterFormat.printReceipt(getApplicationContext(), electronicDocument, printerItem);

                if(bytes!=null) {
                    switch (printerItem.getInterfaz()) {
                        case PRINTER_BLUETOOTH:
                            printBluetooth(bytes, printerItem);
                            break;
                        case PRINTER_ETHERNET:
                            printEthernet(bytes, printerItem);
                            break;

                    }
                }

            } catch (IOException | JSONException | ParserConfigurationException e) {
                e.printStackTrace();
            }
        }
        stopSelf();

    }

    /**
     * Handle action Baz in the provided background thread with the provided
     * parameters.
     */
    private void handleActionStop() {
        stopSelf();
    }



    private void printEthernet(ArrayList<byte[]> bytes, ModelImpresora printerItem)
    {
        SocketAddress socketAddress;
        Socket sock;
        try {
            socketAddress = new InetSocketAddress(printerItem.getDireccion(), 9100);
            sock = new Socket();
            sock.connect(socketAddress, 5000);
            PrintWriter oStream = new PrintWriter(sock.getOutputStream());
            for (byte[] cmd : bytes) {
                try {
                    sock.getOutputStream().write(cmd);
                    sock.getOutputStream().flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            sock.getOutputStream().write(new byte[]{0x0a});
            oStream.println("\n");

            oStream.close();
            sock.close();
        } catch (UnknownHostException e) {
            mHandler.post(new ShowToast(this,"error al conectar impresora"));
            e.printStackTrace();
        } catch (IOException e) {
            mHandler.post(new ShowToast(this,"error al conectar impresora"));
            e.printStackTrace();
        }
    }
    private void printBluetooth(ArrayList<byte[]> bytes, ModelImpresora printerItem)
    {
        boolean res = false;
        try {
            mmDevice = findBT(printerItem.getNombre());
            res = openBT();
            btOpen = res;
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (res) {
            if (bytes.size() > 0) {
                for (byte[] cmd : bytes) {
                    try {
                        sendData(cmd);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            mHandler.post(new ShowToast(this,"error al conectar impresora"));
        }


    }


    class ShowToast implements Runnable {
        private final Context mContext;
        private String mMessage;

        ShowToast(Context mContext, String message){
            this.mContext = mContext;
            this.mMessage = message;
        }

        public void run(){
            Toast.makeText(mContext,mMessage,Toast.LENGTH_SHORT).show();
        }
    }

    private BluetoothDevice findBT(String name) {
        try {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

            if(mBluetoothAdapter == null) {
                Toast.makeText(getApplicationContext(),"No hay bluetooth disponible", Toast.LENGTH_SHORT).show();
            }


            //revisar esto porque no sabemos si funciorá el llamado de una actividad desde un servicio
            if(!mBluetoothAdapter.isEnabled()) {
                Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivity(enableBluetooth);
            }


            Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

            if(pairedDevices.size() > 0) {
                for (BluetoothDevice device : pairedDevices) {
                    if (device.getName().equals(name)) {
                        return device;
                    }
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    // tries to open a connection to the bluetooth printer device
    private boolean openBT() throws IOException {
        boolean res = false;
        try {
            // Standard SerialPortService ID
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
//            resetConnection();
            mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);

            if (mmSocket!=null)
            {
                mmSocket.connect();
                mmOutputStream = mmSocket.getOutputStream();
                mmInputStream = mmSocket.getInputStream();
//                beginListenForData();
                res = true;
            }
        } catch (Exception e) {
            res = false;
            e.printStackTrace();
        }
        return res;
    }
    private void resetConnection() {
        if (mmInputStream != null) {
            try {mmInputStream.close();} catch (Exception e) {}
            mmInputStream = null;
        }

        if (mmOutputStream != null) {
            try {mmOutputStream.close();} catch (Exception e) {}
            mmOutputStream = null;
        }

        if (mmSocket != null) {
            try {mmSocket.close();} catch (Exception e) {}
            mmSocket = null;
        }

    }

    // this will send text data to be printed by the bluetooth printer
    private void sendData(byte[] bytes) throws IOException {
        try {
            mmOutputStream.write(bytes);
            mmOutputStream.flush();
            Thread.sleep(100);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // close the connection to bluetooth printer.
    private void closeBT() throws IOException {
        try {
            stopWorker = true;

            Thread.sleep(1000);
            mmOutputStream.close();
            mmInputStream.close();
            mmSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
