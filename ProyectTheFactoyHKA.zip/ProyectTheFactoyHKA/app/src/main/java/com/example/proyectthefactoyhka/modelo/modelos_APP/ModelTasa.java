package com.example.proyectthefactoyhka.modelo.modelos_APP;


import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ModelTasa extends RealmObject {

    @PrimaryKey
    private int id;

    private String porcentajeDeImpuesto;

    private double decimaDelImpuesto;

    public ModelTasa() {
    }


    public ModelTasa( String porcentajeDeImpuesto, double decimaDelImpuesto) {
        this.id = MyApplication.IdTasa.incrementAndGet();
        this.porcentajeDeImpuesto = porcentajeDeImpuesto;
        this.decimaDelImpuesto = decimaDelImpuesto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPorcentajeDeImpuesto() {
        return porcentajeDeImpuesto;
    }

    public void setPorcentajeDeImpuesto(String porcentajeDeImpuesto) {
        this.porcentajeDeImpuesto = porcentajeDeImpuesto;
    }

    public double getDecimaDelImpuesto() {
        return decimaDelImpuesto;
    }

    public void setDecimaDelImpuesto(double decimaDelImpuesto) {
        this.decimaDelImpuesto = decimaDelImpuesto;
    }
}
