package com.example.proyectthefactoyhka.ajustes.adaptador;

public class SettingListItem {

    private String settingTitle;
    private String settingSubtitle;

    public SettingListItem(String settingTitle, String settingSubtitle) {
        this.settingTitle = settingTitle;
        this.settingSubtitle = settingSubtitle;
    }

    public String getSettingTitle() {
        return settingTitle;
    }

    public void setSettingTitle(String settingTitle) {
        this.settingTitle = settingTitle;
    }

    public String getSettingSubtitle() {
        return settingSubtitle;
    }

    public void setSettingSubtitle(String settingSubtitle) {
        this.settingSubtitle = settingSubtitle;
    }
}
