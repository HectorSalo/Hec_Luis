package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelPeticionDePDF {

    @SerializedName("clave")
    @Expose
    private String clave;
    @SerializedName("documento")
    @Expose
    private String documento;
    @SerializedName("tipoArchivo")
    @Expose
    private String tipoArchivo;
    @SerializedName("usuario")
    @Expose
    private String usuario;


    public ModelPeticionDePDF(String clave, String documento, String tipoArchivo, String usuario) {
        this.clave = clave;
        this.documento = documento;
        this.tipoArchivo = tipoArchivo;
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTipoArchivo() {
        return tipoArchivo;
    }

    public void setTipoArchivo(String tipoArchivo) {
        this.tipoArchivo = tipoArchivo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
