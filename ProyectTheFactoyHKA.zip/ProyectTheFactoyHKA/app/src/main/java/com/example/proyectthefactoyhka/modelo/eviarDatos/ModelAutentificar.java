package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelAutentificar {

    @SerializedName("clave")
    @Expose
    private String clave;
    @SerializedName("ruc")
    @Expose
    private String ruc;
    @SerializedName("tipoAplicacion")
    @Expose
    private String tipoAplicacion;
    @SerializedName("usuario")
    @Expose
    private String usuario;


    public ModelAutentificar(String clave, String ruc, String tipoAplicacion, String usuario) {
        this.clave = clave;
        this.ruc = ruc;
        this.tipoAplicacion = tipoAplicacion;
        this.usuario = usuario;
    }


    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getTipoAplicacion() {
        return tipoAplicacion;
    }

    public void setTipoAplicacion(String tipoAplicacion) {
        this.tipoAplicacion = tipoAplicacion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
}
