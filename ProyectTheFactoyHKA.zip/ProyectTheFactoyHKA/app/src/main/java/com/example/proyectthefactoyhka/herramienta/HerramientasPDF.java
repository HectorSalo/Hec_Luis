package com.example.proyectthefactoyhka.herramienta;

import android.util.Base64;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class HerramientasPDF {


    public static final boolean guardarPdf(String base64String, String docNumber, String path) {


      File invoicePdf = new File(path, docNumber + ".pdf");

        byte[] pdfAsBytes = Base64.decode(base64String, 0);
        FileOutputStream os;
        try {
            os = new FileOutputStream(invoicePdf, false);
            os.write(pdfAsBytes);
            os.flush();
            os.close();

        } catch (FileNotFoundException e) {
            return false;
        } catch (IOException e) {
            return false;
        }
        return true;

    }
}
