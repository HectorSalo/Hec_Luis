package com.example.proyectthefactoyhka.ventana_principal;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.herramienta.FormatoMiles;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;

import java.util.ArrayList;
import java.util.Objects;


public class FoliosFragment extends Fragment {

    private OnFragmentInteractionListener mListener;

    private PieChart pieChart;
    private ProgressBar progressBar;

    public FoliosFragment() {
        // Required empty public constructor
    }

    public static FoliosFragment newInstance(String param1, String param2) {
        FoliosFragment fragment = new FoliosFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_folios, container, false);

        pieChart = view.findViewById(R.id.pie_folios);
        progressBar = view.findViewById(R.id.progressBar_folios);

        cargarFolios("4687");

        return view;
    }


    private void cargarFolios(String folios) {
        double foliosRestantes = FormatoMiles.getValue(folios);

        pieChart.setDescription(null);
        pieChart.setCenterText("Folios");
        pieChart.setCenterTextSize(24);
        pieChart.setDrawEntryLabels(false);
        pieChart.setRotationEnabled(false);

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        pieEntries.add(new PieEntry(5313, "Usados"));
        pieEntries.add(new PieEntry((float) foliosRestantes, "Disponibles"));

        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");
        pieDataSet.setValueTextSize(18);
        pieDataSet.setColors(ContextCompat.getColor(Objects.requireNonNull(getContext()), R.color.colorgrisoscuro), ContextCompat.getColor(getContext(), R.color.md_green_400));
        pieDataSet.setFormSize(16);
        PieData pieData = new PieData(pieDataSet);

        pieChart.setData(pieData);
        pieChart.invalidate();
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
