package com.example.proyectthefactoyhka.herramienta;

import com.example.proyectthefactoyhka.modelo.ModelUnidad;

import java.util.ArrayList;
import java.util.List;


public class ArrayGeneralApp {




    public static ArrayList<String> todosLosCorregimiento(){

        return new ArrayList<String>(){{
            add("Bastimientos");
            add("Bocas del toro (Cabecera)");
            add("Cauchero");
            add("Punta Laurel");
            add("Tierra Oscura");

        }};
    }


    public static ArrayList<String> todosLosDistritosPeru(){

        return new ArrayList<String>(){{
            add("ARAMANGO");
            add("BAGUA");
            add("COPALLIN");
            add("EL PARCO");
            add("IMAZA");
            add("LA PECA");
        }};
    }


    public static ArrayList<String> todasLasProvinciasPeru(){

        return new ArrayList<String>(){{
            add("BAGUA");
            add("BONGARA");
            add("CHACHAPOYAS");
            add("CONDORCANQUI");
            add("LUYA");
            add("RODRIGEZ DE MENDOZA");
            add("UTCUMBAMBA");

        }};
    }


    public static ArrayList<String> todosLosDepartamentosPeru(){

        return new ArrayList<String>(){{
            add("AMAZONAS");
            add("ANCASH");
            add("APURIMAC");
            add("AREQUIPA");
            add("AYACUCHO");
            add("CAJAMARCA");
            add("CUSCO");
            add("HUANCAVELICA");
            add("HUANUCO");
            add("ICA");
            add("JUNIN");
            add("LA LIBERTAD");
            add("LAMBAYEQUE");
            add("LIMA");
            add("LORETO");
            add("MADRE DE DIOS");
            add("MOQUEGUA");
            add("PASCO");
            add("PIURA");
            add("PRV. CONST. DEL CALLAO");
            add("PUNO");
            add("SAN MARTIN");
            add("TACNA");
            add("TUMBES");
            add("UCAYALI");
        }};
    }





    public static List<ModelUnidad> todasLasUnidades(){

        return new ArrayList<ModelUnidad>(){{
            add(new ModelUnidad(false,"Decámetro","dan"));
            add(new ModelUnidad(true,"Sin Unidad","NIU"));
            add(new ModelUnidad(false,"Milimetro","MMT"));
            add(new ModelUnidad(false,"Centimetro","CMT"));
            add(new ModelUnidad(false,"Decimetro","DMT"));
            add(new ModelUnidad(true,"Metro","MTR"));
            add(new ModelUnidad(false,"Kilómetro","KTM"));
            add(new ModelUnidad(true,"Pulgada","INH"));
            add(new ModelUnidad(true,"Pie","FOT"));
            add(new ModelUnidad(true,"Yarda","YRD"));
            add(new ModelUnidad(false,"Milimetro cuadrado","MMK"));
            add(new ModelUnidad(false,"Centimetro cuadrado","CMK"));
            add(new ModelUnidad(false,"Decímetro cuadrado","DMK"));
            add(new ModelUnidad(false,"Metro cuadrado","MTK"));
            add(new ModelUnidad(false,"Hectarea","HAR"));
            add(new ModelUnidad(false,"Kilometro cuadrado","KMK"));
            add(new ModelUnidad(false,"Acre","ACR"));
            add(new ModelUnidad(false,"Milla cuadrada","MIK"));
            add(new ModelUnidad(false,"Pulgada cuadrada","INK"));
            add(new ModelUnidad(false,"Pie cuadrado","FTK"));
            add(new ModelUnidad(false,"Yarda cuadrada","YDK"));
            add(new ModelUnidad(false,"Microlitro","4G"));
            add(new ModelUnidad(false,"Mililitro","MLT"));
            add(new ModelUnidad(false,"Centilitro","CLT"));
            add(new ModelUnidad(false,"Decilitro","DLT"));
            add(new ModelUnidad(true,"Litro","LTR"));
            add(new ModelUnidad(false,"Decalitro","A44"));
            add(new ModelUnidad(false,"Hectolitro","HLT"));
            add(new ModelUnidad(false,"Kilolitro","K6"));
            add(new ModelUnidad(false,"Milimetro cúbico","MMQ"));
            add(new ModelUnidad(false,"Centímetro cúbico","CMQ"));
            add(new ModelUnidad(false,"Decímetro cúbico","DMQ"));
            add(new ModelUnidad(false,"Metro cúbico",""));
            add(new ModelUnidad(true,"Galón EUA","GLL"));
            add(new ModelUnidad(false,"Onza liquida UK","OZI"));
            add(new ModelUnidad(false,"Galon UK","GLIN"));
            add(new ModelUnidad(false,"Pulgada cúbica","INQ"));
            add(new ModelUnidad(false,"Pie cúbico","FTQ"));
            add(new ModelUnidad(false,"Yarda cúbica","YDQ"));
            add(new ModelUnidad(false,"Microgramo","MC"));
            add(new ModelUnidad(false,"Centigramo",""));
            add(new ModelUnidad(false,"Decigramo","DG"));
            add(new ModelUnidad(true,"Gramo","GRM"));
            add(new ModelUnidad(false,"Decagramo","DJ"));
            add(new ModelUnidad(false,"Héctogramo","HGM"));
            add(new ModelUnidad(true,"Kilogramos","KGM"));
            add(new ModelUnidad(false,"Tonelada","STN"));
            add(new ModelUnidad(false,"Grain","GRN"));
            add(new ModelUnidad(true,"Onza","OZA"));
            add(new ModelUnidad(true,"Libra","LBR"));
            add(new ModelUnidad(true,"Unidad","ONE"));
            add(new ModelUnidad(true,"BTU","BTU"));
            add(new ModelUnidad(true,"Bit","A99"));
            add(new ModelUnidad(false,"Bit por segundo","B10"));
            add(new ModelUnidad(false,"Kilobits","C37"));
            add(new ModelUnidad(false,"Kilobits por segundo","C74"));
            add(new ModelUnidad(true,"Kibibit","C21"));
            add(new ModelUnidad(false,"Megabit","D36"));
            add(new ModelUnidad(false,"Megabit por segundo","E20"));
            add(new ModelUnidad(false,"Mebibit","D11"));
            add(new ModelUnidad(false,"Gigabit","B68"));
            add(new ModelUnidad(false,"Gigabit por segundo","B80"));
            add(new ModelUnidad(false,"Gibibit","B30"));
            add(new ModelUnidad(false,"Petabit","E78"));
            add(new ModelUnidad(false,"Byte","AD"));
            add(new ModelUnidad(false,"Kilobyte","2P"));
            add(new ModelUnidad(false,"Mbyte","4L"));
            add(new ModelUnidad(false,"Gigabyte","E34"));
            add(new ModelUnidad(false,"Terabyte","E35"));
            add(new ModelUnidad(false,"Petabyte","E36"));
            add(new ModelUnidad(false,"Exbibyte","E59"));
            add(new ModelUnidad(false,"Kibibyte","E64"));
            add(new ModelUnidad(false,"Mebibyte","E63"));
            add(new ModelUnidad(false,"Gibibyte","E62"));
            add(new ModelUnidad(false,"Tebibyte","E61"));
            add(new ModelUnidad(false,"Píxel","E37"));
            add(new ModelUnidad(false,"Megapíxeles","E38"));
            add(new ModelUnidad(false,"Puntos por pulgada","E39"));
            add(new ModelUnidad(false,"Watt","WTT"));
            add(new ModelUnidad(false,"Kilowatt","KWT"));
            add(new ModelUnidad(false,"Megawatt","MAW"));
            add(new ModelUnidad(false,"Gigawatt","A90"));
            add(new ModelUnidad(false,"Terawatt","D31"));
            add(new ModelUnidad(false,"Watt hora","WHR"));
            add(new ModelUnidad(false,"Kilowatt hora","KWH"));
            add(new ModelUnidad(false,"Megawatt hora","MWH"));
            add(new ModelUnidad(false,"Gigawatt hora","GWH"));
            add(new ModelUnidad(false,"Terawatt hora","D32"));
            add(new ModelUnidad(false,"Voltio-amperio","D46"));
            add(new ModelUnidad(false,"Kilooltio-amperio","KVA"));
            add(new ModelUnidad(false,"Megavoltio-amperio","MVA"));
            add(new ModelUnidad(false,"Denier","Denier"));
            add(new ModelUnidad(false,"Año","ANN"));
            add(new ModelUnidad(false,"Año comun","L95"));
            add(new ModelUnidad(false,"Mes","MON"));
            add(new ModelUnidad(false,"Día","DAY"));
            add(new ModelUnidad(false,"Hora","HUR"));
            add(new ModelUnidad(false,"Minuto","MIN"));
            add(new ModelUnidad(false,"Segundo","SEC"));
            add(new ModelUnidad(false,"Semana","WEE"));
            add(new ModelUnidad(false,"Actividad","Actividad"));
            add(new ModelUnidad(false,"Hora de trabajo","Hora trabajo"));
            add(new ModelUnidad(false,"Horas extra","Hora extra"));
            add(new ModelUnidad(false,"Mes de trabajo","Mes trabajo"));
            add(new ModelUnidad(false,"Personas","Personas"));
            add(new ModelUnidad(false,"Puesto de trabajo","Puesto"));


        }};
    }



}
