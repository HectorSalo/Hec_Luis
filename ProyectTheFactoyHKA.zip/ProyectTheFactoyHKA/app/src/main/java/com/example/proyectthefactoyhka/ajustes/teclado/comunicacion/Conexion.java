package com.example.proyectthefactoyhka.ajustes.teclado.comunicacion;

public interface Conexion {

    void enviarDatos(String datos,String codigo, int color);




}
