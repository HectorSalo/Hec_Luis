package com.example.proyectthefactoyhka.catalogo_cliente.conexion;


import com.example.proyectthefactoyhka.modelo.ModelCliente;


public interface Conexion_Cliente {

    void generarFacturadeCliente(ModelCliente datoDelCliente);


    void llamarVentanaEditarCliente(ModelCliente datoDelCliente);

    void detallesDelCliente(ModelCliente datoDelCliente);

    void borrarCliente(ModelCliente datoDelCliente);

}
