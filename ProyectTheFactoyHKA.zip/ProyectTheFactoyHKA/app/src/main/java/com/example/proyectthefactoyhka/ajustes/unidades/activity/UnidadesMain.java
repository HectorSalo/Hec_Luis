package com.example.proyectthefactoyhka.ajustes.unidades.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.unidades.adaptadores.UnidadesAdaptador;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.List;
import io.realm.Realm;
import io.realm.RealmList;

public class UnidadesMain extends AppCompatActivity {


    private Realm realm;
    private RealmList<ModelUnidad> listaunidades;
    private RecyclerView mi_recicler_view_unidad;
    private RecyclerView.LayoutManager miLayoutManager;
    private UnidadesAdaptador miAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unidades);

        mostrarToolbar();
        cast();
        recibirDatosDeOtrosActivitys();
        funcionDelAdaptador(listaunidades);




    }




    private void recibirDatosDeOtrosActivitys() {
        Bundle extra = getIntent().getExtras();
        if (extra != null) {
             int idUsuario= extra.getInt(getString(R.string.enviar_usuario));

            baseDeDatos(idUsuario);
        }

    }


    private void baseDeDatos(int idUsuario) {
        realm = Realm.getDefaultInstance();
        ModelUsuario usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        if (usuarios !=null)
           listaunidades = usuarios.getDatosunidad();

    }


    private void cast() {
        mi_recicler_view_unidad = findViewById(R.id.mi_recicler_view_unidad);
        miLayoutManager = new LinearLayoutManager(this);


    }


    private void funcionDelAdaptador(List<ModelUnidad> unidades) {
        miAdapter = new UnidadesAdaptador(unidades, R.layout.cardview_unidades, this, new UnidadesAdaptador.MyItemClickUnidad() {
            @Override
            public void onItem(ModelUnidad unidad, int position) {

                ModelUnidad dato =listaunidades.get(position);
                boolean verificacion = true;

                if (dato!=null){
                    if (dato.isCheck()) {
                        verificacion = false;
                    }

                    realm.beginTransaction();
                    dato.setCheck(verificacion);
                    realm.commitTransaction();

                miAdapter.notifyDataSetChanged();
                }

            }
        });




        mi_recicler_view_unidad.setHasFixedSize(true);
        mi_recicler_view_unidad.setLayoutManager(miLayoutManager);
        mi_recicler_view_unidad.setItemAnimator(new DefaultItemAnimator());
        mi_recicler_view_unidad.setAdapter(miAdapter);
    }



    //metodo que  configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_unidades);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        UnidadesMain.this.setTitle(R.string.toolbar_unidades);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
