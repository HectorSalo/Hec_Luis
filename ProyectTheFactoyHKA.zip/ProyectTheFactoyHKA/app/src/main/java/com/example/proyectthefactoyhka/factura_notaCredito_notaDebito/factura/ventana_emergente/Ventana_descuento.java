package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.ventana_emergente;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.conexion_factura.Conexion_factura;
import com.example.proyectthefactoyhka.modelo.eviarDatos.IGV;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ISC;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDescuento;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;
import java.util.Locale;


public class Ventana_descuento {

    private Dialog dialog;
    private EditText edi_descuento;
    private Button bt_aplicar_desc;
    private Conexion_factura conexion_factura;
    private Double montoObtenido;
    private int posicion;
    private double baseImponibleDelDescuento;
    private double montoDescontado;

    public Ventana_descuento(Context context, final ModelFacturacion datosFactura , int posicion, Conexion_factura conexion_factura) {

        configuracionDelaVentana(context);
        cast();
        this.conexion_factura=conexion_factura;
        this.posicion=posicion;
         montoObtenido = Double.parseDouble(datosFactura.getValorUnitarioBI());

        bt_aplicar_desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 baseImponibleDelDescuento = (Double.parseDouble(edi_descuento.getText().toString())/100)*montoObtenido;
                 montoDescontado =montoObtenido-baseImponibleDelDescuento;

                generarFactura(datosFactura,montoDescontado);

            }
        });


        dialog.show();

    }




    private void generarFactura(ModelFacturacion factura, double precioUnitario) {

        ModelFacturacion producto = new ModelFacturacion();
        //accion el cual obtiene los datos tanto de cantidad y de precio los transforma en variable Double y los multiplica
        double cantidadObtenida = Double.parseDouble(factura.getCantidad());


                double tasaIgv= Double.parseDouble(factura.getiGV().getPorcentaje())/100;

                double montoImpuestoIGV = precioUnitario * tasaIgv;

                // Tasa de impuesto ISC


               double totalImpuestosItem;

                if (factura.getiSC()!=null){

                double tasaISC = (Double.parseDouble(factura.getiSC().getPorcentaje())) / 100;

                double baseImponibleISC = precioUnitario / (1 + tasaISC);

                double montoImpuestoISC = baseImponibleISC * tasaISC;

                 totalImpuestosItem = (montoImpuestoIGV + montoImpuestoISC) * cantidadObtenida;


                    ISC isc = new ISC(String.format(Locale.US, "%.2f", baseImponibleISC),
                            String.format(Locale.US, "%.2f", montoImpuestoISC),
                            factura.getiSC().getPorcentaje(),
                            "01");
                    producto.setiSC(isc);

                }else {

                    totalImpuestosItem = (montoImpuestoIGV + 0) * cantidadObtenida;

                }

                double precioTotalItem = precioUnitario + montoImpuestoIGV;


                IGV igv = new IGV(String.format(Locale.US, "%.2f", precioUnitario),
                        String.format(Locale.US, "%.2f", montoImpuestoIGV),
                        factura.getiGV().getPorcentaje(),
                        "10");




                  // ModelDescuento descuento = new ModelDescuento(,"00",,edi_descuento.getText().toString());

                ModelDescuento descuento = new ModelDescuento(precioUnitario+"","00",baseImponibleDelDescuento+"",edi_descuento.getText().toString());

                producto.setCantidad(String.format(Locale.US,"%.2f",cantidadObtenida));
                producto.setDescripcion(factura.getDescripcion());
                producto.setiGV(igv);
                producto.setMontoTotalImpuestoItem( String.format(Locale.US, "%.2f", totalImpuestosItem));
                producto.setNumeroOrden(factura.getNumeroOrden());
                producto.setPrecioVentaUnitarioItem(String.format(Locale.US,"%.2f",precioTotalItem));
                producto.setUnidadMedida(factura.getUnidadMedida());
                producto.setValorUnitarioBI(String.format(Locale.US,"%.2f",precioUnitario));
                producto.setValorVentaItemQxBI(String.format(Locale.US,"%.2f",precioUnitario*cantidadObtenida));
                producto.setDescuento(descuento);

               conexion_factura.aplicarPorcentaje(posicion,producto,baseImponibleDelDescuento);
                dialog.dismiss();

            }







    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {
        edi_descuento=dialog.findViewById(R.id.edi_descuento);
        bt_aplicar_desc=dialog.findViewById(R.id.bt_aplicar_desc);
    }

    //configuracion de la ventana para poder ser visualizada
    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_descuento);

    }


}
