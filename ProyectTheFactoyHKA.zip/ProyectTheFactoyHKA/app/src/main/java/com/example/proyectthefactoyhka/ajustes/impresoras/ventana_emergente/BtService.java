package com.example.proyectthefactoyhka.ajustes.impresoras.ventana_emergente;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.widget.Toast;

import java.util.Set;


/**
 * Created by OAVENDANO on 04/30/2018.
 */

public class BtService {



    public Set<BluetoothDevice> listPairedBtDevices(Context context, BluetoothAdapter mBluetoothAdapter) {
        Set<BluetoothDevice> pairedDevices=null;
        try {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

            if(mBluetoothAdapter == null) {
                Toast.makeText(context, "No hay bluetooth disponible", Toast.LENGTH_SHORT).show();            }

            if(!mBluetoothAdapter.isEnabled()) {
                /*
                Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBluetooth, 0);
                */
                Toast.makeText(context, "Bluetooth Desactivado", Toast.LENGTH_SHORT).show();

            }

            pairedDevices = mBluetoothAdapter.getBondedDevices();

        }catch(Exception e){
            e.printStackTrace();
        }
        return pairedDevices;
    }

}
