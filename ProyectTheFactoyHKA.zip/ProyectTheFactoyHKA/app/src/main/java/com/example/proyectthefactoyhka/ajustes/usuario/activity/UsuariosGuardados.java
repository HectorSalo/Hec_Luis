package com.example.proyectthefactoyhka.ajustes.usuario.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.usuario.adaptador.UsuarioAdaptador;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;


import io.realm.Realm;
import io.realm.RealmResults;

public class UsuariosGuardados extends AppCompatActivity {

    private Realm realm;
    private RealmResults<ModelUsuario> usuario;

    private TextView cant_usuario_guardados;

    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private RecyclerView.Adapter miAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios_guardados);
        realm = Realm.getDefaultInstance();
        usuario =realm.where(ModelUsuario.class).findAll();



        mostrarToolbar();
        cast();
        funcionDelAdaptador();


        cant_usuario_guardados.setText(usuario.size()+"");

    }

    private void cast() {

        miRecicler=findViewById(R.id.mi_recicler_usuarios);
        miLayoutManager = new LinearLayoutManager(this);
        cant_usuario_guardados=findViewById(R.id.cant_usuario_guardados);

    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar los productos
    private void funcionDelAdaptador() {
        miAdapter = new UsuarioAdaptador(usuario,R.layout.cardview_usuario);
        miAdapter.notifyDataSetChanged();
        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);

    }


    //configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_usuario);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        UsuariosGuardados.this.setTitle(R.string.toolbar_usuario);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
