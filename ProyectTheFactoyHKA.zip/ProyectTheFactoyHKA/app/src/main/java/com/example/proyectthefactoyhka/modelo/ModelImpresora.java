package com.example.proyectthefactoyhka.modelo;


import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import java.io.Serializable;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class ModelImpresora extends RealmObject implements Serializable {

    @PrimaryKey
    private int id;
    @Required
    private String interfaz;
    @Required
    private String nombre;
    @Required
    private String direccion;
    @Required
    private String anchoPapel;
    @Required
    private String caracterPorLinea;
    @Required
    private String gaveta;
    @Required
    private String paginaDeCodigo;
    @Required
    private String tipoDeQR;
    @Required
    private String logo;
    private boolean estado;

    public ModelImpresora() {
    }

    public ModelImpresora(ModelImpresora impresora){
        this.id = impresora.getId();
        this.interfaz = impresora.getInterfaz();
        this.nombre = impresora.getNombre();
        this.direccion = impresora.getDireccion();
        this.anchoPapel = impresora.getAnchoPapel();
        this.caracterPorLinea = impresora.getCaracterPorLinea();
        this.gaveta = impresora.getGaveta();
        this.paginaDeCodigo = impresora.getPaginaDeCodigo();
        this.tipoDeQR = impresora.getTipoDeQR();
        this.logo = impresora.getLogo();
        this.estado = impresora.isEstado();
    }
    public ModelImpresora(String interfaz, String nombre, String direccion, String anchoPapel, String caracterPorLinea, String gaveta, String paginaDeCodigo, String tipoDeQR, String logo, boolean estado) {
        this.id = MyApplication.IdImpr.incrementAndGet();
        this.interfaz = interfaz;
        this.nombre = nombre;
        this.direccion = direccion;
        this.anchoPapel = anchoPapel;
        this.caracterPorLinea = caracterPorLinea;
        this.gaveta = gaveta;
        this.paginaDeCodigo = paginaDeCodigo;
        this.tipoDeQR = tipoDeQR;
        this.logo = logo;
        this.estado = estado;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInterfaz() {
        return interfaz;
    }

    public void setInterfaz(String interfaz) {
        this.interfaz = interfaz;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getAnchoPapel() {
        return anchoPapel;
    }

    public void setAnchoPapel(String anchoPapel) {
        this.anchoPapel = anchoPapel;
    }

    public String getCaracterPorLinea() {
        return caracterPorLinea;
    }

    public void setCaracterPorLinea(String caracterPorLinea) {
        this.caracterPorLinea = caracterPorLinea;
    }

    public String getGaveta() {
        return gaveta;
    }

    public void setGaveta(String gaveta) {
        this.gaveta = gaveta;
    }

    public String getPaginaDeCodigo() {
        return paginaDeCodigo;
    }

    public void setPaginaDeCodigo(String paginaDeCodigo) {
        this.paginaDeCodigo = paginaDeCodigo;
    }

    public String getTipoDeQR() {
        return tipoDeQR;
    }

    public void setTipoDeQR(String tipoDeQR) {
        this.tipoDeQR = tipoDeQR;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}