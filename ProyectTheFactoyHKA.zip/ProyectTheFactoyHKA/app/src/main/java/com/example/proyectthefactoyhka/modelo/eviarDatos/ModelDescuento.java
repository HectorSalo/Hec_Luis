package com.example.proyectthefactoyhka.modelo.eviarDatos;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ModelDescuento implements Parcelable {

    @SerializedName("baseImponible")
    private String baseImponible;

    @SerializedName("codigo")
    private String codigo;

    @SerializedName("monto")
    private String monto;

    @SerializedName("porcentaje")
    private String porcentaje;

    public ModelDescuento(String baseImponible, String codigo, String monto, String porcentaje) {
        this.baseImponible = baseImponible;
        this.codigo = codigo;
        this.monto = monto;
        this.porcentaje = porcentaje;
    }

    protected ModelDescuento(Parcel in) {
        baseImponible = in.readString();
        codigo = in.readString();
        monto = in.readString();
        porcentaje = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(baseImponible);
        dest.writeString(codigo);
        dest.writeString(monto);
        dest.writeString(porcentaje);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelDescuento> CREATOR = new Creator<ModelDescuento>() {
        @Override
        public ModelDescuento createFromParcel(Parcel in) {
            return new ModelDescuento(in);
        }

        @Override
        public ModelDescuento[] newArray(int size) {
            return new ModelDescuento[size];
        }
    };

    public String getBaseImponible() {
        return baseImponible;
    }

    public void setBaseImponible(String baseImponible) {
        this.baseImponible = baseImponible;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(String porcentaje) {
        this.porcentaje = porcentaje;
    }
}
