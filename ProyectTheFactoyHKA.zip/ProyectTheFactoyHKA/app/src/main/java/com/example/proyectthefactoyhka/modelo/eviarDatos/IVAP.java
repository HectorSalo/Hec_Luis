package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.SerializedName;

public class IVAP {

    @SerializedName("baseImponible")
    private String baseImponible;

    @SerializedName("monto")
    private String monto;

    @SerializedName("porcentaje")
    private String porcentaje;

    @SerializedName("tipo")
    private String tipo;

    public IVAP(String baseImponible, String monto, String porcentaje, String tipo) {
        this.baseImponible = baseImponible;
        this.monto = monto;
        this.porcentaje = porcentaje;
        this.tipo = tipo;
    }

    public String getBaseImponible() {
        return baseImponible;
    }

    public void setBaseImponible(String baseImponible) {
        this.baseImponible = baseImponible;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(String porcentaje) {
        this.porcentaje = porcentaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
