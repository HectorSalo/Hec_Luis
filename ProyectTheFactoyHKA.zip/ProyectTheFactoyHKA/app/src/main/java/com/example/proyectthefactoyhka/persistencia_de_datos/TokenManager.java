package com.example.proyectthefactoyhka.persistencia_de_datos;

import android.content.SharedPreferences;

import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerToken;

public class TokenManager {

    public static final String SHARED_PREFERENCES = "SHARED_PREFERENCES";
    private static final String SHARED_PREFERENCES_TOKEN_DE_ACCESO = "SHARED_PREFERENCES_TOKEN_DE_ACCESO";
    private static final String SHARED_PREFERENCES_REFRESCAR_TOKEN = "SHARED_PREFERENCES_REFRESCAR_TOKEN";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private static TokenManager INSTANCE = null;

    private TokenManager(SharedPreferences sharedPreferences){
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
    }

    public static synchronized TokenManager getIntance(SharedPreferences sharedPreferences){
        if(INSTANCE == null){
            INSTANCE = new TokenManager(sharedPreferences);
        }
        return INSTANCE;
    }

    public void guardarToken(ModelObtenerToken token){
        editor.putString(SHARED_PREFERENCES_TOKEN_DE_ACCESO, token.getToken()).commit();
     //   editor.putString(SHARED_PREFERENCES_REFRESCAR_TOKEN, token.getRefreshToken()).commit();
    }

    public ModelObtenerToken obtenerTokeDeAcceso(){
        ModelObtenerToken token = new ModelObtenerToken();
        token.setToken(sharedPreferences.getString(SHARED_PREFERENCES_TOKEN_DE_ACCESO, null));
     //   token.setRefreshToken(sharedPreferences.getString(SHARED_PREFERENCES_REFRESCAR_TOKEN, null));
        return token;
    }

}
