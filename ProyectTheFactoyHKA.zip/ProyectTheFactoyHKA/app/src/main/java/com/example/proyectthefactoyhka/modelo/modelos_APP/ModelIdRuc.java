package com.example.proyectthefactoyhka.modelo.modelos_APP;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class ModelIdRuc extends RealmObject implements Parcelable {

    @PrimaryKey
    private int id;

    private String ruc;

    private RealmList<ModelUsuario> listaUsuarios;

    public ModelIdRuc() {
    }

    public ModelIdRuc(String ruc, RealmList<ModelUsuario> listaUsuarios) {
        this.id = MyApplication.IdRuc.incrementAndGet();
        this.ruc = ruc;
        this.listaUsuarios = listaUsuarios;
    }

    protected ModelIdRuc(Parcel in) {
        id = in.readInt();
        ruc = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(ruc);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelIdRuc> CREATOR = new Creator<ModelIdRuc>() {
        @Override
        public ModelIdRuc createFromParcel(Parcel in) {
            return new ModelIdRuc(in);
        }

        @Override
        public ModelIdRuc[] newArray(int size) {
            return new ModelIdRuc[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public RealmList<ModelUsuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(RealmList<ModelUsuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
}
