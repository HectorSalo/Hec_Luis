package com.example.proyectthefactoyhka.modelo.modelos_APP;

import io.realm.RealmObject;

public class ModelMunicipios extends RealmObject {

    private String id;
    private String codigo_municipio;
    private String codigo_departamento;
    private String municipio;

    public ModelMunicipios() {
    }

    public ModelMunicipios(String id, String codigo_municipio, String codigo_departamento, String municipio) {
        this.id = id;
        this.codigo_municipio = codigo_municipio;
        this.codigo_departamento = codigo_departamento;
        this.municipio = municipio;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo_municipio() {
        return codigo_municipio;
    }

    public void setCodigo_municipio(String codigo_municipio) {
        this.codigo_municipio = codigo_municipio;
    }

    public String getCodigo_departamento() {
        return codigo_departamento;
    }

    public void setCodigo_departamento(String codigo_departamento) {
        this.codigo_departamento = codigo_departamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }
}
