package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModelRecibirProductos  {

    @SerializedName("id")
    @Expose
    private String id;

    @SerializedName("codigo1")
    @Expose
    private String codigo1;
    @SerializedName("codigo2")
    @Expose
    private String codigo2;
    @SerializedName("codigo3")
    @Expose
    private String codigo3;
    @SerializedName("descripcion")
    @Expose
    private String descripcion;
    @SerializedName("impuestos")
    @Expose
    private List<ModelImpuestos> impuestos = null;
    @SerializedName("precio1")
    @Expose
    private Double precio1;
    @SerializedName("precio2")
    @Expose
    private Double precio2;
    @SerializedName("tipo")
    @Expose
    private String tipo;
    @SerializedName("unidad")
    @Expose
    private String unidad;

    public ModelRecibirProductos(String id, String codigo1, String codigo2, String codigo3, String descripcion, List<ModelImpuestos> impuestos, Double precio1, Double precio2, String tipo, String unidad) {
        this.id = id;
        this.codigo1 = codigo1;
        this.codigo2 = codigo2;
        this.codigo3 = codigo3;
        this.descripcion = descripcion;
        this.impuestos = impuestos;
        this.precio1 = precio1;
        this.precio2 = precio2;
        this.tipo = tipo;
        this.unidad = unidad;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo1() {
        return codigo1;
    }

    public void setCodigo1(String codigo1) {
        this.codigo1 = codigo1;
    }

    public String getCodigo2() {
        return codigo2;
    }

    public void setCodigo2(String codigo2) {
        this.codigo2 = codigo2;
    }

    public String getCodigo3() {
        return codigo3;
    }

    public void setCodigo3(String codigo3) {
        this.codigo3 = codigo3;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<ModelImpuestos> getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(List<ModelImpuestos> impuestos) {
        this.impuestos = impuestos;
    }

    public Double getPrecio1() {
        return precio1;
    }

    public void setPrecio1(Double precio1) {
        this.precio1 = precio1;
    }

    public Double getPrecio2() {
        return precio2;
    }

    public void setPrecio2(Double precio2) {
        this.precio2 = precio2;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }
}
