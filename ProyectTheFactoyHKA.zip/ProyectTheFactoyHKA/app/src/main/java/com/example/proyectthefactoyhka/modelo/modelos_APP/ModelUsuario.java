package com.example.proyectthefactoyhka.modelo.modelos_APP;


import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class ModelUsuario  extends RealmObject {

    @PrimaryKey
    private int id;
    @Required
    private String usuario;
    @Required
    private String clave;


    private String dv;
    @Required
    private String serial;

    private RealmList<ModelProducto> datos_productos;

    private RealmList<ModelCliente> datos_clientes;

    private ModelOpciones opciones;

    private RealmList<ModelImpresora> datos_impresoras;

    private ModelTeclado teclado;

   private RealmList<ModelUnidad> datosunidad;

   private RealmList<ModelFacturasParseada> lista_de_facturas;



    public ModelUsuario() {
    }


    public ModelUsuario(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }

    public ModelUsuario(String usuario, String clave, String serial, RealmList<ModelUnidad> datosunidad) {
        this.id = MyApplication.IdUsu.incrementAndGet();
        this.usuario = usuario;
        this.clave = clave;

     //   this.dv = dv;
        this.serial = serial;
        this.datos_productos = new RealmList<ModelProducto>();
        this.datos_clientes = new RealmList<ModelCliente>();
        this.opciones = new ModelOpciones();
        this.teclado = new ModelTeclado(false);
        this.datos_impresoras = new RealmList<ModelImpresora>();
        this.datosunidad = datosunidad;
        this.lista_de_facturas = new RealmList<ModelFacturasParseada>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }


    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public RealmList<ModelProducto> getDatos_producto() {
        return datos_productos;
    }

    public void setDatos_producto(RealmList<ModelProducto> datos_productos) {
        this.datos_productos = datos_productos;
    }

    public RealmList<ModelCliente> getDatos_clientes() {
        return datos_clientes;
    }

    public void setDatos_clientes(RealmList<ModelCliente> datos_clientes) {
        this.datos_clientes = datos_clientes;
    }

    public ModelOpciones getOpciones() {
        return opciones;
    }

    public void setOpciones(ModelOpciones opciones) {
        this.opciones = opciones;
    }

    public RealmList<ModelImpresora> getDatos_impresoras() {
        return datos_impresoras;
    }

    public void setDatos_impresoras(RealmList<ModelImpresora> datos_impresoras) {
        this.datos_impresoras = datos_impresoras;
    }

    public ModelTeclado getTeclado() {
        return teclado;
    }

    public void setTeclado(ModelTeclado teclado) {
        this.teclado = teclado;
    }


    public RealmList<ModelProducto> getDatos_productos() {
        return datos_productos;
    }

    public void setDatos_productos(RealmList<ModelProducto> datos_productos) {
        this.datos_productos = datos_productos;
    }

    public RealmList<ModelUnidad> getDatosunidad() {
        return datosunidad;
    }

    public void setDatosunidad(RealmList<ModelUnidad> datosunidad) {
        this.datosunidad = datosunidad;
    }

    public RealmList<ModelFacturasParseada> getLista_de_facturas() {
        return lista_de_facturas;
    }

    public void setLista_de_facturas(RealmList<ModelFacturasParseada> lista_de_facturas) {
        this.lista_de_facturas = lista_de_facturas;
    }
}
