package com.example.proyectthefactoyhka.modelo.recibirDatos;

public class ModelImpuestos {
}
