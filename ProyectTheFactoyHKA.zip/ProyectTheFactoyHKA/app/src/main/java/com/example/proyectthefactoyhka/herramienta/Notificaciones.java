package com.example.proyectthefactoyhka.herramienta;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.content.FileProvider;
import android.widget.RemoteViews;

import com.example.proyectthefactoyhka.R;

import java.io.File;

public class Notificaciones {

    public static void generar(Context contexto, String numeroDocumento, String rutaArchivo){

        int notificationID = 1;
        File file = new File(rutaArchivo,numeroDocumento+ ".pdf");
        file.deleteOnExit();
        Uri path2 = FileProvider.getUriForFile(contexto, contexto.getApplicationContext().getPackageName() + ".provider", file);

        Intent openFile = new Intent(Intent.ACTION_VIEW);
        openFile.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        openFile.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        openFile.setDataAndType(path2, "application/pdf");
        PendingIntent pendingIntent = PendingIntent.getActivity(contexto, 0, openFile, 0);

        Intent intentdel = new Intent(contexto, NotificationBroadcastReceiver.class);
        intentdel.setAction("notification_cancelled");
        intentdel.putExtra("docNumber",numeroDocumento);
        PendingIntent pendingIntentdelete = PendingIntent.getBroadcast(contexto.getApplicationContext(), 0, intentdel, PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationManager nm = (NotificationManager) contexto.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)
            nm.cancel(notificationID);


        String CHANNEL_ID = "my_channel_01";// The id of the channel.
        CharSequence name = "canal";// The user-visible name of the channel.
        int importance = NotificationManager.IMPORTANCE_NONE;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);
            nm.createNotificationChannel(mChannel);
        }

        RemoteViews contentView = new RemoteViews(contexto.getPackageName(), R.layout.layout_notificacion);
        contentView.setImageViewResource(R.id.image, R.mipmap.thefactory);
        contentView.setTextViewText(R.id.titulo, numeroDocumento);
        contentView.setTextViewText(R.id.detalles, "Ver mas detalles");
        Notification noti = new NotificationCompat.Builder(contexto,CHANNEL_ID)
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.drawable.ic_file_download_black_24dp)
                .setContent(contentView)
                .setAutoCancel(true)
                .setDeleteIntent(pendingIntentdelete)
                .build();

        nm.notify(1, noti);


    }
}
