package com.example.proyectthefactoyhka.catalogo_producto.comunicacion;


import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;

public interface Conexion_Producto {

    void generarFacturadeProducto(ModelProducto producto);

    void llamarVentanaEditarProducto(ModelProducto producto);

    void detallesDelProducto(ModelProducto producto);

    void borrarProducto(ModelProducto producto);

}
