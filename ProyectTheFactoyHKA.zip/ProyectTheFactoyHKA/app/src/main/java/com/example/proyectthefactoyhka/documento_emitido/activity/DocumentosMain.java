package com.example.proyectthefactoyhka.documento_emitido.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.acerca_de.Acerca_de;
import com.example.proyectthefactoyhka.ajustes.Ajustes;
import com.example.proyectthefactoyhka.ajustes.unidades.activity.UnidadesMain;
import com.example.proyectthefactoyhka.catalogo_cliente.activity.ClientesMain;
import com.example.proyectthefactoyhka.catalogo_producto.activity.ProductosMain;
import com.example.proyectthefactoyhka.documento_emitido.adaptador.DocumentoEmitidoAdaptador;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity.Factura;
import com.example.proyectthefactoyhka.herramienta.Conexion_calendario;
import com.example.proyectthefactoyhka.herramienta.Ventana_calendario;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeDocumentos;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelDocumento;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerDocumentos;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.example.proyectthefactoyhka.ventana_principal.PrincipalActivity;
import com.google.android.material.internal.NavigationMenu;
import com.nbsp.materialfilepicker.MaterialFilePicker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.github.yavski.fabspeeddial.FabSpeedDial;
import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmQuery;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class DocumentosMain extends AppCompatActivity implements Conexion_calendario, TextWatcher, View.OnClickListener {

    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private ModelUsuario usuarios;
    private FabSpeedDial fabt_menu;
    private EditText edi_panel_calendario;
    private View panel_busqueda;
    private final int CODIGO_PERMISO = 946;
    private int idUsuario;
    private DatosTemporales datosTemporales;
    private RealmList<ModelFacturasParseada> listaDeFacturasParseada;
    private ModelFacturasParseada facturasParseada;
    private ProgressBar visDoc_progressBar;
    private Date fechaInicio;
    private List<ModelDocumento> listaDocumentos;
    private DocumentoEmitidoAdaptador miAdapter;
    private DrawerLayout drawerLayout;
    private LinearLayout nav_view_layout_catalogo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_documentos_main);

        mostrarToolbar();
        cast();
        recibirDatosDeOtrosActivitys();
        botonFlotanteMenu();


        servicioRetrofit2();

    }

    private void servicioRetrofit2() {

        esperaDeDatos();
        final String fechaInicioRequest, fechaFinRequest;
        final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US);
        SimpleDateFormat requestDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);

        Calendar calendar = Calendar.getInstance();

        //Verificamos si la fecha de inicio no es nula
        if(fechaInicio != null){
                calendar.setTime(fechaInicio);
                //si hay una fecha de inicio, quiere decir que se llegó al último registro del recyclerView, entonces la fecha de
                //inicio ha de ser un par de segundos antes de la fecha del último registro
                calendar.add(Calendar.SECOND, -2);
        }else{
            fechaInicio = new Date();
            calendar.setTime(fechaInicio);
        }


        fechaFinRequest = requestDateFormat.format(calendar.getTime());
        calendar.add(Calendar.DAY_OF_YEAR, -2);
        fechaInicioRequest = requestDateFormat.format(calendar.getTime());

        //Asignamos el valor de la fecha final del request a la variable fechaInicio, esto en caso de que, al consultar el rango solicitado la lista que se devuelva sea vacía
        fechaInicio = calendar.getTime();


        final ModelPeticionDeDocumentos documentos = new ModelPeticionDeDocumentos(fechaFinRequest, fechaInicioRequest, "100", "0", datosTemporales.odtenerRuc(), "", "00", datosTemporales.obtenerTokeDeAcceso().getToken());

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);

        Call<ModelObtenerDocumentos> obtenerDocumentos = service.peticionDocumentos(documentos);

        obtenerDocumentos.enqueue(new Callback<ModelObtenerDocumentos>() {

            ModelObtenerDocumentos doc = new ModelObtenerDocumentos();

            @Override
            public void onResponse(Call<ModelObtenerDocumentos> call, Response<ModelObtenerDocumentos> response) {



                doc = response.body();

                if (doc.getDocumento() != null) {

                    String fechaUltimaFactura = null;
                    List<ModelDocumento> listaDocumentosResponse = doc.getDocumento();
                    //Ordenamos los documentos por orden cronológico, del mas reciente al mas antiguo;
                    Collections.sort(listaDocumentosResponse);
                    if(listaDocumentos==null)
                        listaDocumentos= new ArrayList<>();

                    for (ModelDocumento documento: listaDocumentosResponse) {
//
                        if (!documento.getId().isEmpty() && !documento.getSerieCorrelativo().isEmpty()
                                && !documento.getNombreCliente().isEmpty() && !documento.getFechaPago().isEmpty()
                                && !documento.getSubtotal().isEmpty() && !documento.getTotal().isEmpty()
                                && !documento.getTotalImpuestos().isEmpty() && !documento.getDescuentos().isEmpty()
                                && !documento.getIdInterno().isEmpty() && !documento.getFechaEmision().isEmpty()) {
                            listaDocumentos.add(new ModelDocumento(documento));

                            //almacenamos la fecha del documento para tenerla de referencia como próxima fecha inicial la proxima vez
                            //que generemos una consulta de rango de documentos
                            fechaUltimaFactura = documento.getFechaEmision();

                        }

                    }
                    //Verificamos que la fecha de la última factura no sea nula, y la almacenamos para el siguiente rango de fechas|
                    if(fechaUltimaFactura!=null){
                        try {
                            fechaInicio = dateFormat.parse(fechaUltimaFactura);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    if(miRecicler!=null)
                        miRecicler.getAdapter().notifyDataSetChanged();


                    esperaDeDatos();

                } else {


                    Toast.makeText(DocumentosMain.this, doc.getMensaje(), Toast.LENGTH_SHORT).show();
                    esperaDeDatos();
                }

            }

            @Override
            public void onFailure(Call<ModelObtenerDocumentos> call, Throwable t) {
                esperaDeDatos();
                mostrarToast(R.string.fallo_retroit);
            }
        });

    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.bt_calendario:

                new Ventana_calendario(DocumentosMain.this, DocumentosMain.this);

                break;


            // botones del navigation view

            case R.id.bt_nav_inicio:

                enviarDatos(PrincipalActivity.class, getString(R.string.codigo_de_boletaDeVenta) );

                break;

            case R.id.bt_nav_catalogo:

                if(nav_view_layout_catalogo.getVisibility()== View.GONE){
                    nav_view_layout_catalogo.setVisibility(View.VISIBLE);
                }else {
                    nav_view_layout_catalogo.setVisibility(View.GONE);
                }

                break;

            case R.id.bt_nav_unidades:

                enviarDatos(UnidadesMain.class, getString(R.string.codigo_de_boletaDeVenta));

                break;

            case R.id.bt_nav_documento:

                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START); }

                break;

            case R.id.bt_nav_ajustes:

                enviarDatos(Ajustes.class, getString(R.string.codigo_de_boletaDeVenta));

                break;

            case R.id.bt_nav_acerca_De:

                enviarDatos(Acerca_de.class, getString(R.string.codigo_de_boletaDeVenta));

                break;

            case R.id.bt_nav_cerrar_sesion:


                break;



        }

    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente del la seleccion del menu flotante
    private void botonFlotanteMenu() {

        fabt_menu.setMenuListener(new FabSpeedDial.MenuListener() {
            @Override
            public boolean onPrepareMenu(NavigationMenu navigationMenu) {
                return true;
            }

            @Override
            public boolean onMenuItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.menu_ir_boleta:
                        enviarDatos(Factura.class, getString(R.string.codigo_de_boletaDeVenta));
                        break;

                    case R.id.menu_ir_factura:
                        enviarDatos(Factura.class, "01");
                        break;

                    case R.id.menu_ir_nota_credito:
                        enviarDatos(Factura.class, "07");
                        break;

                    case R.id.menu_ir_nota_debito:
                        enviarDatos(Factura.class, "08");
                        break;
                }

                return true;
            }

            @Override
            public void onMenuClosed() {

            }
        });

    }


    private void enviarDatos(Class clase, String i) {
        Intent enviar = new Intent(DocumentosMain.this, clase);
        enviar.putExtra(getString(R.string.enviar_usuario), idUsuario);
        enviar.putExtra("tipoDocumento", i);
        startActivity(enviar);
    }

    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar las facturas
    //este recibira la lista de facturas y generara el elemento en el layout
    private void funcionDelAdaptador(List<ModelDocumento> documentos) {

         miAdapter = new DocumentoEmitidoAdaptador(documentos, R.layout.cardview_documentos, this, new DocumentoEmitidoAdaptador.MyOnItemClick() {
            @Override
            public void onItem(ModelDocumento documentos, int position) {

                RealmQuery<ModelFacturasParseada> consultaFactura = listaDeFacturasParseada.where().contains("id", documentos.getTipoDoc() + "-" + documentos.getSerieCorrelativo());
                facturasParseada = consultaFactura.findFirst();

                if (facturasParseada != null) {
                    Intent enviar = new Intent(DocumentosMain.this, VisualizacionDeDocumentos.class);

                    enviar.putExtra("facturaParseada", facturasParseada);
                    startActivity(enviar);
                } else {

                    Toast.makeText(DocumentosMain.this, "no registrada", Toast.LENGTH_SHORT).show();

                }


            }
        });

        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);
    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        Realm realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        if (usuarios != null)
            listaDeFacturasParseada = usuarios.getLista_de_facturas();
    }


    private void recibirDatosDeOtrosActivitys() {


        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            idUsuario = extra.getInt(getString(R.string.enviar_usuario));
            baseDeDatos();

        }
    }


    //lista de elementos que aparecera cuando se presione el boton flotante y desplegara la lista
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_documentos_emitido, menu);
    }


    // menu que aparecera enlazado al toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar_doc_emitido, menu);

        return super.onCreateOptionsMenu(menu);
    }


    //metodo de accion de los botones que estan alojados en el toolbar

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {

            //Si se presiona la fecha hacia atras, terminamos la actividad
            case android.R.id.home:
                finish();
                return true;

            case R.id.menu_doc_buscar:
                //metodo para mostrar y ocultar el panel de busqueda
                panel_busqueda.setVisibility(panel_busqueda.getVisibility() == View.GONE?View.VISIBLE:View.GONE);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    private void permisos() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso(WRITE_EXTERNAL_STORAGE)) {
                //ha aceptado

                new MaterialFilePicker()
                        .withActivity(this)
                        .withRequestCode(CODIGO_PERMISO)
                        .withHiddenFiles(true)
                        .start();


            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                } else {
                    mostrarToast(R.string.login_validar_permiso_denegado);
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                }
            }

        } else {
            viejaVersion();
        }
    }


// este metodo sera llamado por el metodo permisos si la version es menor a la version 25

    private void viejaVersion() {

        if (chequearPermiso(WRITE_EXTERNAL_STORAGE)) {


            new MaterialFilePicker()
                    .withActivity(this)
                    .withRequestCode(CODIGO_PERMISO)
                    .withHiddenFiles(true)
                    .start();


        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso(String permiso) {

        int result = this.checkCallingOrSelfPermission(permiso);
        return result == PackageManager.PERMISSION_GRANTED;

    }


    //este metodo sera llamado  si la version es mayor a la 25 es un metodo para identificar que tipo
    // de permiso esta pidiendo en tiempo de ejecucion la app y asi ejecutar la peticion a travez de
    // un codigo ya declarado de manera global

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        switch (requestCode) {
            case CODIGO_PERMISO:

                if (grantResults.length > 0) {

                    String permission = permissions[0];
                    int result = grantResults[0];

                    if (permission.equals(WRITE_EXTERNAL_STORAGE)) {
                        if (result == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso(WRITE_EXTERNAL_STORAGE);
                            }

                        } else {
                            mostrarToast(R.string.login_validar_permiso_denegado);
                        }
                    }

                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                break;
        }
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(DocumentosMain.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));

        fabt_menu = findViewById(R.id.fabt_menu);
        panel_busqueda = findViewById(R.id.panel_busqueda);

        edi_panel_calendario = findViewById(R.id.edi_panel_calendario);
        edi_panel_calendario.addTextChangedListener(this);


        miRecicler = findViewById(R.id.mi_recicler_view_documentos);
        miLayoutManager = new LinearLayoutManager(this);
        miRecicler.addOnScrollListener(onScrollListener);
        if(listaDocumentos==null)
            listaDocumentos = new ArrayList<>();
        funcionDelAdaptador(listaDocumentos);


        visDoc_progressBar = findViewById(R.id.visDoc_progressBar);
        visDoc_progressBar.setVisibility(View.GONE);

        ImageView bt_calendario = findViewById(R.id.bt_calendario);
        bt_calendario.setOnClickListener(this);


        //funciones del navigation view

        drawerLayout = findViewById(R.id.drawer_activity_principal);

        View bt_nav_inicio = findViewById(R.id.bt_nav_inicio);
        bt_nav_inicio.setOnClickListener(this);

        View bt_nav_catalogo = findViewById(R.id.bt_nav_catalogo);
        bt_nav_catalogo.setOnClickListener(this);

        nav_view_layout_catalogo = findViewById(R.id.nav_view_layout_catalogo);


        View bt_nav_unidades = findViewById(R.id.bt_nav_unidades);
        bt_nav_unidades.setOnClickListener(this);

        View bt_nav_documento = findViewById(R.id.bt_nav_documento);
        bt_nav_documento.setOnClickListener(this);

        View bt_nav_ajustes = findViewById(R.id.bt_nav_ajustes);
        bt_nav_ajustes.setOnClickListener(this);

        View bt_nav_acerca_De = findViewById(R.id.bt_nav_acerca_De);
        bt_nav_acerca_De.setOnClickListener(this);

        View bt_nav_cerrar_sesion = findViewById(R.id.bt_nav_cerrar_sesion);
        bt_nav_cerrar_sesion.setOnClickListener(this);


    }



    //Implementamos un listener para saber cuando el recyclerview ha llegado al último registro y debemos solicitar un nuevo rango
    private RecyclerView.OnScrollListener onScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            /*
                Se valida si el recycleview ha llegado al final (si no puede cargar mas items) y se solicita un nuevo rango de documentos.
           */
            if (!recyclerView.canScrollVertically(1)) {
                servicioRetrofit2();
            }

        }
    };

    //configura el toolbar
    private void mostrarToolbar() {
        Toolbar toolbar = findViewById(R.id.toobarDocEmi);
        setSupportActionBar(toolbar);
        DocumentosMain.this.setTitle(R.string.toolbar_Documentos_E);
        //Se habilita el home button (la flecha hacia atras)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public void datosDelCalendario(String dia, String mes, String year) {

        edi_panel_calendario.setText(String.format("%s/%s/%s", dia, mes, year));




    }


    @Override
    public void onBackPressed() {


/*
        Intent enviar = new Intent(this, PrincipalActivity.class);
        enviar.putExtra("usuario", idUsuario);
        startActivity(enviar);
*/


        /*
        En el backPressed debe terminarse la actividad, a fin de respetar el ciclo de vida de esta, puesto que
        si llamamos a otra actividad en vez de terminar esta, va a quedar en memoria y no vamos a tener un control del flujo de las interacciones
        en la interfaz gráfica. Si estuviesemos trabajando con fragmentos, quizas si se puede mantener en memoria.

        La otra opcion sería no crear una nueva instancia de la actividad, sino llamar a una instancia existente.
         */

        finish();
    }

    private void esperaDeDatos() {

        visDoc_progressBar.setVisibility(visDoc_progressBar.getVisibility() == View.GONE?View.VISIBLE:View.GONE);

    }


    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        String datosdoc = charSequence.toString().toLowerCase();



        List<ModelDocumento> documentos =new ArrayList<>();


        for (i=0;i<listaDocumentos.size(); i++){

            if (listaDocumentos.get(i).getNombreCliente().contains(charSequence)||listaDocumentos.get(i).getFechaEmision().contains(charSequence)){

                documentos.add(listaDocumentos.get(i));
            }

            funcionDelAdaptador(documentos);
            miAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }




}