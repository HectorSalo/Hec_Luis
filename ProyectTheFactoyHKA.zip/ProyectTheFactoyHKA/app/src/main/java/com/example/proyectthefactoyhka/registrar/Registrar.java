package com.example.proyectthefactoyhka.registrar;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.herramienta.ArrayGeneralApp;
import com.example.proyectthefactoyhka.login.MainActivity;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;


import io.realm.Realm;
import io.realm.RealmList;

public class Registrar extends AppCompatActivity implements View.OnClickListener, View.OnFocusChangeListener {

    private Realm realm;
    private RealmList<ModelUnidad> listaunidades = new RealmList<>();
    private EditText edi_regis_usuario, edi_regis_pass;
    private EditText edi_regis_ruc, edi_regis_dv;
    private TextView tv_regis_serial;
    private View view_registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        cast();


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            tv_regis_serial.setText(Build.getSerial());
        } else {
            tv_regis_serial.setText(Build.SERIAL);
        }

        //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
        //configuracion_realm_dataBase
        realm = Realm.getDefaultInstance();

    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.bt_registrar:


                if (TieneCamposVacios()) {
                    validarCampoIndividual();
                } else {

                    insercionDeunidades();

                    ModelUsuario modelUsuario = new ModelUsuario("testhkaM", "th3f4ct",  tv_regis_serial.getText().toString(), listaunidades);

                    realm.beginTransaction();
                    realm.copyToRealmOrUpdate(modelUsuario);
                    realm.commitTransaction();

                    startActivity(new Intent(Registrar.this, MainActivity.class));

                    Toast.makeText(Registrar.this, "Usuario registrado con exito", Toast.LENGTH_SHORT).show();
                }

                break;
        }

    }







    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        edi_regis_usuario = findViewById(R.id.edi_regis_usuario);
        edi_regis_usuario.setOnFocusChangeListener(this);

        edi_regis_pass = findViewById(R.id.edi_regis_pass);
        edi_regis_pass.setOnFocusChangeListener(this);


        edi_regis_ruc = findViewById(R.id.edi_regis_ruc);
        edi_regis_ruc.setOnFocusChangeListener(this);

        edi_regis_dv = findViewById(R.id.edi_regis_dv);
        edi_regis_dv.setOnFocusChangeListener(this);

        tv_regis_serial = findViewById(R.id.tv_regis_serial);

        view_registrar = findViewById(R.id.view_registrar);

        Button bt_registrar = findViewById(R.id.bt_registrar);
        bt_registrar.setOnClickListener(this);

    }


    //metodo principal utilizado para verificar si algun campo esta vacio al presionar el boton registrar
    private boolean TieneCamposVacios() {
        return edi_regis_usuario.getText().toString().isEmpty() ||
                edi_regis_pass.getText().toString().isEmpty() ||
                edi_regis_ruc.getText().toString().isEmpty() ||
          //      edi_regis_dv.getText().toString().isEmpty() ||
                tv_regis_serial.getText().toString().isEmpty();
    }


    //metodo filtro utilizado para verificar de manera individual para ver si algun campo esta vacio
    //y asi enviar un toast al usuario este metodo sera llamado por validarCamposVacios si en dado caso este envia
    //un true como resultado

    private void validarCampoIndividual() {

        if (edi_regis_usuario.getText().toString().isEmpty()) {
            mostrarToast(R.string.validar_usuario);

        } else {

            if (edi_regis_pass.getText().toString().isEmpty()) {
                mostrarToast(R.string.validar_pass);

            } else {

                if (edi_regis_ruc.getText().toString().isEmpty()) {
                    mostrarToast(R.string.validar_ruc);

                } else {

//                    if (edi_regis_dv.getText().toString().isEmpty()) {
//                        mostrarToast(R.string.validar_dv);
//                    } else {

                        if (tv_regis_serial.getText().toString().isEmpty()) {
                            mostrarToast(R.string.validar_serial);
                        }
                    }
                }
            }
        }
  //  }


    //metodo para obtener las unidades y registrarla en la base de datos
    private void insercionDeunidades() {

        realm.beginTransaction();
        listaunidades.addAll(ArrayGeneralApp.todasLasUnidades());
        realm.copyToRealm(listaunidades);
        realm.commitTransaction();

    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {

        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onFocusChange(View v, boolean hasFocus) {

        if (edi_regis_usuario.hasFocus() || edi_regis_pass.hasFocus() || edi_regis_ruc.hasFocus() || edi_regis_dv.hasFocus()) {
            view_registrar.setVisibility(View.GONE);
        } else {
            view_registrar.setVisibility(View.VISIBLE);
        }
    }
}
