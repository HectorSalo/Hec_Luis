package com.example.proyectthefactoyhka.modelo.modelos_APP;

import io.realm.RealmObject;

public class ModelCiudades extends RealmObject {

    private String id;
    private String codigo_municipio;
    private String codigo_departamento;
    private String ciudad;
    private String ubigeo;

    public ModelCiudades() {
    }

    public ModelCiudades(String id, String codigo_municipio, String codigo_departamento, String ciudad, String ubigeo) {
        this.id = id;
        this.codigo_municipio = codigo_municipio;
        this.codigo_departamento = codigo_departamento;
        this.ciudad = ciudad;
        this.ubigeo = ubigeo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo_municipio() {
        return codigo_municipio;
    }

    public void setCodigo_municipio(String codigo_municipio) {
        this.codigo_municipio = codigo_municipio;
    }

    public String getCodigo_departamento() {
        return codigo_departamento;
    }

    public void setCodigo_departamento(String codigo_departamento) {
        this.codigo_departamento = codigo_departamento;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getUbigeo() {
        return ubigeo;
    }

    public void setUbigeo(String ubigeo) {
        this.ubigeo = ubigeo;
    }
}
