package com.example.proyectthefactoyhka.herramienta;


import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;


public class Ventana_calendario implements View.OnClickListener {




    private Dialog dialog;

    private DatePicker calendario;
    private Conexion_calendario conexion_calendario;


    public Ventana_calendario(final Context context, final Conexion_calendario conexion_calendario) {



        configuracionDelaVentana(context);
        this.conexion_calendario=conexion_calendario;

        cast();


        dialog.show();

    }




    //metodo donde esta asignado las acciones de los botones

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.bt_calendario_aceptar:


                 conexion_calendario.datosDelCalendario( String.valueOf(calendario.getMonth()+1),String.valueOf(calendario.getDayOfMonth()), String.valueOf(calendario.getYear()));


                dialog.dismiss();

                break;

            case R.id.bt_calendario_cancelar:

                Toast.makeText(dialog.getContext(), "no se selecciono fecha", Toast.LENGTH_SHORT).show();
                dialog.dismiss();

                break;


        }


    }





    //metodo donde se castea todos los elementos que tendran interacion con el usuario

    private void cast() {



        calendario=dialog.findViewById(R.id.calendario);
        Button bt_calendario_aceptar = dialog.findViewById(R.id.bt_calendario_aceptar);
        Button bt_calendario_cancelar = dialog.findViewById(R.id.bt_calendario_cancelar);

        bt_calendario_aceptar.setOnClickListener(this);
        bt_calendario_cancelar.setOnClickListener(this);

    }




    //configuracion de la ventana para poder ser visualizada

    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_calendario);

    }


}
