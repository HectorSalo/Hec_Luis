package com.example.proyectthefactoyhka.modelo.eviarDatos;

import android.os.Parcel;
import android.os.Parcelable;

public class IGV implements Parcelable {

    private String baseImponible;
    private String monto;
    private String porcentaje;
    private String tipo;


    public IGV(String baseImponible, String monto, String porcentaje, String tipo) {
        this.baseImponible = baseImponible;
        this.monto = monto;
        this.porcentaje = porcentaje;
        this.tipo = tipo;
    }


    protected IGV(Parcel in) {
        baseImponible = in.readString();
        monto = in.readString();
        porcentaje = in.readString();
        tipo = in.readString();
    }

    public static final Creator<IGV> CREATOR = new Creator<IGV>() {
        @Override
        public IGV createFromParcel(Parcel in) {
            return new IGV(in);
        }

        @Override
        public IGV[] newArray(int size) {
            return new IGV[size];
        }
    };

    public String getBaseImponible() {
        return baseImponible;
    }

    public void setBaseImponible(String baseImponible) {
        this.baseImponible = baseImponible;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getPorcentaje() {
        return porcentaje;
    }

    public void setPorcentaje(String porcentaje) {
        this.porcentaje = porcentaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(baseImponible);
        dest.writeString(monto);
        dest.writeString(porcentaje);
        dest.writeString(tipo);
    }
}
