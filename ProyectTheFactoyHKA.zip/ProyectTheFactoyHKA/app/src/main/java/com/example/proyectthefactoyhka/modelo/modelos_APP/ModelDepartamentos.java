package com.example.proyectthefactoyhka.modelo.modelos_APP;

import io.realm.RealmObject;

public class ModelDepartamentos extends RealmObject {

    private String id;
    private String codigo_departamento;
    private String departamento;

    public ModelDepartamentos() {
    }

    public ModelDepartamentos(String id, String codigo_departamento, String departamento) {
        this.id = id;
        this.codigo_departamento = codigo_departamento;
        this.departamento = departamento;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo_departamento() {
        return codigo_departamento;
    }

    public void setCodigo_departamento(String codigo_departamento) {
        this.codigo_departamento = codigo_departamento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }
}
