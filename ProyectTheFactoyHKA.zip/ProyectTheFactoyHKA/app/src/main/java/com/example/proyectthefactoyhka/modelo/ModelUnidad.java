package com.example.proyectthefactoyhka.modelo;

import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import io.realm.RealmObject;

public class ModelUnidad extends RealmObject {

    private int id ;
    private boolean check;
    private String descripcion;
    private String codigo;

    public ModelUnidad() {
    }

    public ModelUnidad(boolean check, String descripcion,String codigo) {
        this.id = MyApplication.IdUnidad.incrementAndGet();
        this.check = check;
        this.descripcion = descripcion;
        this.codigo = codigo;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCodigo() { return codigo; }

    public void setCodigo(String codigo) { this.codigo = codigo; }
}
