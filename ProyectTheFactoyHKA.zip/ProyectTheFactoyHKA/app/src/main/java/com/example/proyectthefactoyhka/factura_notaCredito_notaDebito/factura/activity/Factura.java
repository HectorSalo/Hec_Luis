package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.opciones.Opciones;
import com.example.proyectthefactoyhka.ajustes.teclado.adaptador.TecladoAdaptador;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente.VentAddCliente;
import com.example.proyectthefactoyhka.catalogo_producto.ventana_emergente.CodigoScanner;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.adaptador.FacturaAdaptador;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.conexion_factura.Conexion_factura;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.ventana_emergente.Ventana_descuento;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura_generada.FacturaGenerada;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;
import com.example.proyectthefactoyhka.modelo.ModelTotales;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.eviarDatos.IGV;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ISC;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDescuentosGlobales;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelOpciones;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import in.galaxyofandroid.spinerdialog.OnSpinerItemClick;
import in.galaxyofandroid.spinerdialog.SpinnerDialog;
import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;

import static android.Manifest.permission.CAMERA;

public class Factura extends AppCompatActivity implements View.OnClickListener, Conexion_factura, RealmChangeListener<RealmList<ModelCliente>> {

    public static final int REQUEST_FACTURA = 1000;

    private TextView panel_spinnercliente, spinnerproducto, spinnercodigo, tv_panel_total, panel_tv_precio;
    private SpinnerDialog ventana_spinner;
    private EditText edi_panel_cantidad;
    private RealmList<ModelCliente> listaclientes;
    private RealmList<ModelProducto> listaproducto;
    private RealmResults<ModelTasa> tasa;
    private ArrayList<String> datosClientes, datosProductos, datosCodigoProductos;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager, miGridlayout, miGridlayoutnumerico;
    private RecyclerView.Adapter miAdapter;
    private ArrayList<ModelFacturacion> factura = new ArrayList<>();
    private Button bt_generar_factura;
    private double cantidadObtenida, totalVenta = 0;
    private int idUsuario;
    private double montoTotalImpuestoXCantidad = 0, montoTotalBaseImponibleXcantidad = 0;
    private ModelProducto producto;
    private ModelCliente cliente;
    private RealmQuery<ModelProducto> consultaProducto;
    private final int CODIGO_PERMISO = 946;
    private RealmList<ModelTeclas> listaTeclas;
    private RealmList<ModelUnidad> listaUnidades;
    boolean mostrarTeclado;
    private View panel_factura, panel_layout_productos, panel_layout_cliente;
    private ImageButton bt_panel_tecl_mostrar_produtos, bt_panel_mostrar_cli;
    private boolean selecionado = true;
    private String tipoDocumento;
    private ModelOpciones opcionesFactura;
    private double montoTotalDescontado = 0.00;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factura);


        cast();
        funcionDelAdaptador();
        recibirDatosDeOtrosActivitys();
        funcionDelTecladoDelPanelDeTeclado(listaTeclas);


    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            //Si es presionada la flecha atras del ActionBar
            case android.R.id.home:
                mostrarDialogo();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.panel_spinnercliente:

                //accion el cual llamara al adaptador de los spinner el cual obtendra los datos el obtendra los datos del array datosClientes
                //y lo enviara al textView spinnercliente

                adaptadorSearchableSpinner(datosClientes, panel_spinnercliente);
                ventana_spinner.showSpinerDialog();


                break;


            case R.id.spinnerproducto:
                //accion el cual llamara al adaptador de los spinner el cual obtendra los datos el obtendra los datos del array datosProductos y lo enviara al textView
                // spinnerproducto y  dependiendo el elemento obtenido este recorrera el array datosCodigoProductos y enviara el dato obtenido al TextView spinercodigo
                adaptadorSearchableSpinner(datosProductos, spinnerproducto);
                ventana_spinner.showSpinerDialog();


                break;

            case R.id.spinnercodigo:
                //accion el cual llamara al adaptador de los spinner el cual obtendra los datos el obtendra los datos del array datosCodigoProductos y lo enviara al textView
                // spinercodigo y  dependiendo el elemento obtenido este recorrera el array datosProductos y enviara el dato obtenido al TextView spinnerproducto
                adaptadorSearchableSpinner(datosCodigoProductos, spinnercodigo);
                ventana_spinner.showSpinerDialog();

                break;

            case R.id.bt_panel_incremento:
                //llamara al elemento el cual sumara la cantidad de productos antes de generar una facruta
                OperacionIncrementoDecremento(R.id.bt_panel_incremento);

                break;

            case R.id.bt_panel_decremento:

                //llamara al elemento el cual restara la cantidad de productos antes de generar una facruta
                OperacionIncrementoDecremento(R.id.bt_panel_decremento);

                break;

            case R.id.bt_panel_agregar_fact:
                //if el cual verificara que el spinnerProducto tenga datos antes de generar una nueva factura
                if (!spinnerproducto.getText().toString().equals("")) {
                    generarFactura(producto, producto.getPrecioUnitario1());

                } else {
                    mostrarToast(R.string.panel_toast_validador);
                }
                break;


            case R.id.bt_generar_factura:
                //accion el cual obtendra todos los datos almacenados en el ReciclerView y enviara los datos a la clase FacturaGenerada.class

                if (panel_spinnercliente.getText().equals("")) {
                    mostrarToast(R.string.validar_cantidad_cliente);
                } else if (panel_spinnercliente.getText().equals(getString(R.string.consumidor_final)) && totalVenta >=700) {
                    mostrarToast(R.string.monto_excedido);
                } else {
                    enviarDatos();
                }

                break;

            case R.id.bScanItem:

                if (listaproducto.size() > 0) {

                    permisosCamara();

                } else {
                    mostrarToast(R.string.registre_producto);
                }
                break;


            case R.id.bt_panel_agregar_cli:

                VentAddCliente ventanaDialogo = new VentAddCliente();
                Bundle datos = new Bundle();
                datos.putInt("usuario", idUsuario);
                ventanaDialogo.setArguments(datos);
                ventanaDialogo.show(getSupportFragmentManager(), "producto");

                break;

            //botones de la funcionalidad del panel del teclado

            case R.id.panel_tecl_porcentaje:

                break;


            case R.id.panel_tecl_eliminar:

                break;


            case R.id.bt_panel_tecl_mostrar_produtos:

                if (panel_layout_productos.getVisibility() == View.GONE) {

                    panel_factura.setVisibility(View.VISIBLE);
                    panel_layout_productos.setVisibility(View.VISIBLE);

                    bt_panel_tecl_mostrar_produtos.setBackgroundColor(getResources().getColor(R.color.gris_de_botones));

                } else {
                    bt_panel_tecl_mostrar_produtos.setBackgroundColor(getResources().getColor(R.color.colorgris));
                    panel_layout_productos.setVisibility(View.GONE);
                }

                break;

            case R.id.panel_tecl_escaneo:

                if (listaproducto.size() > 0) {

                    permisosCamara();

                } else {
                    mostrarToast(R.string.registre_producto);
                }

                break;


            case R.id.bt_panel_mostrar_cli:


                if (panel_layout_cliente.getVisibility() == View.GONE) {

                    panel_factura.setVisibility(View.VISIBLE);
                    panel_layout_cliente.setVisibility(View.VISIBLE);
                    bt_panel_mostrar_cli.setBackgroundColor(getResources().getColor(R.color.gris_de_botones));

                } else {

                    bt_panel_mostrar_cli.setBackgroundColor(getResources().getColor(R.color.colorgris));
                    panel_layout_cliente.setVisibility(View.GONE);

                }


            case R.id.panel_tecl_retroceso:


                break;


        }
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AdaptadorFacturacion se presiona la accion del boton de Eliminar factura
    //el cual removera el elemento cardView dependiendo la posicion obtenida
    @Override
    public void borrarFactura(int posicion, String montoDeVenta) {


        totalVenta = totalVenta - Double.parseDouble(montoDeVenta);
        bt_generar_factura.setText(String.format(Locale.US, "%.2f", totalVenta));
        factura.remove(posicion);
        miAdapter.notifyItemRemoved(posicion);
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AdaptadorFacturacion se presiona la accion del boton de Aplicar
    //este llamara a la clase Ventana_descuento
    @Override
    public void funcionDePorcentaje(int posicion, ModelFacturacion datosFactura) {
        new Ventana_descuento(this, datosFactura, posicion, this);
    }


    @Override
    public void aplicarPorcentaje(int posicion, ModelFacturacion datosFactura, double monto) {
        factura.set(posicion, datosFactura);
        montoTotalDescontado = montoTotalDescontado + monto;
        miAdapter.notifyDataSetChanged();
    }


    //metodo el cual verificara si esta recibiendo datos de las activity ProductosMain o ClientesMain para implementar los datos en los textView correspondiente
    private void recibirDatosDeOtrosActivitys() {

        final Intent intent = getIntent();
        Bundle extra = intent.getExtras();

        if (extra != null) {
            idUsuario = extra.getInt(getString(R.string.enviar_usuario));
            tipoDocumento = extra.getString("tipoDocumento");

            baseDeDatos();

            if (tipoDocumento != null) {
                mostrarToolbar(tipoDocumento);
            }


            String identificacionCliente = extra.getString("datoClien");
            String codigoPro = extra.getString("codigo");

            if (intent.hasExtra("datoClien")) {

                if (identificacionCliente != null) {

                    RealmQuery<ModelCliente> consultaCliente = listaclientes.where().contains("identificacion", identificacionCliente);
                    cliente = consultaCliente.findFirst();

                    if (cliente != null) {
                        panel_spinnercliente.setText(cliente.getNombre());
                    }
                }
            } else {

                if (codigoPro != null) {

                    consultaProducto = listaproducto.where().contains("codigo1", codigoPro);
                    producto = consultaProducto.findFirst();

                    if (producto != null) {
                        spinnerproducto.setText(producto.getDescripcion());
                        spinnercodigo.setText(producto.getCodigo1());

                        ModelTasa porcentajeDeImpuesto = tasa.get(producto.getPosicionSpinnerIGV());

                        if (porcentajeDeImpuesto != null) {
                            tv_panel_total.setText(String.format("%s", producto.getPrecioUnitario1() + Integer.parseInt(porcentajeDeImpuesto.getPorcentajeDeImpuesto())));
                        }

                        generarFactura(producto, producto.getPrecioUnitario1());

                    }
                }
            }

        }
    }


    //metodo el cual recibe una respuesta despues de haber llamado a la ventana de escaneo este si
    // recibe un codigo valido lo agregara a la lista de lo contrario notificara que el producto no esta registrado en la base de datos
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 2) {

            if (resultCode == Activity.RESULT_OK) {

                if (data != null) {

                    final String result = data.getStringExtra("barra");


                    consultaProducto = listaproducto.where().equalTo("codigo1", result);
                    producto = consultaProducto.findFirst();

                    if (producto != null) {

                        spinnerproducto.setText(producto.getDescripcion());
                        spinnercodigo.setText(producto.getCodigo1());
                        tv_panel_total.setText(String.format(Locale.getDefault(), "%.2f", producto.getPrecioUnitario1()).replaceAll(",", "."));

                    } else {

                        spinnerproducto.setText("");
                        spinnercodigo.setText("");
                        tv_panel_total.setText("");
                        mostrarToast(R.string.codigo_no_registrado);

                    }


                }
            }
        }
        if(requestCode == REQUEST_FACTURA){
            if(resultCode == RESULT_OK){
                finish();
            }
        }
    }


    //metodo para generar una nueva factura
    private void generarFactura(ModelProducto factProductos, double precioUnitario) {

        ModelFacturacion producto = new ModelFacturacion();
        //accion el cual obtiene los datos tanto de cantidad y de precio los transforma en variable Double y los multiplica
        cantidadObtenida = Double.parseDouble(edi_panel_cantidad.getText().toString());


        double total;

        if (factProductos != null) {

            ModelTasa tasasIgv = tasa.get(factProductos.getPosicionSpinnerIGV());

            RealmQuery<ModelUnidad> consultaUnidad = listaUnidades.where().contains("descripcion", factProductos.getTipo_unidad());


            if (tasasIgv != null) {

                double montoTotalIGV = precioUnitario * (1 + tasasIgv.getDecimaDelImpuesto());

                double montoImpuestoIGV = precioUnitario * tasasIgv.getDecimaDelImpuesto();

                // Tasa de impuesto ISC
                double tasaISC = (Double.parseDouble(factProductos.getCantidadDePorcISC())) / 100;

                double baseImponibleISC = precioUnitario / (1 + tasaISC);

                double montoImpuestoISC = baseImponibleISC * tasaISC;

                double totalImpuestosItem = (montoImpuestoIGV + montoImpuestoISC) * cantidadObtenida;

                double precioTotalItem = precioUnitario + montoImpuestoIGV;

                double baseImponibleigv;

                if (montoImpuestoIGV != 0) {
                    baseImponibleigv = precioUnitario;
                } else {
                    baseImponibleigv = 0.00;
                }


                IGV igv = new IGV(String.format(Locale.US, "%.2f", baseImponibleigv),
                        String.format(Locale.US, "%.2f", montoImpuestoIGV),
                        tasasIgv.getPorcentajeDeImpuesto(),
                        "10");

                if (montoImpuestoISC > 0) {
                    ISC isc = new ISC(String.format(Locale.US, "%.2f", baseImponibleISC),
                            String.format(Locale.US, "%.2f", montoImpuestoISC),
                            factProductos.getCantidadDePorcISC(),
                            "01");
                    producto.setiSC(isc);
                }


                producto.setCantidad(String.format(Locale.US, "%.2f", cantidadObtenida));
                producto.setDescripcion(factProductos.getDescripcion());

                producto.setCodigoPLU(factProductos.getCodigo2());
                producto.setiGV(igv);
                producto.setMontoTotalImpuestoItem(String.format(Locale.US, "%.2f", totalImpuestosItem));
                producto.setNumeroOrden("" + (factura.size() + 1));
                producto.setCodigoPLU(factProductos.getCodigo1());
                producto.setPrecioVentaUnitarioItem(String.format(Locale.US, "%.2f", precioTotalItem));
                producto.setUnidadMedida(consultaUnidad.findFirst().getCodigo());
                producto.setValorUnitarioBI(String.format(Locale.US, "%.2f", precioUnitario));
                producto.setValorVentaItemQxBI(String.format(Locale.US, "%.2f", precioUnitario * cantidadObtenida));

                factura.add(producto);
                miAdapter.notifyDataSetChanged();
                miAdapter.notifyItemInserted(0);
                miLayoutManager.scrollToPosition(0);

                total = cantidadObtenida * montoTotalIGV;

                //accion que enviara un total acumulado al boton de generar factura

                totalVenta = totalVenta + total;

                bt_generar_factura.setText(String.format(Locale.US, "%.2f", totalVenta));
                edi_panel_cantidad.setText("1.0");
            }


        }
    }


    private void enviarDatos() {

        if (!panel_spinnercliente.getText().equals("") || tipoDocumento.equals(getString(R.string.enviar_usuario))) {

            if (factura.size() != 0) {
                for (int i = 0; i < factura.size(); i++) {
                    montoTotalBaseImponibleXcantidad = montoTotalBaseImponibleXcantidad + Double.parseDouble(factura.get(i).getValorVentaItemQxBI());
                    montoTotalImpuestoXCantidad = (montoTotalImpuestoXCantidad + (Double.parseDouble(factura.get(i).getMontoTotalImpuestoItem())));
                }

                String totalImpuesto = String.format(Locale.US, "%.2f", montoTotalImpuestoXCantidad);
                String subTotalDeVentas = String.format(Locale.US, "%.2f", montoTotalBaseImponibleXcantidad);

                ModelTotales totales = new ModelTotales("", String.format(Locale.US, "%.2f", totalVenta), totalImpuesto, subTotalDeVentas);


                Intent enviar = new Intent(this, FacturaGenerada.class);
                Bundle bundle = new Bundle();

                bundle.putInt(getString(R.string.enviar_usuario), idUsuario);
                bundle.putString("tipoDocumento", tipoDocumento);

                if (panel_spinnercliente.getText().equals(getString(R.string.consumidor_final))) {
                    cliente = new ModelCliente("", "", "", "", getString(R.string.consumidor_final), "-", "", "");
                    enviar.putExtra("datosCli", cliente);
                } else {
                    enviar.putExtra("datosCli", cliente);
                }

                enviar.putExtra("datosTotal", totales);
                enviar.putExtra("factura", factura);

                if (montoTotalDescontado != 0.00) {
                    enviar.putExtra("descuentoglobal", descuentoGlobal(montoTotalDescontado));
                }

                enviar.putExtras(bundle);
                startActivityForResult(enviar,REQUEST_FACTURA);

            } else {
                Toast.makeText(this, "coloca un producto", Toast.LENGTH_SHORT).show();
            }
        } else {
            mostrarToast(R.string.validar_cantidad_cliente);
        }
    }



    private ModelDescuentosGlobales descuentoGlobal(double montoTotalDescontado) {


        return new ModelDescuentosGlobales(String.format(Locale.US, "%.2f", montoTotalBaseImponibleXcantidad), String.format(Locale.US, "%.2f", montoTotalDescontado), "00", "10");

    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar las facturas
    //este recibira la lista de factura y generara el elemento en el layout
    private void funcionDelAdaptador() {

        miAdapter = new FacturaAdaptador(factura, R.layout.cardview_fact_cred_debi, Factura.this, Factura.this, selecionado, new FacturaAdaptador.MyItemClickfact() {
            @Override
            public void onItem(ModelFacturacion factura, int position) {

                miAdapter.notifyItemChanged(position);
            }
        });
        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);
    }


    //metodo para el incremento o decremento de las unidades de la facturas
    @SuppressLint("SetTextI18n")
    private void OperacionIncrementoDecremento(int boton) {

        cantidadObtenida = Double.parseDouble(edi_panel_cantidad.getText().toString());

        //se obtiene el dato actual en el editext

        if (boton == R.id.bt_panel_incremento) {

            // se limpia el editext
            edi_panel_cantidad.getText().clear();
            //se coloca el nuevo resultado
            edi_panel_cantidad.setText((cantidadObtenida + 1) + "");

        } else if (boton == R.id.bt_panel_decremento) {

            if (cantidadObtenida > 0) {
                edi_panel_cantidad.getText().clear();
                //se coloca el nuevo resultado
                edi_panel_cantidad.setText((cantidadObtenida - 1) + "");
            } else {
                mostrarToast(R.string.panel_toast);
            }
        }
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        miRecicler = findViewById(R.id.mi_recicler_view_factura);
        miLayoutManager = new LinearLayoutManager(this);
        panel_factura = findViewById(R.id.panel_factura);

        panel_layout_productos = findViewById(R.id.panel_layout_productos);
        panel_layout_cliente = findViewById(R.id.panel_layout_cliente);


        edi_panel_cantidad = findViewById(R.id.edi_panel_cantidad);
        edi_panel_cantidad.setText("1.00");

        tv_panel_total = findViewById(R.id.edi_panel_total);

        panel_spinnercliente = findViewById(R.id.panel_spinnercliente);
        panel_spinnercliente.setOnClickListener(this);

        spinnerproducto = findViewById(R.id.spinnerproducto);
        spinnerproducto.setOnClickListener(this);

        spinnercodigo = findViewById(R.id.spinnercodigo);
        spinnercodigo.setOnClickListener(this);

        miGridlayout = new GridLayoutManager(this, 4);
        miGridlayoutnumerico = new GridLayoutManager(this, 3);

        ImageButton bt_panel_agregar_cli = findViewById(R.id.bt_panel_agregar_cli);
        bt_panel_agregar_cli.setOnClickListener(this);

        ImageButton bt_panel_decremento = findViewById(R.id.bt_panel_decremento);
        bt_panel_decremento.setOnClickListener(this);

        ImageButton bt_panel_incremento = findViewById(R.id.bt_panel_incremento);
        bt_panel_incremento.setOnClickListener(this);

        ImageButton bt_panel_agregar_fact = findViewById(R.id.bt_panel_agregar_fact);
        bt_panel_agregar_fact.setOnClickListener(this);

        ImageButton bScanItem = findViewById(R.id.bScanItem);
        bScanItem.setOnClickListener(this);

        bt_generar_factura = findViewById(R.id.bt_generar_factura);
        bt_generar_factura.setOnClickListener(this);

        //botones del panel del teclado

        ImageButton panel_tecl_porcentaje = findViewById(R.id.panel_tecl_porcentaje);
        panel_tecl_porcentaje.setBackgroundColor(getResources().getColor(R.color.colorgris));
        panel_tecl_porcentaje.setOnClickListener(this);

        ImageButton panel_tecl_eliminar = findViewById(R.id.panel_tecl_eliminar);
        panel_tecl_eliminar.setBackgroundColor(getResources().getColor(R.color.colorgris));
        panel_tecl_eliminar.setOnClickListener(this);

        bt_panel_tecl_mostrar_produtos = findViewById(R.id.bt_panel_tecl_mostrar_produtos);
        bt_panel_tecl_mostrar_produtos.setBackgroundColor(getResources().getColor(R.color.colorgris));
        bt_panel_tecl_mostrar_produtos.setOnClickListener(this);

        ImageButton panel_tecl_escaneo = findViewById(R.id.panel_tecl_escaneo);
        panel_tecl_escaneo.setBackgroundColor(getResources().getColor(R.color.colorgris));
        panel_tecl_escaneo.setOnClickListener(this);

        bt_panel_mostrar_cli = findViewById(R.id.bt_panel_mostrar_cli);
        bt_panel_mostrar_cli.setBackgroundColor(getResources().getColor(R.color.colorgris));
        bt_panel_mostrar_cli.setOnClickListener(this);

        ImageButton panel_tecl_retroceso = findViewById(R.id.panel_tecl_retroceso);
        panel_tecl_retroceso.setOnClickListener(this);

        panel_tv_precio = findViewById(R.id.panel_tv_precio);

    }


    //metodo el cual buscara los los elementos requeridos en la base de datos  el cual
    // posteriormente sera consumido por el searcheable spinner
    private void arrayParallenarLosSpinners() {

        datosClientes = new ArrayList<String>() {
            {
                for (int i = 0; i < listaclientes.size(); i++) {

                    ModelCliente obtenerCliente = listaclientes.get(i);

                    if (obtenerCliente != null) {

                        add(obtenerCliente.getNombre());
                    }

                }
            }
        };


        datosProductos = new ArrayList<String>() {
            {
                for (int i = 0; i < listaproducto.size(); i++) {

                    ModelProducto obtenerProducto = listaproducto.get(i);

                    if (obtenerProducto != null) {

                        add(obtenerProducto.getDescripcion());
                    }
                }
            }
        };

        datosCodigoProductos = new ArrayList<String>() {
            {
                for (int i = 0; i < listaproducto.size(); i++) {

                    ModelProducto obtenerProducto = listaproducto.get(i);

                    if (obtenerProducto != null) {

                        add(obtenerProducto.getCodigo1());
                    }
                }
            }
        };

    }


    //metodo usado para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        Realm realm = Realm.getDefaultInstance();
        ModelUsuario usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        tasa = realm.where(ModelTasa.class).findAll();
        if (usuarios != null) {
            listaproducto = usuarios.getDatos_producto();
            listaclientes = usuarios.getDatos_clientes();
            listaclientes.addChangeListener(this);
            mostrarTeclado = usuarios.getTeclado().isTecladoPordefecto();
            listaTeclas = usuarios.getTeclado().getTeclas();
            listaUnidades = usuarios.getDatosunidad();
            opcionesFactura = usuarios.getOpciones();
        }
        arrayParallenarLosSpinners();

        if (laFacturaEsUnaBoleta()) {
            datosClientes.add(0, getString(R.string.consumidor_final));
            panel_spinnercliente.setText(getString(R.string.consumidor_final));

        }

    }


    //Los códigos de documentos no deberían ser definidos en el string; deberían estar en base de datos
    private void validandoSerieDelDocumento(){

        String serie = null;
        switch (tipoDocumento){
            case "03":
                serie =  opcionesFactura.getCodigo_boleta_de_venta();
                break;
            case "01":
                serie =  opcionesFactura.getCodigo_facturas();
                break;
            case "07":
                serie =  opcionesFactura.getCodigo_nota_credito();
                break;
            case "08":
                serie =  opcionesFactura.getCodigo_nota_debito();
                break;
        }
        if(serie==null || serie.isEmpty()){

            bt_generar_factura.setVisibility(View.GONE);
            enviarAConfiguracion();

        }else {

            bt_generar_factura.setVisibility(View.VISIBLE);
        }
    }


    private void adaptadorSearchableSpinner(ArrayList<String> datosSpinner, final TextView spinnerTexto) {


        ventana_spinner = new SpinnerDialog(Factura.this, datosSpinner, "Selecciona");
        ventana_spinner.bindOnSpinerListener(new OnSpinerItemClick() {
            @Override
            public void onClick(String item, int position) {

                if (spinnerTexto == panel_spinnercliente) {

                    if (laFacturaEsUnaBoleta()) {
                        if (!item.equals(getString(R.string.consumidor_final))) {
                            cliente = listaclientes.get(position - 1);
                            panel_spinnercliente.setText(item);
                        } else {
                            cliente = new ModelCliente("", "", "", "", "", item, item, "");
                            panel_spinnercliente.setText(item);
                        }
                    } else {
                        cliente = listaclientes.get(position);
                        if (cliente != null) {
                            panel_spinnercliente.setText(cliente.getNombre());
                        }
                    }
                } else {
                    producto = listaproducto.get(position);
                    if (producto != null) {
                        spinnerproducto.setText(producto.getDescripcion());
                        spinnercodigo.setText(producto.getCodigo1());
                        ModelTasa porcentajeDeImpuesto = tasa.get(producto.getPosicionSpinnerIGV());
                        if (porcentajeDeImpuesto != null) {
                            tv_panel_total.setText(String.format("%s", producto.getPrecioUnitario1() + Integer.parseInt(porcentajeDeImpuesto.getPorcentajeDeImpuesto())));
                        }
                    }
                }
            }


        });
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(Factura.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    //metodo que  configura el toolbar
    private void mostrarToolbar(String tipoDocumento) {

        Toolbar toolbar = findViewById(R.id.toolbar_factura);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        switch (tipoDocumento) {
            case "01":
                Factura.this.setTitle(R.string.toolbar_factura);

                break;
            case "07":

                Factura.this.setTitle(R.string.titulo_nota_credito);

                break;
            case "08":

                Factura.this.setTitle(R.string.titulo_nota_debito);

                break;
            case "03":

                Factura.this.setTitle(R.string.titulo_boletas_de_venta);
                break;
        }

    }


    //metodo que se encargara de verificar los permiso de ususario tanto de versiones por debajo de 6.0 a superiores de 6.0 esten ya registrado para la inicializacion de la actividad de escaneo de codigo
    private void permisosCamara() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso()) {
                //ha aceptado

                Intent intent = new Intent(Factura.this, CodigoScanner.class);
                startActivityForResult(intent, 2);

            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{CAMERA}, CODIGO_PERMISO);
                } else {
                    //ha rechazado
                    requestPermissions(new String[]{CAMERA}, CODIGO_PERMISO);
                }
            }
        } else {
            viejaVersionpermisoCamara();
        }
    }


    private void viejaVersionpermisoCamara() {

        if (chequearPermiso()) {

            Intent intent = new Intent(Factura.this, CodigoScanner.class);
            startActivityForResult(intent, 2);
        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo para registrar los permisos de camara para versiones 6.0 o superior

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CODIGO_PERMISO) {
            if (grantResults.length > 0) {

                String permission = permissions[0];
                int result = grantResults[0];

                if (permission.equals(CAMERA)) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(Factura.this, CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso();
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso() {
        int result = Factura.this.checkCallingOrSelfPermission(Manifest.permission.CAMERA);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    //metodo el cual reutiliza los adatadores de los recicler view del teclado para implementar el teclado numerico y
    private void funcionDelTecladoDelPanelDeTeclado(List<ModelTeclas> teclas) {

        View panel_teclado = findViewById(R.id.panel_teclado);
        final View panel_layout_precio = findViewById(R.id.panel_layout_precio);
        panel_layout_cliente.setVisibility(View.GONE);
        panel_layout_productos.setVisibility(View.GONE);

        RecyclerView mi_recicler_teclado = findViewById(R.id.mi_recicler_teclado);
        RecyclerView mi_recicler_teclado_numerico = findViewById(R.id.mi_recicler_teclado_numerico);

        if (mostrarTeclado) {

            panel_teclado.setVisibility(View.VISIBLE);
            panel_factura.setVisibility(View.GONE);

            TecladoAdaptador miAdapter_teclado = new TecladoAdaptador(teclas, this, R.layout.card_tecla_pro_panel_teclado, 1, new TecladoAdaptador.MyItemClick() {
                @Override
                public void listener(ModelTeclas modelTeclas, int position) {

                    if (!modelTeclas.getCodigo1().equals("")) {

                        RealmQuery<ModelProducto> consultaProducto = listaproducto.where().contains("codigo1", modelTeclas.getCodigo1());
                        producto = consultaProducto.findFirst();

                        if (panel_layout_precio.getVisibility() == View.VISIBLE) {
                            generarFactura(producto, Double.parseDouble(panel_tv_precio.getText().toString()));
                            panel_layout_precio.setVisibility(View.GONE);

                        } else {
                            generarFactura(producto, producto.getPrecioUnitario1());
                        }
                    }
                }
            });

            mi_recicler_teclado.setHasFixedSize(true);
            mi_recicler_teclado.setLayoutManager(miGridlayout);
            mi_recicler_teclado.setItemAnimator(new DefaultItemAnimator());
            mi_recicler_teclado.setAdapter(miAdapter_teclado);

            TecladoAdaptador miAdapter_teclado_numerico = new TecladoAdaptador(teclasnumericas(), this, R.layout.card_tecla_num_panel_teclado, 2, new TecladoAdaptador.MyItemClick() {
                @Override
                public void listener(ModelTeclas modelTeclas, int position) {

                    if (panel_layout_precio.getVisibility() == View.GONE) {
                        panel_layout_precio.setVisibility(View.VISIBLE);
                        panel_tv_precio.setText(modelTeclas.getTexto());
                    } else {

                        panel_tv_precio.setText(String.format("%s%s", panel_tv_precio.getText().toString(), modelTeclas.getTexto()));
                    }
                }
            });

            mi_recicler_teclado_numerico.setHasFixedSize(true);
            mi_recicler_teclado_numerico.setLayoutManager(miGridlayoutnumerico);
            mi_recicler_teclado_numerico.setItemAnimator(new DefaultItemAnimator());
            mi_recicler_teclado_numerico.setAdapter(miAdapter_teclado_numerico);


        } else {

            panel_teclado.setVisibility(View.GONE);
            panel_factura.setVisibility(View.VISIBLE);
            panel_layout_cliente.setVisibility(View.VISIBLE);
            panel_layout_productos.setVisibility(View.VISIBLE);
        }

    }


    private List<ModelTeclas> teclasnumericas() {

        return new ArrayList<ModelTeclas>() {{
            add(new ModelTeclas("7", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("8", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("9", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("4", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("5", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("6", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("1", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("2", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("3", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("00", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas("0", "", getResources().getColor(R.color.colorgris)));
            add(new ModelTeclas(".", "", getResources().getColor(R.color.colorgris)));
        }};
    }


    //metodo el cual al ingresar un nuevo usuario a la base de datos mediante el boton de agragar cliente de la factura
    //se efectuara y buscara el cliente ingresado y lo colocara de primera opcion por defecto

    @Override
    public void onChange(RealmList<ModelCliente> modelClientes) {
        datosClientes = new ArrayList<String>() {
            {
                for (int i = 0; i < listaclientes.size(); i++) {

                    ModelCliente obtenerCliente = listaclientes.get(i);

                    if (obtenerCliente != null) {

                        add(obtenerCliente.getNombre());
                    }
                }
            }
        };

        cliente = listaclientes.get(0);
        panel_spinnercliente.setText(datosClientes.get(0));

    }


    @Override
    protected void onResume() {
        validandoSerieDelDocumento();
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        mostrarDialogo();

    }



    private boolean laFacturaEsUnaBoleta() {
        return tipoDocumento.equals(getString(R.string.codigo_de_boletaDeVenta));
    }


    private void enviarAConfiguracion(){

        Snackbar.make(findViewById(R.id.factura_xml), getString(R.string.snackbar_factura), Snackbar.LENGTH_INDEFINITE).setAction("ir a configuracion", new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent enviar = new Intent(Factura.this, Opciones.class);
                enviar.putExtra(getString(R.string.enviar_usuario),idUsuario);
                startActivity(enviar);

            }
        }).show();




    }




    //Metodo que muestra un díalogo de confirmacion de salida
    private void mostrarDialogo(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(Factura.this);
        dialog.setTitle("Confirmar");
        dialog.setMessage("¿Desea salir?");
        //dialog.setIcon(R.drawable.ic_advertencia);
        dialog.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}