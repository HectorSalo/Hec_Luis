package com.example.proyectthefactoyhka.catalogo_cliente.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;

import com.example.proyectthefactoyhka.ventana_principal.TestVariablesGenerales;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.acerca_de.Acerca_de;
import com.example.proyectthefactoyhka.ajustes.Ajustes;
import com.example.proyectthefactoyhka.ajustes.unidades.activity.UnidadesMain;
import com.example.proyectthefactoyhka.catalogo_cliente.adaptador.ClienteAdaptador;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion.Conexion_Cliente;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente.VentAddCliente;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente.VentVerMasDetallesClient;
import com.example.proyectthefactoyhka.catalogo_producto.activity.ProductosMain;
import com.example.proyectthefactoyhka.documento_emitido.activity.DocumentosMain;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity.Factura;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeClientes;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerListaDeClientes;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.example.proyectthefactoyhka.ventana_principal.PrincipalActivity;
import com.nbsp.materialfilepicker.MaterialFilePicker;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class ClientesMain extends AppCompatActivity implements Conexion_Cliente, View.OnClickListener, TextWatcher, RealmChangeListener<RealmList<ModelCliente>> {


    private Realm realm;
    private RealmList<ModelCliente> listacliente;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private ClienteAdaptador miAdapter;
    private EditText edi_buscador_cliente;
    private LinearLayout layout_cliente_buscar;
    private ModelUsuario usuarios;
    private Toolbar toolbar;
    private final int CODIGO_PERMISO = 600;
    private int idUsuario;
    private LinearLayout nav_view_layout_catalogo;
    private DrawerLayout drawerLayout;
    private RelativeLayout view_list_clientes_vacios;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes_main);

        mostrarToolbar();
        cast();
        recibirDatosDeOtrosActivitys();
        baseDeDatos();
        funcionDelAdaptador(listacliente);
        verificarLista();
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.fabt_catalogo_clientes:

                //accion el cual llamara a la clase VentAddCliente para lograr crear un producto

                VentAddCliente ventanaDialogo = new VentAddCliente();
                Bundle datos = new Bundle();
                datos.putInt(getString(R.string.enviar_usuario), idUsuario);
                ventanaDialogo.setArguments(datos);
                ventanaDialogo.show(getSupportFragmentManager(), "producto");

                break;


            case R.id.bt_buscador_cliente:
                //accion el cual ocultara el el layout del ediText filtrador limpiara los carateres colocados y mostrara nuevamente el toolbar

                layout_cliente_buscar.setVisibility(View.GONE);
                toolbar.setVisibility(View.VISIBLE);
                edi_buscador_cliente.getText().clear();

                break;


            // botones del navigation view

            case R.id.bt_nav_inicio:

                enviarDatos(PrincipalActivity.class );

                break;

            case R.id.bt_nav_catalogo:

                if(nav_view_layout_catalogo.getVisibility()== View.GONE){
                    nav_view_layout_catalogo.setVisibility(View.VISIBLE);
                }else {
                    nav_view_layout_catalogo.setVisibility(View.GONE);
                }

                break;

            case R.id.bt_nav_unidades:

                enviarDatos(UnidadesMain.class);

                break;

            case R.id.bt_nav_documento:

                enviarDatos(DocumentosMain.class);

                break;

            case R.id.bt_nav_ajustes:

                enviarDatos(Ajustes.class);

                break;

            case R.id.bt_nav_acerca_De:

                enviarDatos(Acerca_de.class);

                break;

            case R.id.bt_nav_cerrar_sesion:


                break;


        }
    }


    //opciones de accion de los botones que estan alojados en context menu del toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;
            case R.id.menu_tab_eliminar:
                //accion el cual eliminara todas cardview alojadas en el reciclerView y notificara al recycle de dicho cambio

                realm.beginTransaction();
                usuarios.getDatos_clientes().removeAll(listacliente);
                realm.commitTransaction();
                miAdapter.notifyDataSetChanged();
                return true;

            case R.id.menu_tab_buscar:
                //accion el cual mostrara el layout del ediText filtrador y ocultara el toolbar

                layout_cliente_buscar.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.GONE);

                return true;

            case R.id.menu_tab_imp:

                permisos();

                return true;

            default:

                return super.onOptionsItemSelected(item);
        }
    }


    private void recibirDatosDeOtrosActivitys() {
        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            idUsuario = extra.getInt(getString(R.string.enviar_usuario));
        }
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddClienteAdapater  se presiona la accion del boton de editar este
    // llamara a ventAddCliente.Class con la diferencia que este enviara una posicion el cual sera utilizada para poder recatar los datos y asi poder editar los datos correspondiente
    @Override
    public void llamarVentanaEditarCliente(ModelCliente datoDelCliente) {

        VentAddCliente ventanaDialogo = new VentAddCliente();
        Bundle datosedi = new Bundle();
        datosedi.putInt(getString(R.string.enviar_usuario), idUsuario);
        datosedi.putString("ruc", datoDelCliente.getIdentificacion());
        ventanaDialogo.setArguments(datosedi);
        ventanaDialogo.show(getSupportFragmentManager(), "editar");

    }


    // interface que se inicializa cada vez que en el contexMenu se presiona la accion del boton de Generar FActura y este se encargara de obtener los datos
    //de la cardView seleccionada y lo enviara a una nueva activity llamada Factura.Class
    @Override
    public void generarFacturadeCliente(ModelCliente datoDelCliente) {

        Intent enviar = new Intent(this, Factura.class);
        Bundle bundle = new Bundle();
        bundle.putInt(getString(R.string.enviar_usuario), idUsuario);
        bundle.putString("datoClien", datoDelCliente.getIdentificacion());
        bundle.putString("tipoDocumento","03");
        enviar.putExtras(bundle);
        startActivity(enviar);
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddClienteAdapater  se presiona la accion del boton de ventVerMasDetalle
    // obteniendo los datos a travez del la posicion obtenida del adaptador y enviandolos a la clase VermasDellesCliente.Class
    @Override
    public void detallesDelCliente(ModelCliente datoDelCliente) {

        new VentVerMasDetallesClient(ClientesMain.this, datoDelCliente.getNombre(),
                datoDelCliente.getApellido(), datoDelCliente.getJurisdiccion(), datoDelCliente.getTelefono(),
                datoDelCliente.getIdentificacion(), datoDelCliente.getDatoVerificador(), datoDelCliente.getCorreo(),
                datoDelCliente.getCodigoPais(), datoDelCliente.getProvincia(), datoDelCliente.getDistrito(),
                datoDelCliente.getCorreginmiento(), datoDelCliente.getDireccion(), datoDelCliente.getJurisdiccion());
    }

    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddProductosAdapater  se presiona la accion del boton eliminar
    //este eliminara los datos obtenido a travez de la posicion que fue enviada desde el adaptador
    @Override
    public void borrarCliente(ModelCliente datoDelCliente) {

        realm.beginTransaction();
        datoDelCliente.deleteFromRealm();
        realm.commitTransaction();


    }


    //metodo que filtrara los produtos colocado en el editext Filtrador este posee 3 metodos uno de antes/durante/depues el codigo sera implementado en el metodo durante
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

        String userInput = s.toString().toLowerCase();
        RealmQuery<ModelCliente> query = listacliente.where().contains("identificacion", userInput).or().contains("nombre", userInput);
        RealmResults<ModelCliente> newList = query.findAll();
        funcionDelAdaptador(newList);
        miAdapter.notifyDataSetChanged();

    }

    @Override
    public void afterTextChanged(Editable s) {
    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar los productos
    //este recibira la lista de producto y generara el elemento en el layout
    private void funcionDelAdaptador(List<ModelCliente> cliente) {
        miAdapter = new ClienteAdaptador(cliente, R.layout.cardview_clientes, this, ClientesMain.this);
        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);
    }


    private void permisos() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso()) {
                //ha aceptado

                new MaterialFilePicker()
                        .withActivity(this)
                        .withRequestCode(CODIGO_PERMISO)
                        .withHiddenFiles(true)
                        .start();

            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                } else {
                    mostrarToast();
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                }
            }

        } else {
            viejaVersion();
        }
    }


// este metodo sera llamado por el metodo permisos si la version es menor a la version 25

    private void viejaVersion() {

        if (chequearPermiso()) {


            new MaterialFilePicker()
                    .withActivity(this)
                    .withRequestCode(CODIGO_PERMISO)
                    .withHiddenFiles(true)
                    .start();
        } else {
            mostrarToast();
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso() {

        int result = this.checkCallingOrSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED;

    }


    //este metodo sera llamado  si la version es mayor a la 25 es un metodo para identificar que tipo
    // de permiso esta pidiendo en tiempo de ejecucion la app y asi ejecutar la peticion a travez de
    // un codigo ya declarado de manera global

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        switch (requestCode) {
            case CODIGO_PERMISO:

                if (grantResults.length > 0) {

                    String permission = permissions[0];
                    int result = grantResults[0];

                    if (permission.equals(WRITE_EXTERNAL_STORAGE)) {
                        if (result == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso();
                            }

                        } else {
                            mostrarToast();
                        }
                    }
                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                break;
        }
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {
        miRecicler = findViewById(R.id.mi_recicler_view_cliente);
        miLayoutManager = new LinearLayoutManager(this);

        FloatingActionButton fabt_catalogo_clientes = findViewById(R.id.fabt_catalogo_clientes);
        fabt_catalogo_clientes.setOnClickListener(this);

        ImageButton bt_buscador_cliente = findViewById(R.id.bt_buscador_cliente);
        bt_buscador_cliente.setOnClickListener(this);

        edi_buscador_cliente = findViewById(R.id.edi_buscador_cliente);
        edi_buscador_cliente.addTextChangedListener(this);

        layout_cliente_buscar = findViewById(R.id.layout_cliente_buscar);

        //funciones del navigation view

        drawerLayout = findViewById(R.id.drawer_activity_principal);

        View bt_nav_inicio = findViewById(R.id.bt_nav_inicio);
        bt_nav_inicio.setOnClickListener(this);

        View bt_nav_catalogo = findViewById(R.id.bt_nav_catalogo);
        bt_nav_catalogo.setOnClickListener(this);

        nav_view_layout_catalogo = findViewById(R.id.nav_view_layout_catalogo);



        View bt_nav_unidades = findViewById(R.id.bt_nav_unidades);
        bt_nav_unidades.setOnClickListener(this);

        View bt_nav_documento = findViewById(R.id.bt_nav_documento);
        bt_nav_documento.setOnClickListener(this);

        View bt_nav_ajustes = findViewById(R.id.bt_nav_ajustes);
        bt_nav_ajustes.setOnClickListener(this);

        View bt_nav_acerca_De = findViewById(R.id.bt_nav_acerca_De);
        bt_nav_acerca_De.setOnClickListener(this);

        View bt_nav_cerrar_sesion = findViewById(R.id.bt_nav_cerrar_sesion);
        bt_nav_cerrar_sesion.setOnClickListener(this);


        //--------------------------------------------------------------------------------------

        view_list_clientes_vacios = findViewById(R.id.view_list_clientes_vacios);
    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", TestVariablesGenerales.idUsuario).findFirst();
        if (usuarios != null)
            listacliente = usuarios.getDatos_clientes();
        listacliente.addChangeListener(this);
    }


    // inflamos el layout context menu que aparecera en el toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_toolbar, menu);
        return super.onCreateOptionsMenu(menu);
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast() {
        Toast.makeText(ClientesMain.this, R.string.login_validar_permiso_denegado, Toast.LENGTH_SHORT).show();
    }


    //metodo que  configura el toolbar
    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbarclientes);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ClientesMain.this.setTitle(R.string.toolbar_Catalogo_clientes);
    }


    @Override
    public void onChange(RealmList<ModelCliente> modelClientes) {

        miAdapter.notifyDataSetChanged();
        verificarLista();

    }


    @Override
    public void onBackPressed() {
        finish();
    }




    private void servicioRetrofit2(){

        ModelPeticionDeClientes peticionDeClientes = new ModelPeticionDeClientes("","","");

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelObtenerListaDeClientes> obtenerListaDeClientes= service.peticionDeClientes(peticionDeClientes);
        obtenerListaDeClientes.enqueue(new Callback<ModelObtenerListaDeClientes>() {

            ModelObtenerListaDeClientes listaDeClientes = new ModelObtenerListaDeClientes();

            @Override
            public void onResponse(Call<ModelObtenerListaDeClientes> call, Response<ModelObtenerListaDeClientes> response) {

                listaDeClientes= response.body();



            }

            @Override
            public void onFailure(Call<ModelObtenerListaDeClientes> call, Throwable t) {

            }
        });

    }


        private void verificarLista(){

            if (listacliente.size()==0){
                view_list_clientes_vacios.setVisibility(View.VISIBLE);
            }else {
                view_list_clientes_vacios.setVisibility(View.GONE);
            }

        }



    private void enviarDatos(Class clase) {
        Intent enviar = new Intent(ClientesMain.this, clase);
        enviar.putExtra(getString(R.string.enviar_usuario), idUsuario);
        enviar.putExtra("tipoDocumento","03");
        startActivity(enviar);
        finish();
    }

}