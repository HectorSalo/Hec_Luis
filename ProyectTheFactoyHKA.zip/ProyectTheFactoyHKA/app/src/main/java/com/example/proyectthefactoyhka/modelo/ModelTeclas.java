package com.example.proyectthefactoyhka.modelo;


import com.example.proyectthefactoyhka.configuracion_realm_dataBase.MyApplication;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;
import io.realm.annotations.Required;

public class ModelTeclas extends RealmObject{

   @PrimaryKey
    private int id;
   @Required
   private String texto;

   private String codigo1;

   private Integer fondo;


   public ModelTeclas() {
   }

    public ModelTeclas(String texto, String codigo1,Integer fondo) {
       this.id= MyApplication.IdTecl.incrementAndGet();
       this.texto = texto;
       this.codigo1 = codigo1;
        this.fondo = fondo;

    }

    public int getId() { return id; }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getCodigo1() {
        return codigo1;
    }

    public void setCodigo1(String codigo1) {
        this.codigo1 = codigo1;
    }

    public Integer getFondo() {
        return fondo;
    }

    public void setFondo(Integer fondo) {
        this.fondo = fondo;
    }
}
