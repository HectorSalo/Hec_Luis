package com.example.proyectthefactoyhka.modelo.eviarDatos;

import android.os.Parcel;
import android.os.Parcelable;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.ModelPago;
import com.example.proyectthefactoyhka.modelo.ModelReceptor;
import com.example.proyectthefactoyhka.modelo.ModelTotales;
import java.util.List;

public class ModelDocumentoElectronico implements Parcelable {

    private String codigoTipoOperacion;
    private String correlativo;
    private ModelCliente emisor;
    private String fechaEmision;
    private String horaEmision;
    private ModelPago pago;
    private List<ModelFacturacion> producto;
    private ModelDescuentosGlobales descuentosGlobales;
    private ModelReceptor receptor;
    private String serie;
    private String tipoDocumento;
    private ModelTotales totales;



    public ModelDocumentoElectronico(String codigoTipoOperacion, String fechaEmision, String horaEmision,String serie,  String tipoDocumento) {
        this.codigoTipoOperacion = codigoTipoOperacion;
        this.correlativo = correlativo;
        this.emisor = emisor;
        this.fechaEmision = fechaEmision;
        this.horaEmision = horaEmision;
        this.pago = pago;
        this.producto = producto;
        this.receptor = receptor;
        this.serie = serie;
        this.tipoDocumento = tipoDocumento;
        this.totales = totales;

    }


    protected ModelDocumentoElectronico(Parcel in) {
        codigoTipoOperacion = in.readString();
        correlativo = in.readString();
        emisor = in.readParcelable(ModelCliente.class.getClassLoader());
        fechaEmision = in.readString();
        horaEmision = in.readString();
        producto = in.createTypedArrayList(ModelFacturacion.CREATOR);
        descuentosGlobales = in.readParcelable(ModelDescuentosGlobales.class.getClassLoader());
        serie = in.readString();
        tipoDocumento = in.readString();
        totales = in.readParcelable(ModelTotales.class.getClassLoader());
    }

    public static final Creator<ModelDocumentoElectronico> CREATOR = new Creator<ModelDocumentoElectronico>() {
        @Override
        public ModelDocumentoElectronico createFromParcel(Parcel in) {
            return new ModelDocumentoElectronico(in);
        }

        @Override
        public ModelDocumentoElectronico[] newArray(int size) {
            return new ModelDocumentoElectronico[size];
        }
    };

    public String getCodigoTipoOperacion() {
        return codigoTipoOperacion;
    }

    public void setCodigoTipoOperacion(String codigoTipoOperacion) {
        this.codigoTipoOperacion = codigoTipoOperacion;
    }

    public String getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(String correlativo) {
        this.correlativo = correlativo;
    }

    public ModelCliente getEmisor() {
        return emisor;
    }

    public void setEmisor(ModelCliente emisor) {
        this.emisor = emisor;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getHoraEmision() {
        return horaEmision;
    }

    public void setHoraEmision(String horaEmision) {
        this.horaEmision = horaEmision;
    }

    public ModelPago getPago() {
        return pago;
    }

    public void setPago(ModelPago pago) {
        this.pago = pago;
    }

    public List<ModelFacturacion> getProducto() {
        return producto;
    }

    public void setProducto(List<ModelFacturacion> producto) {
        this.producto = producto;
    }

    public ModelDescuentosGlobales getDescuentosGlobales() {
        return descuentosGlobales;
    }

    public void setDescuentosGlobales(ModelDescuentosGlobales descuentosGlobales) {
        this.descuentosGlobales = descuentosGlobales;
    }

    public ModelReceptor getReceptor() {
        return receptor;
    }

    public void setReceptor(ModelReceptor receptor) {
        this.receptor = receptor;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public ModelTotales getTotales() {
        return totales;
    }

    public void setTotales(ModelTotales totales) {
        this.totales = totales;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(codigoTipoOperacion);
        dest.writeString(correlativo);
        dest.writeParcelable(emisor, flags);
        dest.writeString(fechaEmision);
        dest.writeString(horaEmision);
        dest.writeTypedList(producto);
        dest.writeParcelable(descuentosGlobales, flags);
        dest.writeString(serie);
        dest.writeString(tipoDocumento);
        dest.writeParcelable(totales, flags);
    }
}
