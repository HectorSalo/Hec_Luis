package com.example.proyectthefactoyhka.modelo.eviarDatos;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ModelFacturacion implements Parcelable {

    @SerializedName("IGV")
    private IGV iGV;

    @SerializedName("ISC")
    private ISC iSC;

    @SerializedName("IVAP")
    private IVAP iVAP;

    @SerializedName("cantidad")
    private String cantidad;

    @SerializedName("cargo")
    private ModelCargo cargo;

    @SerializedName("codigoGS1")
    private String codigoGS1;

    @SerializedName("codigoPLU")
    private String codigoPLU;

    @SerializedName("codigoPLUSunat")
    private String codigoPLUSunat;

    @SerializedName("descripcion")
    private String descripcion;

    @SerializedName("descuento")
    private ModelDescuento descuento;

    @SerializedName("detalleProducto")
    private String detalleProducto;

    @SerializedName("montoTotalImpuestoItem")
    private String montoTotalImpuestoItem;

    @SerializedName("numeroOrden")
    private String numeroOrden;

    @SerializedName("numeroPlacaVehiculo")
    private String numeroPlacaVehiculo;

    @SerializedName("otrosTributos")
    private List<ModelOtrosTributos> otrosTributos;

    @SerializedName("precioVentaUnitarioItem")
    private String precioVentaUnitarioItem;

    @SerializedName("unidadMedida")
    private String unidadMedida;

    @SerializedName("valorReferencialUnitario")
    private String valorReferencialUnitario;

    @SerializedName("valorUnitarioBI")
    private String valorUnitarioBI;

    @SerializedName("valorVentaItemQxBI")
    private String valorVentaItemQxBI;


    public ModelFacturacion() {
    }

    public ModelFacturacion(IGV iGV, ISC iSC, IVAP iVAP, String cantidad, ModelCargo cargo, String codigoGS1, String codigoPLU, String codigoPLUSunat,
                            String descripcion, ModelDescuento descuento, String detalleProducto, String montoTotalImpuestoItem, String numeroOrden, String numeroPlacaVehiculo,
                            List<ModelOtrosTributos> otrosTributos, String precioVentaUnitarioItem, String unidadMedida, String valorReferencialUnitario, String valorUnitarioBI,
                            String valorVentaItemQxBI) {
        this.iGV = iGV;
        this.iSC = iSC;
        this.iVAP = iVAP;
        this.cantidad = cantidad;
        this.cargo = cargo;
        this.codigoGS1 = codigoGS1;
        this.codigoPLU = codigoPLU;
        this.codigoPLUSunat = codigoPLUSunat;
        this.descripcion = descripcion;
        this.descuento = descuento;
        this.detalleProducto = detalleProducto;
        this.montoTotalImpuestoItem = montoTotalImpuestoItem;
        this.numeroOrden = numeroOrden;
        this.numeroPlacaVehiculo = numeroPlacaVehiculo;
        this.otrosTributos = otrosTributos;
        this.precioVentaUnitarioItem = precioVentaUnitarioItem;
        this.unidadMedida = unidadMedida;
        this.valorReferencialUnitario = valorReferencialUnitario;
        this.valorUnitarioBI = valorUnitarioBI;
        this.valorVentaItemQxBI = valorVentaItemQxBI;
    }


    protected ModelFacturacion(Parcel in) {
        iGV = in.readParcelable(IGV.class.getClassLoader());
        iSC = in.readParcelable(ISC.class.getClassLoader());
        cantidad = in.readString();
        codigoGS1 = in.readString();
        codigoPLU = in.readString();
        codigoPLUSunat = in.readString();
        descripcion = in.readString();
        descuento = in.readParcelable(ModelDescuento.class.getClassLoader());
        detalleProducto = in.readString();
        montoTotalImpuestoItem = in.readString();
        numeroOrden = in.readString();
        numeroPlacaVehiculo = in.readString();
        precioVentaUnitarioItem = in.readString();
        unidadMedida = in.readString();
        valorReferencialUnitario = in.readString();
        valorUnitarioBI = in.readString();
        valorVentaItemQxBI = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(iGV, flags);
        dest.writeParcelable(iSC, flags);
        dest.writeString(cantidad);
        dest.writeString(codigoGS1);
        dest.writeString(codigoPLU);
        dest.writeString(codigoPLUSunat);
        dest.writeString(descripcion);
        dest.writeParcelable(descuento, flags);
        dest.writeString(detalleProducto);
        dest.writeString(montoTotalImpuestoItem);
        dest.writeString(numeroOrden);
        dest.writeString(numeroPlacaVehiculo);
        dest.writeString(precioVentaUnitarioItem);
        dest.writeString(unidadMedida);
        dest.writeString(valorReferencialUnitario);
        dest.writeString(valorUnitarioBI);
        dest.writeString(valorVentaItemQxBI);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelFacturacion> CREATOR = new Creator<ModelFacturacion>() {
        @Override
        public ModelFacturacion createFromParcel(Parcel in) {
            return new ModelFacturacion(in);
        }

        @Override
        public ModelFacturacion[] newArray(int size) {
            return new ModelFacturacion[size];
        }
    };

    public IGV getiGV() {
        return iGV;
    }

    public void setiGV(IGV iGV) {
        this.iGV = iGV;
    }

    public ISC getiSC() {
        return iSC;
    }

    public void setiSC(ISC iSC) {
        this.iSC = iSC;
    }

    public IVAP getiVAP() {
        return iVAP;
    }

    public void setiVAP(IVAP iVAP) {
        this.iVAP = iVAP;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public ModelCargo getCargo() {
        return cargo;
    }

    public void setCargo(ModelCargo cargo) {
        this.cargo = cargo;
    }

    public String getCodigoGS1() {
        return codigoGS1;
    }

    public void setCodigoGS1(String codigoGS1) {
        this.codigoGS1 = codigoGS1;
    }

    public String getCodigoPLU() {
        return codigoPLU;
    }

    public void setCodigoPLU(String codigoPLU) {
        this.codigoPLU = codigoPLU;
    }

    public String getCodigoPLUSunat() {
        return codigoPLUSunat;
    }

    public void setCodigoPLUSunat(String codigoPLUSunat) {
        this.codigoPLUSunat = codigoPLUSunat;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public ModelDescuento getDescuento() {
        return descuento;
    }

    public void setDescuento(ModelDescuento descuento) {
        this.descuento = descuento;
    }

    public String getDetalleProducto() {
        return detalleProducto;
    }

    public void setDetalleProducto(String detalleProducto) {
        this.detalleProducto = detalleProducto;
    }

    public String getMontoTotalImpuestoItem() {
        return montoTotalImpuestoItem;
    }

    public void setMontoTotalImpuestoItem(String montoTotalImpuestoItem) {
        this.montoTotalImpuestoItem = montoTotalImpuestoItem;
    }

    public String getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(String numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public String getNumeroPlacaVehiculo() {
        return numeroPlacaVehiculo;
    }

    public void setNumeroPlacaVehiculo(String numeroPlacaVehiculo) {
        this.numeroPlacaVehiculo = numeroPlacaVehiculo;
    }

    public List<ModelOtrosTributos> getOtrosTributos() {
        return otrosTributos;
    }

    public void setOtrosTributos(List<ModelOtrosTributos> otrosTributos) {
        this.otrosTributos = otrosTributos;
    }

    public String getPrecioVentaUnitarioItem() {
        return precioVentaUnitarioItem;
    }

    public void setPrecioVentaUnitarioItem(String precioVentaUnitarioItem) {
        this.precioVentaUnitarioItem = precioVentaUnitarioItem;
    }

    public String getUnidadMedida() {
        return unidadMedida;
    }

    public void setUnidadMedida(String unidadMedida) {
        this.unidadMedida = unidadMedida;
    }

    public String getValorReferencialUnitario() {
        return valorReferencialUnitario;
    }

    public void setValorReferencialUnitario(String valorReferencialUnitario) {
        this.valorReferencialUnitario = valorReferencialUnitario;
    }

    public String getValorUnitarioBI() {
        return valorUnitarioBI;
    }

    public void setValorUnitarioBI(String valorUnitarioBI) {
        this.valorUnitarioBI = valorUnitarioBI;
    }

    public String getValorVentaItemQxBI() {
        return valorVentaItemQxBI;
    }

    public void setValorVentaItemQxBI(String valorVentaItemQxBI) {
        this.valorVentaItemQxBI = valorVentaItemQxBI;
    }
}
