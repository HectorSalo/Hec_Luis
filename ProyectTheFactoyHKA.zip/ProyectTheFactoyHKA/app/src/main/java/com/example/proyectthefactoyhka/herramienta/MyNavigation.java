package com.example.proyectthefactoyhka.herramienta;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.Nullable;

public class MyNavigation extends Activity {




    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




    }
}
