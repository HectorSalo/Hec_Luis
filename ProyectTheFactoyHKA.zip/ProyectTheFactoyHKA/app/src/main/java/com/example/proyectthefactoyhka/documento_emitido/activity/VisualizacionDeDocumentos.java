package com.example.proyectthefactoyhka.documento_emitido.activity;

import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.documento_emitido.adaptador.VisualizadorDeDocAdaptador;
import com.example.proyectthefactoyhka.documento_emitido.ventana_emergente.ComunicacionDeBaja;
import com.example.proyectthefactoyhka.herramienta.HerramientasPDF;
import com.example.proyectthefactoyhka.herramienta.Notificaciones;
import com.example.proyectthefactoyhka.impresion.PrintService;
import com.example.proyectthefactoyhka.login.MainActivity;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDePDF;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelVisDoc;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerPDF;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.google.gson.Gson;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class VisualizacionDeDocumentos extends AppCompatActivity {


    private TextView visDoc_tv_razon_social,  visDoc_tv_fecha, visDoc_tv_subtotal,visDoc_tv_descuento,visDoc_tv_impuesto, visDoc_tv_total;
    private Realm realm;
    private RealmResults<ModelImpresora> impresoras;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private ArrayList<ModelVisDoc> productoVisualizados;
    private ModelDocumentoElectronico parseo;
    private DatosTemporales datosTemporales;
    private ModelFacturasParseada datosDocumento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizacion_de_documentos);

        cast();
        baseDeDatos();
        mostrarToolbar();
        recibirDatosDeOtrosActivitys();
        datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));

    }

    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        impresoras = realm.where(ModelImpresora.class).findAll();
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        miRecicler = findViewById(R.id.mi_recicler_vis_doc);
        miLayoutManager = new LinearLayoutManager(this);

        visDoc_tv_razon_social = findViewById(R.id.visDoc_tv_razon_social);
        visDoc_tv_fecha = findViewById(R.id.visDoc_tv_fecha);
        visDoc_tv_subtotal = findViewById(R.id.visDoc_tv_subtotal);
        visDoc_tv_descuento = findViewById(R.id.visDoc_tv_descuento);
        visDoc_tv_impuesto = findViewById(R.id.visDoc_tv_impuesto);
        visDoc_tv_total = findViewById(R.id.visDoc_tv_total);
    }



    //metodo el cual recibira datos del DocumentosMain para identificar el actual usuario y recibir la factura parseada
    private void recibirDatosDeOtrosActivitys() {

        final Intent intent = getIntent();
        if (intent != null) {

             datosDocumento = intent.getParcelableExtra("facturaParseada");




            Gson gson = new Gson();
            parseo = gson.fromJson(datosDocumento.getFactura(), ModelDocumentoElectronico.class);

            visDoc_tv_razon_social.setText(parseo.getReceptor().getRazonSocial());
            visDoc_tv_fecha.setText(parseo.getFechaEmision());
            visDoc_tv_subtotal.setText(parseo.getTotales().getSubtotalValorVenta());
            visDoc_tv_total.setText(parseo.getTotales().getImporteTotalVenta());

            if (parseo.getDescuentosGlobales()!=null){ visDoc_tv_descuento.setText(parseo.getDescuentosGlobales().getMonto());
            }else{ visDoc_tv_descuento.setText(getString(R.string.text_numero)); }

            visDoc_tv_impuesto.setText(parseo.getTotales().getMontoTotalImpuestos());

           final List<ModelFacturacion> listaproducto = parseo.getProducto();

            productoVisualizados = new ArrayList<ModelVisDoc>(){
                {
                    for (int i = 0; i < listaproducto.size(); i++){

                        ModelFacturacion obtenerProducto = listaproducto.get(i);

                        add(new ModelVisDoc(obtenerProducto.getDescripcion(),
                                parseo.getProducto().get(i).getCantidad()+"x S/"+parseo.getProducto().get(i).getValorUnitarioBI(),
                                obtenerProducto.getPrecioVentaUnitarioItem()));
                    }
                }
            };
}
        funcionDelAdaptador(productoVisualizados);
    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar los productos
    //este recibira la lista de productos y generara el elemento en el layout

    private void funcionDelAdaptador(List<ModelVisDoc> documento) {

        RecyclerView.Adapter miAdapter = new VisualizadorDeDocAdaptador(documento, R.layout.cardview_visualizacion_documentos);
        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);
    }



    // menu que aparecera enlazado al toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_visulizacion_de_doc,menu);

        return super.onCreateOptionsMenu(menu);
    }


    //metodo de accion de los botones que estan alojados en el toolbar


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {

            case R.id.menu_vis_doc_impri:
                iniciarServicioImpresion();
                return true;

            case R.id.menu_vis_doc_desc:
                //primero verificamos si ya se encuenta almacenado el archivo
                String ruta = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE).getString(MainActivity.PREFERENCE_DIR_PDF, "");
                File invoicePdf = new File(ruta, datosDocumento.getId() + ".pdf");
                if(!invoicePdf.exists()) {
                    iniciarDescargaPdf();
                    Notificaciones.generar(getApplicationContext(),datosDocumento.getId(),ruta);
                }else{
                    Toast.makeText(this, "Archivo PDF descargado", Toast.LENGTH_SHORT).show();
                }
                return true;

            case R.id.menu_vis_doc_enviar:
                Toast.makeText(this, "asignar enviar", Toast.LENGTH_SHORT).show();
                return true;


            case R.id.menu_vis_doc_comunicacion_de_baja:

                ComunicacionDeBaja ventanaDialogo = new ComunicacionDeBaja();
                Bundle datoscomunicacionDeBaja = new Bundle();
                datoscomunicacionDeBaja.putString("documento", datosDocumento.getId());
                ventanaDialogo.setArguments(datoscomunicacionDeBaja);
                ventanaDialogo.show(getSupportFragmentManager(), "comunicacion De Baja");

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //Crea el Service Intent para la impresión de documentos
    private void iniciarServicioImpresion(){

        Intent intent = new Intent(getApplicationContext(), PrintService.class);
        intent.setAction(PrintService.ACTION_PRINT);
        intent.putExtra(PrintService.EXTRA_DOC, (Bundle) getIntent().getParcelableExtra("facturaParseada"));
        intent.putExtra(PrintService.EXTRA_PRINTERS,obtenerImpresoras());
        startService(intent);
    }

    //Crea una lista de impresoras del Arreglo Realm para poder ser enviada al servicio de impresión
    private ArrayList<ModelImpresora> obtenerImpresoras(){
        ArrayList<ModelImpresora> impresoras = new ArrayList<>();
        for(ModelImpresora impresora: this.impresoras){

            impresoras.add(new ModelImpresora(impresora));

        }
        return impresoras;
    }

    //configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_visual_documentos);
        setSupportActionBar(toolbar);
        VisualizacionDeDocumentos.this.setTitle(R.string.toolbar_vis_doc);
    }


    private void iniciarDescargaPdf(){

        ModelPeticionDePDF datosParaPDF = new ModelPeticionDePDF(datosTemporales.obtenerUsuario().getClave(),parseo.getEmisor().getIdentificacion()+"-"+datosDocumento.getId(),"PDF",datosTemporales.obtenerUsuario().getUsuario());

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelObtenerPDF> obtenerPDF = service.peticionDePDF(datosParaPDF);
        obtenerPDF.enqueue(new Callback<ModelObtenerPDF>() {

            ModelObtenerPDF pdf = new ModelObtenerPDF();
            @Override
            public void onResponse(Call<ModelObtenerPDF> call, Response<ModelObtenerPDF> response) {

                pdf = response.body();
                if(pdf.getArchivo()!=null){
                    String ruta = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE).getString(MainActivity.PREFERENCE_DIR_PDF, "");
                    boolean res = HerramientasPDF.guardarPdf(pdf.getArchivo(),datosDocumento.getId(),ruta);
                    if(res){
                        Toast.makeText(getApplicationContext(), "Archivo PDF descargado", Toast.LENGTH_SHORT).show();
                        Notificaciones.generar(getApplicationContext(),datosDocumento.getId(),ruta);
                    }
                }
            }

            @Override
            public void onFailure(Call<ModelObtenerPDF> call, Throwable t) {

            }
        });

    }




}
