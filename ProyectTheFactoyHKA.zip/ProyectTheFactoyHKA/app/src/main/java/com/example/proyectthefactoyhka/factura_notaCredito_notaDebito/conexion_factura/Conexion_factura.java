package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.conexion_factura;

import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;

public interface Conexion_factura {


    void borrarFactura(int posicion,String montoDeVenta);
    void funcionDePorcentaje(int posicion,ModelFacturacion datosFactura);
    void aplicarPorcentaje(int posicion,ModelFacturacion datosFactura,double monto);

}
