package com.example.proyectthefactoyhka.ajustes.impresoras.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.impresoras.adaptador.ImpresorasAdapter;
import com.example.proyectthefactoyhka.ajustes.impresoras.comunicacion.Conexion_Impresora;
import com.example.proyectthefactoyhka.ajustes.impresoras.ventana_emergente.VentAddImpresora;
import com.example.proyectthefactoyhka.impresion.PrintService;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;


import io.realm.Realm;
import io.realm.RealmResults;

import static android.Manifest.permission.BLUETOOTH;

public class Impresoras extends AppCompatActivity implements View.OnClickListener , Conexion_Impresora {



    private Realm realm;
    private RealmResults<ModelImpresora> impresoras;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private RecyclerView.Adapter miAdapter;
    private final int CODIGO_PERMISO = 810;
    private Switch card_impr_activar_impr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impresoras);

        mostrarToolbar();
        cast();
        baseDeDatos();
        funcionDelAdaptador();
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.bt_agregar_impresora:

                permisos();

                break;
        }

    }


    //interface que se inicializa cada vez que VentAddImpresora.Class presiona la accion del boton de aceptar y este se encargara de guardar los datos recibido a travez de la interface

    @Override
    public void crear_impresora(String interfaz, String nombre, String direccion, String ancho_papel, String caracter_por_linea, String gaveta, String pagina_de_codigo, String tipo_de_qr, String logo) {

        ModelImpresora modelo = new ModelImpresora(interfaz.equalsIgnoreCase("Bluetooth")? PrintService.PRINTER_BLUETOOTH:PrintService.PRINTER_ETHERNET,nombre,direccion,ancho_papel,caracter_por_linea,gaveta,pagina_de_codigo,tipo_de_qr,logo,false);

        realm.beginTransaction();
        realm.copyToRealmOrUpdate(modelo);
        realm.commitTransaction();
        miAdapter.notifyDataSetChanged();

    }

    @Override
    public void activar_impresora(boolean activado,int posicion) {

        realm.beginTransaction();
        impresoras.get(posicion).setEstado(activado);
        realm.commitTransaction();
        miAdapter.notifyDataSetChanged();

    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {
        miRecicler = findViewById(R.id.mi_recicler_view_impresora);
        miLayoutManager = new LinearLayoutManager(this);

        card_impr_activar_impr = findViewById(R.id.card_impr_activar_impr);


        Button bt_agregar_impresora = findViewById(R.id.bt_agregar_impresora);
        bt_agregar_impresora.setOnClickListener(this);
    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar los productos
    //este recibira la lista de producto y generara el elemento en el layout
    private void funcionDelAdaptador() {

        miAdapter = new ImpresorasAdapter(impresoras, R.layout.cardview_impresora, Impresoras.this, this,new ImpresorasAdapter.MyOnItemClick() {
            @Override
            public void onItem(ModelImpresora impresoras, int position) {

                Toast.makeText(Impresoras.this, position+"", Toast.LENGTH_SHORT).show();




            }
        });

        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);

    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        impresoras = realm.where(ModelImpresora.class).findAll();
    }


    private void permisos() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso(BLUETOOTH)) {
                //ha aceptado

                new VentAddImpresora(this,this);


            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.BLUETOOTH)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{BLUETOOTH}, CODIGO_PERMISO);
                } else {
                    //a rechazado
                    requestPermissions(new String[]{BLUETOOTH}, CODIGO_PERMISO);
                }
            }

        } else {
            viejaVersion();
        }
    }


// este metodo sera llamado por el metodo permisos si la version es menor a la version 25

    private void viejaVersion() {

        if (chequearPermiso(BLUETOOTH)) {

            new VentAddImpresora(this,this);

        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso(String permiso) {

        int result = this.checkCallingOrSelfPermission(permiso);
        return result == PackageManager.PERMISSION_GRANTED;

    }


    //este metodo sera llamado  si la version es mayor a la 25 es un metodo para identificar que tipo
    // de permiso esta pidiendo en tiempo de ejecucion la app y asi ejecutar la peticion a travez de
    // un codigo ya declarado de manera global

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        switch (requestCode) {
            case CODIGO_PERMISO:

                if (grantResults.length > 0) {

                    String permission = permissions[0];
                    int result = grantResults[0];

                    if (permission.equals(BLUETOOTH)) {
                        if (result == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso(BLUETOOTH);
                            }

                        } else {
                            mostrarToast(R.string.login_validar_permiso_denegado);
                        }
                    }
                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                break;
        }
    }


    //configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_impresora);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Impresoras.this.setTitle(R.string.toolbar_impresora);
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(Impresoras.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
