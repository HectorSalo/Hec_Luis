package com.example.proyectthefactoyhka.ventana_principal;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.proyectthefactoyhka.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;


public class DocsSemanaFragment extends Fragment {

    private OnFragmentInteractionListener mListener;

    private BarChart barChartSemana;

    public DocsSemanaFragment() {
        // Required empty public constructor
    }

    public static DocsSemanaFragment newInstance(String param1, String param2) {
        DocsSemanaFragment fragment = new DocsSemanaFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_docs_semana, container, false);

        barChartSemana = view.findViewById(R.id.bargraphSemana);

        cargarGraficoSemana();
        // Inflate the layout for this fragment
        return view;
    }


    private void cargarGraficoSemana() {
        ArrayList<String> diasSemana = new ArrayList<>();
        diasSemana.add(0, "Lunes");
        diasSemana.add(1, "Martes");
        diasSemana.add(2, "Miércoles");
        diasSemana.add(3, "Jueves");
        diasSemana.add(4, "Viernes");
        diasSemana.add(5, "Sábado");
        diasSemana.add(6, "Domingo");


        ArrayList<BarEntry> barEntries = new ArrayList<>();
        barEntries.add(new BarEntry(0.0f, 15));
        barEntries.add(new BarEntry(1.0f, 22));
        barEntries.add(new BarEntry(2.0f, 40));
        barEntries.add(new BarEntry(3.0f, 0));
        barEntries.add(new BarEntry(4.0f, 32));
        barEntries.add(new BarEntry(5.0f, 1));
        barEntries.add(new BarEntry(6.0f, 0));


        barChartSemana.animateY(3000);
        barChartSemana.setDescription(null);

        BarDataSet barDataSet = new BarDataSet(barEntries, "Boletas y Facturas");

        BarData barData = new BarData(barDataSet);

        XAxis xAxis = barChartSemana.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(diasSemana));
        xAxis.setPosition(XAxis.XAxisPosition.TOP);
        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(315);

        barChartSemana.setData(barData);
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
