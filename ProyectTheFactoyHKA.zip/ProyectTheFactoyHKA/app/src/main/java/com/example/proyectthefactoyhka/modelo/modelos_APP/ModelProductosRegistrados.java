package com.example.proyectthefactoyhka.modelo.modelos_APP;

public class ModelProductosRegistrados {

    private String objetos;
    private String total;


    public ModelProductosRegistrados(String objetos, String total) {
        this.objetos = objetos;
        this.total = total;
    }


    public String getObjetos() {
        return objetos;
    }

    public void setObjetos(String objetos) {
        this.objetos = objetos;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
