package com.example.proyectthefactoyhka.catalogo_producto.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import com.example.proyectthefactoyhka.R;

public class CarritoDeCompras extends AppCompatActivity {

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito_de_compras);


         mostrarToolbar();
    }


    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbar_productos_carrito);
        setSupportActionBar(toolbar);
        //Habilitamos el home button (flecha hacia atras)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        CarritoDeCompras.this.setTitle(R.string.toolbar_Catalogo_productos);
    }

}
