package com.example.proyectthefactoyhka.modelo.recibirDatos;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;

import com.example.proyectthefactoyhka.modelo.ModelReceptor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ModelDocumento implements Parcelable, Comparable<ModelDocumento> {

    private String id;
    private String serieCorrelativo;
    private String estatus;
    private String nombreCliente;
    private String fechaPago;
    private String subtotal;
    private String total;
    private String totalImpuestos;
    private String descuentos;
    private ModelReceptor receptor;
    private String tipoDoc;
    private String idInterno;
    private String fechaEmision;


    public ModelDocumento(String id, String serieCorrelativo, String estatus, String nombreCliente, String fechaPago, String subtotal, String total, String totalImpuestos, String descuentos, ModelReceptor receptor, String idInterno, String fechaEmision) {
        this.id = id;
        this.serieCorrelativo = serieCorrelativo;
        this.estatus = estatus;
        this.nombreCliente = nombreCliente;
        this.fechaPago = fechaPago;
        this.subtotal = subtotal;
        this.total = total;
        this.totalImpuestos = totalImpuestos;
        this.descuentos = descuentos;
        this.receptor = receptor;
        this.idInterno = idInterno;
        this.fechaEmision = fechaEmision;
    }


    public ModelDocumento(ModelDocumento documento){
        this.id = documento.getId();
        this.serieCorrelativo = documento.getSerieCorrelativo();
        this.estatus = documento.getEstatus();
        this.nombreCliente = documento.getNombreCliente();
        this.fechaPago = documento.getFechaPago();
        this.subtotal = documento.getSubtotal();
        this.total = documento.getTotal();
        this.totalImpuestos = documento.getTotalImpuestos();
        this.descuentos = documento.getDescuentos();
        this.tipoDoc = documento.getTipoDoc();
        this.idInterno = documento.getIdInterno();
        this.fechaEmision = documento.getFechaEmision();

    }

    public ModelDocumento(String id, String serieCorrelativo, String estatus, String nombreCliente, String fechaPago, String subtotal, String total, String totalImpuestos, String descuentos, String tipoDoc,String idInterno, String fechaEmision) {
        this.id = id;
        this.serieCorrelativo = serieCorrelativo;
        this.estatus = estatus;
        this.nombreCliente = nombreCliente;
        this.fechaPago = fechaPago;
        this.subtotal = subtotal;
        this.total = total;
        this.totalImpuestos = totalImpuestos;
        this.descuentos = descuentos;
        this.tipoDoc = tipoDoc;
        this.idInterno = idInterno;
        this.fechaEmision = fechaEmision;
    }


    protected ModelDocumento(Parcel in) {
        id = in.readString();
        serieCorrelativo = in.readString();
        estatus = in.readString();
        nombreCliente = in.readString();
        fechaPago = in.readString();
        subtotal = in.readString();
        total = in.readString();
        totalImpuestos = in.readString();
        descuentos = in.readString();
        tipoDoc = in.readString();
        idInterno = in.readString();
        fechaEmision = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(serieCorrelativo);
        dest.writeString(estatus);
        dest.writeString(nombreCliente);
        dest.writeString(fechaPago);
        dest.writeString(subtotal);
        dest.writeString(total);
        dest.writeString(totalImpuestos);
        dest.writeString(descuentos);
        dest.writeString(tipoDoc);
        dest.writeString(idInterno);
        dest.writeString(fechaEmision);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<ModelDocumento> CREATOR = new Creator<ModelDocumento>() {
        @Override
        public ModelDocumento createFromParcel(Parcel in) {
            return new ModelDocumento(in);
        }

        @Override
        public ModelDocumento[] newArray(int size) {
            return new ModelDocumento[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSerieCorrelativo() {
        return serieCorrelativo;
    }

    public void setSerieCorrelativo(String serieCorrelativo) {
        this.serieCorrelativo = serieCorrelativo;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(String fechaPago) {
        this.fechaPago = fechaPago;
    }

    public String getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(String subtotal) {
        this.subtotal = subtotal;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getTotalImpuestos() {
        return totalImpuestos;
    }

    public void setTotalImpuestos(String totalImpuestos) {
        this.totalImpuestos = totalImpuestos;
    }

    public String getDescuentos() {
        return descuentos;
    }

    public void setDescuentos(String descuentos) {
        this.descuentos = descuentos;
    }

    public ModelReceptor getReceptor() {
        return receptor;
    }

    public void setReceptor(ModelReceptor receptor) {
        this.receptor = receptor;
    }

    public String getTipoDoc() { return tipoDoc; }

    public void setTipoDoc(String tipoDoc) { this.tipoDoc = tipoDoc; }

    public String getIdInterno() {
        return idInterno;
    }

    public void setIdInterno(String idInterno) {
        this.idInterno = idInterno;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }


    @Override
    public int compareTo(ModelDocumento modelDocumento) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US);
        try {
            Date a = simpleDateFormat.parse(getFechaEmision());
            Date b = simpleDateFormat.parse(modelDocumento.getFechaEmision());
            return b.compareTo(a);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
