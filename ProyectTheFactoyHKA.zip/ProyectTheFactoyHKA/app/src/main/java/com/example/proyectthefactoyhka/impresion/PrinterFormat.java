package com.example.proyectthefactoyhka.impresion;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;

import com.example.proyectthefactoyhka.herramienta.FormatoMiles;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import com.example.proyectthefactoyhka.modelo.ModelReceptor;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelDocumentoElectronico;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelFacturacion;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelFacturasParseada;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProductosRegistrados;
import com.google.gson.Gson;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;

import javax.xml.parsers.ParserConfigurationException;


/**
 * Created by OAVENDANO on 10/18/2018.
 */

class PrinterFormat {


    /*
    Lista de comandos ESC/POS para ser enviados a la impresora
     */

    public final static byte[] LF = new byte[]{0x0A};
    public static final char ESC = (char)0x1B;
    public static final byte[] CUT = new byte[]{0x1D, 0x56,0x42,0x00};

    public static final String ALINEADO_IZQUIERDA = ESC + "a" + "\u0000";
    public static final String ALINEADO_CENTRO =ESC + "a" + "\u0001";
    public static final String ALINEADO_DERECHA = ESC + "a" + "\u0002";

    private static final String FUENTE_A_NORMAL= ESC + "\u0021" + "\u0000";
    private static final String FUENTE_A_BOLD= ESC + "\u0021" + "\u0008";
    private static final String FUENTE_A_SUBRAYADO= ESC + "\u0021" + "\u0080";
    private static final String FUENTE_A_DOBALTO= ESC + "\u0021" + "\u0010";
    private static final String FUENTE_A_DOBANCHO= ESC + "\u0021" + "\u0020";

    private static final String FUENTE_B_NORMAL= ESC + "\u0021" + "\u0001";
    private static final String FUENTE_B_BOLD= ESC + "\u0021" + "\u0009";
    private static final String FUENTE_B_SUBRAYADO= ESC + "\u0021" + "\u0081";
    private static final String FUENTE_B_DOBALTO= ESC + "\u0021" + "\u0011";
    private static final String FUENTE_B_DOBANCHO= ESC + "\u0021" + "\u0021";


    /**
     * Recibe un documento electrónico, da formato y retorna una lista de comandos ESC/POS para ser impresos
     * @param context contexto de la actividad desde la cual esta llamandose
     * @param documento documento electrónico con los datos a ser impresos
     * @param impresora modelo de impresora, con los diferentes parámetros para dar formato al documento
     * @return
     * @throws IOException
     * @throws ParserConfigurationException
     */
    public static ArrayList<byte[]> printTicket(Context context, ModelFacturasParseada documento, ModelImpresora impresora) throws IOException, ParserConfigurationException {

        ModelDocumentoElectronico documentoElectronico = new Gson().fromJson(documento.getFactura(),ModelDocumentoElectronico.class);
        String simboloMoneda =  "S/";
        int caracteresPorLinea = Integer.parseInt(impresora.getCaracterPorLinea());
        String strTmp;
        String paginaDeCodigo = impresora.getPaginaDeCodigo();

        StringBuilder sb = new StringBuilder();
        ArrayList<byte[]> bytes = new ArrayList<>();

        /*
        impresion de lineas de encabezado (Datos de contribuyente emisor)
        */

        bytes.add(ALINEADO_CENTRO.getBytes(paginaDeCodigo));

        if(documentoElectronico.getEmisor()!=null) {

            sb.append(documentoElectronico.getEmisor().getNombre() + "\n");
            sb.append("RUC "+documentoElectronico.getEmisor().getIdentificacion() + "\n");
            sb.append(documentoElectronico.getEmisor().getDireccion() + "\n");
            bytes.add(sb.toString().getBytes(paginaDeCodigo));
            bytes.add(LF);
            sb = new StringBuilder();
        }

        /*
        Datos del contribuyente receptor
         */

        bytes.add(ALINEADO_IZQUIERDA.getBytes(paginaDeCodigo));

        if(documentoElectronico.getReceptor()!=null){
            ModelReceptor receptor = documentoElectronico.getReceptor();
            sb.append(String.format(Locale.getDefault(),"Nombre: %s\n",receptor.getRazonSocial()));
            sb.append(String.format(Locale.getDefault(),"No ID: %s\n",receptor.getNumDocumento()));
        }

        bytes.add(sb.toString().getBytes(paginaDeCodigo));
        bytes.add(LF);
        sb = new StringBuilder();



        /*
        Titulo del documento
         */

        bytes.add(ALINEADO_CENTRO.getBytes(paginaDeCodigo));
        sb.append(documentoElectronico.getTipoDocumento());
        bytes.add(sb.toString().getBytes(paginaDeCodigo));
        bytes.add(LF);
        bytes.add(LF);
        sb = new StringBuilder();

        /*
        Número y fecha del documento
         */
        bytes.add(ALINEADO_IZQUIERDA.getBytes(paginaDeCodigo));

        strTmp = String.format(Locale.getDefault(),"No.%"+(caracteresPorLinea-3)+"s\n",documento.getId());
        sb.append(strTmp);
        strTmp = String.format(Locale.getDefault(),"%s%"+(caracteresPorLinea- documentoElectronico.getFechaEmision().length())+"s\n",documentoElectronico.getFechaEmision(),documentoElectronico.getHoraEmision());
        sb.append(strTmp);
        sb.append(lineaSeparacion('-',caracteresPorLinea)+"\n");
        bytes.add(sb.toString().getBytes(paginaDeCodigo));
        sb = new StringBuilder();

        /*
        productos
         */
        for (ModelFacturacion producto:documentoElectronico.getProducto()) {
            strTmp = String.format(Locale.getDefault(),"%s %s x %s\n", FormatoMiles.getFormattedString(producto.getCantidad()),producto.getUnidadMedida(),FormatoMiles.getFormattedString(producto.getPrecioVentaUnitarioItem()));
            sb.append(strTmp);
            strTmp = String.format(Locale.getDefault(),"%s%"+(caracteresPorLinea-producto.getDescripcion().length())+"s\n",producto.getDescripcion(),FormatoMiles.getFormattedString(producto.getValorVentaItemQxBI()));
            sb.append(strTmp);
        }

        sb.append(lineaSeparacion('-',caracteresPorLinea)+"\n");

        /*
        Totales
        */
        strTmp = "TOTAL";
        strTmp = String.format(Locale.getDefault(),"%s%"+(caracteresPorLinea-strTmp.length())+"s\n",strTmp,simboloMoneda+FormatoMiles.getFormattedString(documentoElectronico.getTotales().getImporteTotalPagar()));
        sb.append(strTmp);

        bytes.add(sb.toString().getBytes(paginaDeCodigo));
        bytes.add(LF);
        bytes.add(LF);
        bytes.add(LF);
        bytes.add(LF);

        /*
        Comando de corte de papel

        */

        bytes.add(CUT);
        return bytes;

    }


    public static ArrayList<byte[]> printReceipt(Context context, ModelFacturasParseada document, ModelImpresora printerItem) throws IOException, ParserConfigurationException, JSONException {
        String codePage = printerItem.getPaginaDeCodigo();

        String aux2 = "";
        ArrayList<byte[]> bytes = new ArrayList<>();

        return  bytes;

    }


    private static String splitLineBySpaces(String line, int charPerLine) {
        String[] words = line.split(" ");
        String currentLine = "";
        String res = line;
        if(res.length()>charPerLine) {
            if (words.length > 1) {
                res = "";
                for (String word : words) {
                    if (currentLine.length() + word.length() < charPerLine) {
                        currentLine = String.format(Locale.US,"%s %s", currentLine, word);
                        res = String.format(Locale.US,"%s %s", res, word);
                    } else {
                        res = String.format(Locale.US,"%s\n%s", res, word);
                        currentLine = word;
                    }
                }
            }
        }
        return res.trim();
    }
/*

    private static ArrayList<byte[]> getQrCode(int type, String qrInfo, String charset, int printerInterface) throws IOException {


        ArrayList<byte[]> bytes = new ArrayList<>();
        switch (type) {
            case 0: //QR por imagen
                Bitmap bitmap1 = null;
                try {
                    bitmap1 = TextToImageEncode(qrInfo);
                } catch (WriterException e) {
                    e.printStackTrace();
                }

                PrinterTools printerTools = new PrinterTools();
                bytes.add(printerTools.getImage(bitmap1));
                bitmap1.recycle();
                break;
            case 1: //QR por comando ESC/POS
                if(qrInfo!=null)
                {
                    byte[] btdata=null;

                    try {
                        btdata=qrInfo.getBytes(charset);
                    } catch (UnsupportedEncodingException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }

                    byte moduleSize = 0x04;

*/
/*
                    switch (printerInterface){
                        case Constantes.PRINTER_BLUETOOTH:
                            moduleSize = 0x07;
                            break;
                        case Constantes.PRINTER_ETHERNET:
                            moduleSize = 0x03;
                            break;
                    }
*//*


                    short datalen=(short) (btdata.length+3);
                    byte pL=(byte)(datalen&0xff);
                    byte pH=(byte)(datalen>>8);
                    bytes.add(new byte[]{0x1B, 0x61, 1});
                    bytes.add(new byte[]{0x1d,0x28,0x6b,0x03,0x00,0x31,0x43,moduleSize});
                    bytes.add(new byte[]{0x1d,0x28,0x6b,0x03,0x00,0x31,0x45,0x30});
                    byte[] qrHead=new byte[]{0x1d,0x28,0x6b,pL,pH,0x31,0x50,0x30};
                    byte[] qrData=new byte[qrHead.length+datalen];
                    System.arraycopy(qrHead, 0, qrData, 0, qrHead.length);
                    System.arraycopy(btdata, 0, qrData, qrHead.length, btdata.length);
                    bytes.add(qrData);
                    bytes.add(new byte[]{0x1d,0x28,0x6b,0x03,0x00,0x31,0x51,0x30,0x0A});
                }
                break;
        }
        return bytes;

    }

    private static Bitmap TextToImageEncode(String Value) throws WriterException {
        com.google.zxing.common.BitMatrix bitMatrix;
        Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        try {
            bitMatrix = new MultiFormatWriter().encode(
                    Value,
                    QR_CODE,
                    ProcesarPrefijos.qrSize, ProcesarPrefijos.qrSize, hints
            );

        } catch (IllegalArgumentException Illegalargumentexception) {

            return null;
        } catch (com.google.zxing.WriterException e) {
            e.printStackTrace();
            return null;
        }
        int bitMatrixWidth = bitMatrix.getWidth();

        int bitMatrixHeight = bitMatrix.getHeight();

        int[] pixels = new int[bitMatrixWidth * bitMatrixHeight];


        for (int y = 0; y < bitMatrixHeight; y++) {
            int offset = y * bitMatrixWidth;

            for (int x = 0; x < bitMatrixWidth; x++) {

                pixels[offset + x] = bitMatrix.get(x, y) ?
                        Color.BLACK:Color.WHITE;
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(bitMatrixWidth, bitMatrixHeight, Bitmap.Config.ARGB_8888);

        bitmap.setPixels(pixels, 0, ProcesarPrefijos.qrSize, 0, 0, bitMatrixWidth, bitMatrixHeight);
        return bitmap;
    }

    private static String[] splitToNChar(String text, int size) {
        List<String> parts = new ArrayList<>();

        int length = text.length();
        for (int i = 0; i < length; i += size) {
            parts.add(text.substring(i, Math.min(length, i + size)));
        }
        return parts.toArray(new String[0]);
    }
*/

    private static String lineaSeparacion(char separator, int size)
    {
        char[] chars = new char[size];
        Arrays.fill(chars, separator);
        return new String(chars);
    }


}
