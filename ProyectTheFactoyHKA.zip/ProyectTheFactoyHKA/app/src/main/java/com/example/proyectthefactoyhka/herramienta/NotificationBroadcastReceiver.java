package com.example.proyectthefactoyhka.herramienta;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;


import java.io.File;


/**
 * Created by fmonasterios on 4/28/2017.
 */

public class NotificationBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent)
    {
        String action = intent.getAction();
        String docNumber = intent.getStringExtra("docNumber");
        if(action.equals("notification_cancelled"))
        {
            // your code
            File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath() + File.separator +
                    docNumber+ ".pdf");
            file.delete();
        }
    }

}
