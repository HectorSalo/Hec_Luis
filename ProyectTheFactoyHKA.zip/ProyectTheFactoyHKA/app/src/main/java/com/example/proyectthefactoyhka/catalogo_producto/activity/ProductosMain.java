package com.example.proyectthefactoyhka.catalogo_producto.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.annotation.NonNull;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.acerca_de.Acerca_de;
import com.example.proyectthefactoyhka.ajustes.Ajustes;
import com.example.proyectthefactoyhka.ajustes.unidades.activity.UnidadesMain;
import com.example.proyectthefactoyhka.catalogo_cliente.activity.ClientesMain;
import com.example.proyectthefactoyhka.catalogo_producto.adaptadores.ProductosAdapter;
import com.example.proyectthefactoyhka.catalogo_producto.comunicacion.Conexion_Producto;
import com.example.proyectthefactoyhka.catalogo_producto.ventana_emergente.VentVerMasDetallesProducto;
import com.example.proyectthefactoyhka.catalogo_producto.ventana_emergente.VentanaProducto;
import com.example.proyectthefactoyhka.documento_emitido.activity.DocumentosMain;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity.Factura;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeProductos;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelProducto;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelRecibirListaProductos;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.example.proyectthefactoyhka.ventana_principal.PrincipalActivity;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import java.util.List;
import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class ProductosMain extends AppCompatActivity implements Conexion_Producto, View.OnClickListener, TextWatcher, RealmChangeListener<RealmList<ModelProducto>> {

    private Realm realm;
    private RealmList<ModelProducto> listaproducto;

    private RealmResults<ModelTasa> tasas;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private ProductosAdapter miAdapter;
    private LinearLayout layout_producto_buscar;
    private ModelUsuario usuarios;
    private Toolbar toolbar;
    private EditText edi_buscador_pro;
    private final int CODIGO_PERMISO = 400;
    private int idUsuario;
    private DatosTemporales datosTemporales;
    private RealmList<ModelUnidad> listaunidades;
    private ProgressBar prod_progressBar;
    private DrawerLayout drawerLayout;
    private LinearLayout nav_view_layout_catalogo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos_main);




        mostrarToolbar();
        cast();
        recibirDatosDeOtrosActivitys();
        funcionDelAdaptador(listaproducto);
        insercionDetasas();
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.fabt_catalogo_productos:


                VentanaProducto ventanaDialogo = new VentanaProducto();
                Bundle datos = new Bundle();
                datos.putInt(getString(R.string.enviar_usuario), idUsuario);
                ventanaDialogo.setArguments(datos);
                ventanaDialogo.show(getSupportFragmentManager(), "producto");

                break;

            case R.id.bt_buscador_prod:

                //accion el cual ocultara el el layout del ediText filtrador limpiara los carateres colocados y mostrara nuevamente el toolbar
                layout_producto_buscar.setVisibility(View.GONE);
                toolbar.setVisibility(View.VISIBLE);
                edi_buscador_pro.getText().clear();

                break;

            // botones del navigation view

            case R.id.bt_nav_inicio:

               enviarDatos(PrincipalActivity.class );

                break;

            case R.id.bt_nav_catalogo:

                if(nav_view_layout_catalogo.getVisibility()== View.GONE){
                    nav_view_layout_catalogo.setVisibility(View.VISIBLE);
                }else {
                    nav_view_layout_catalogo.setVisibility(View.GONE);
                }

                break;

            case R.id.bt_nav_unidades:

                enviarDatos(UnidadesMain.class);

                break;

            case R.id.bt_nav_documento:

                enviarDatos(DocumentosMain.class);

                break;

            case R.id.bt_nav_ajustes:

                enviarDatos(Ajustes.class);

                break;

            case R.id.bt_nav_acerca_De:

                enviarDatos(Acerca_de.class);

                break;

            case R.id.bt_nav_cerrar_sesion:


                cerrarActividad();

                break;

        }
    }



    //opciones de accion de los botones que estan alojados en context menu del toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()) {

            case android.R.id.home:
                finish();
                return true;

            case R.id.menu_pro_tab_eliminar:
                //accion el cual eliminara todas cardview alojadas en el reciclerView y notificara al recycle de dicho cambio

                realm.beginTransaction();
                usuarios.getDatos_producto().removeAll(listaproducto);
                realm.commitTransaction();
                miAdapter.notifyDataSetChanged();
                return true;

            case R.id.menu_pro_tab_buscar:
                //accion el cual mostrara el layout del ediText filtrador y ocultara el toolbar

                layout_producto_buscar.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.GONE);

                return true;

            case R.id.menu_pro_tab_carrito:


                enviarDatos(CarritoDeCompras.class);


                return true;

//            case R.id.menu_tab_imp:
//                permisosEscritura();
//                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddProductosAdapater  se presiona la accion del boton de editar, este
    // llamara a VentanaProducto.Class con la diferencia que este enviara el codigo el cual sera utilizada para poder rescatar los datos y asi poder editar los datos correspondiente
    @Override
    public void llamarVentanaEditarProducto(ModelProducto datos) {

        VentanaProducto ventanaDialogo = new VentanaProducto();
        Bundle datosedi = new Bundle();
        datosedi.putInt(getString(R.string.enviar_usuario), idUsuario);
        datosedi.putString("codigo", datos.getCodigo1());
        ventanaDialogo.setArguments(datosedi);
        ventanaDialogo.show(getSupportFragmentManager(), "editar");
    }


    // interface que se inicializa cada vez que en el contexMenu se presiona la accion del boton de Generar Factura y este se encargara de obtener los datos
    //de la cardView seleccionada y lo enviara a una nueva activity llamada Factura.Class
    @Override
    public void generarFacturadeProducto(ModelProducto dato) {

        Intent enviar = new Intent(this, Factura.class);
        Bundle datosedi = new Bundle();
        datosedi.putInt(getString(R.string.enviar_usuario), idUsuario);
        datosedi.putString("codigo", dato.getCodigo1());
        enviar.putExtra("tipoDocumento", "03");
        enviar.putExtras(datosedi);
        startActivity(enviar);
    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddProductosAdapater  se presiona la accion del boton de ventVerMasDetalle
    // obteniendo los datos a travez del la posicion obtenida del adaptador y enviandolos a la clase VentVerMasDellesProducto.Class
    @Override
    public void detallesDelProducto(ModelProducto producto) {

        new VentVerMasDetallesProducto(ProductosMain.this, producto.getDescripcion()
                , producto.getCodigo1(), producto.getTipo_unidad(), tasas.get(producto.getPosicionSpinnerIGV()).getPorcentajeDeImpuesto());

    }


    //interface que se inicializa cada vez que en el contexMenu a travez del adaptador AddProductosAdapater  se presiona la accion del boton eliminar
    //este eliminara los datos obtenido a travez de la posicion que fue enviada desde el adaptador
    @Override
    public void borrarProducto(ModelProducto dato) {
        realm.beginTransaction();
        dato.deleteFromRealm();
        realm.commitTransaction();
        miAdapter.notifyDataSetChanged();
    }


    //metodo para insertar las taza de impuesto a la base de datos
    private void insercionDetasas() {
        if (tasas.size() == 0) {
            for (int i = 0; i <= 4; i++) {
                ModelTasa nuevasTasas = new ModelTasa(0 + "", 0);
                realm.beginTransaction();
                realm.copyToRealm(nuevasTasas);
                realm.commitTransaction();
            }
        }
    }


    //metodo el cual inicia servicio del retrofic este traera del servidor este traera todos los datos que se alojan en el servido
    private void servicioRetrofit2() {

        final ModelPeticionDeProductos producto = new ModelPeticionDeProductos(datosTemporales.odtenerRuc(), usuarios.getSerial(), datosTemporales.obtenerTokeDeAcceso().getToken());
        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelRecibirListaProductos> obtenerProducto = service.peticionProducto(producto);
        obtenerProducto.enqueue(new Callback<ModelRecibirListaProductos>() {

            ModelRecibirListaProductos listProd = new ModelRecibirListaProductos();

            @Override
            public void onResponse(Call<ModelRecibirListaProductos> call, Response<ModelRecibirListaProductos> response) {


                listProd = response.body();
                int cantidad = listProd.getProductos().size();
                List<ModelProducto> prod = new RealmList<>();


                if (listProd.getProductos().size() > listaproducto.size()) {

                    for (int i = 0; i <= cantidad - 1; i++) {

                        if (!listProd.getProductos().get(i).getCodigo1().isEmpty() && !listProd.getProductos().get(i).getDescripcion().isEmpty() && !listProd.getProductos().get(i).getUnidad().isEmpty() && listProd.getProductos().get(i).getPrecio1() != null) {

                            prod.add(new ModelProducto("Producto", listProd.getProductos().get(i).getCodigo1(), listProd.getProductos().get(i).getCodigo2(),
                                    listProd.getProductos().get(i).getDescripcion(), listProd.getProductos().get(i).getPrecio1(), listaunidades.get(1).getDescripcion(), 0,
                                    "0"));

                        }
                    }

                    realm.beginTransaction();
                    listaproducto.addAll(prod);
                    realm.copyToRealm(listaproducto);
                    realm.commitTransaction();
                    miAdapter.notifyDataSetChanged();
                }

                esperaDeDatos();
            }

            @Override
            public void onFailure(Call<ModelRecibirListaProductos> call, Throwable t) {
                esperaDeDatos();
                mostrarToast(R.string.fallo_retroit);
            }
        });

    }


    //metodo que filtrara los produtos colocado en el editext Filtrador este posee 3 metodos uno de antes/durante/depues el codigo sera implementado en el metodo durante
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {


        RealmQuery<ModelProducto> query = listaproducto.where().contains("descripcion", s.toString()).or().contains("codigo1", s.toString());
        RealmResults<ModelProducto> newList = query.findAll();
        funcionDelAdaptador(newList);
        miAdapter.notifyDataSetChanged();
    }

    @Override
    public void afterTextChanged(Editable s) {
    }


    //funcion del adaptador para poder configurar y generar las cardview utilizada para mostrar los productos
    //este recibira la lista de producto y generara el elemento en el layout
    private void funcionDelAdaptador(List<ModelProducto> producto) {
        miAdapter = new ProductosAdapter(producto, tasas, R.layout.cardview_productos, this, this);
        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);

    }


    //metodo que se encargara de verificar los permiso de ususario tanto de versiones por debajo de 6.0 a superiores de 6.0 esten ya registrado para la inicializacion de la actividad de ingresar a los dato alojado en el dispositivo

    private void permisosEscritura() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso()) {
                //ha aceptado

                new MaterialFilePicker()
                        .withActivity(this)
                        .withRequestCode(CODIGO_PERMISO)
                        .withHiddenFiles(true)
                        .start();
            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                } else {
                    //ha rechazado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                }
            }

        } else {
            viejaVersionpermisoEscritura();
        }
    }


    // este metodo sera llamado por el metodo permisos si la version es menor a la version 25
    private void viejaVersionpermisoEscritura() {

        if (chequearPermiso()) {

            new MaterialFilePicker()
                    .withActivity(this)
                    .withRequestCode(CODIGO_PERMISO)
                    .withHiddenFiles(true)
                    .start();

        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso() {
        int result = this.checkCallingOrSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    //metodo para registrar los permisos de escritura en el dispositivo para versiones 6.0 o superior
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        if (requestCode == CODIGO_PERMISO) {
            if (grantResults.length > 0) {

                String permission = permissions[0];
                int result = grantResults[0];

                if (permission.equals(WRITE_EXTERNAL_STORAGE)) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso();
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }

            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));

        FloatingActionButton fabt_catalogo_productos = findViewById(R.id.fabt_catalogo_productos);
        fabt_catalogo_productos.setOnClickListener(this);

        miRecicler = findViewById(R.id.mi_recicler_view);
        miLayoutManager = new LinearLayoutManager(this);

        prod_progressBar = findViewById(R.id.prod_progressBar);
        prod_progressBar.setVisibility(View.GONE);

        edi_buscador_pro = findViewById(R.id.edi_buscador_prod);
        edi_buscador_pro.addTextChangedListener(this);

        layout_producto_buscar = findViewById(R.id.layout_producto_buscar);

        ImageButton bt_buscador_prod = findViewById(R.id.bt_buscador_prod);
        bt_buscador_prod.setOnClickListener(this);



        //funciones del navigation view

        drawerLayout = findViewById(R.id.drawer_activity_principal);

        View bt_nav_inicio = findViewById(R.id.bt_nav_inicio);
        bt_nav_inicio.setOnClickListener(this);

        View bt_nav_catalogo = findViewById(R.id.bt_nav_catalogo);
        bt_nav_catalogo.setOnClickListener(this);

        nav_view_layout_catalogo = findViewById(R.id.nav_view_layout_catalogo);

        View bt_nav_unidades = findViewById(R.id.bt_nav_unidades);
        bt_nav_unidades.setOnClickListener(this);

        View bt_nav_documento = findViewById(R.id.bt_nav_documento);
        bt_nav_documento.setOnClickListener(this);

        View bt_nav_ajustes = findViewById(R.id.bt_nav_ajustes);
        bt_nav_ajustes.setOnClickListener(this);

        View bt_nav_acerca_De = findViewById(R.id.bt_nav_acerca_De);
        bt_nav_acerca_De.setOnClickListener(this);

        View bt_nav_cerrar_sesion = findViewById(R.id.bt_nav_cerrar_sesion);
        bt_nav_cerrar_sesion.setOnClickListener(this);
    }


    //metodo para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {

        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        tasas = realm.where(ModelTasa.class).findAll();
        if (usuarios != null)
            listaproducto = usuarios.getDatos_producto();
        listaproducto.addChangeListener(this);
        listaunidades = usuarios.getDatosunidad();


    }


    //metodo el cual recibira datos del PrincipalActivity para identificar el actual usuario
    private void recibirDatosDeOtrosActivitys() {

        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            idUsuario = extra.getInt(getString(R.string.enviar_usuario));
            baseDeDatos();

            if (listaproducto.size() == 0) {

                esperaDeDatos();
                servicioRetrofit2();

            }
        }
    }


    // inflamos el layout context menu que aparecera en el toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_productos, menu);
        return super.onCreateOptionsMenu(menu);
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(ProductosMain.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    private void esperaDeDatos() {

        if (prod_progressBar.getVisibility() == View.GONE) {
            prod_progressBar.setVisibility(View.VISIBLE);

        } else {
            prod_progressBar.setVisibility(View.GONE);

        }
    }


    //metodo que  configura el toolbar
    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbar_productos);
        setSupportActionBar(toolbar);
        //Habilitamos el home button (flecha hacia atras)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ProductosMain.this.setTitle(R.string.toolbar_Catalogo_productos);
    }


    //metodo que se encargara de actualiza el Reciclerview cada vez que este recibe un cambio en la base de datos
    @Override
    public void onChange(RealmList<ModelProducto> modelProductos) {
        miAdapter.notifyDataSetChanged();
    }


    @Override
    public void onBackPressed() {
        finish();
    }



    private void enviarDatos(Class clase) {
        Intent enviar = new Intent(ProductosMain.this, clase);
        enviar.putExtra(getString(R.string.enviar_usuario), idUsuario);
        enviar.putExtra("tipoDocumento","03");
        startActivity(enviar);
        finish();
    }





    private void cerrarActividad(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(ProductosMain.this);
        dialog.setTitle("Confirmar");
        dialog.setMessage("¿Desea cerrar sesión?");
        //dialog.setIcon(R.drawable.ic_advertencia);
        dialog.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();



            }
        });
        dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialog.show();

    }



}







