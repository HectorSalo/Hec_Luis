package com.example.proyectthefactoyhka.modelo.recibirDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelObtenerPDF {
    @SerializedName("archivo")
    @Expose
    private String archivo;
    @SerializedName("codigo")
    @Expose
    private Integer codigo;
    @SerializedName("mensaje")
    @Expose
    private String mensaje;
    @SerializedName("numeracion")
    @Expose
    private String numeracion;

    public ModelObtenerPDF() {
    }

    public ModelObtenerPDF(String archivo, Integer codigo, String mensaje, String numeracion) {
        this.archivo = archivo;
        this.codigo = codigo;
        this.mensaje = mensaje;
        this.numeracion = numeracion;
    }


    public String getArchivo() {
        return archivo;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getNumeracion() {
        return numeracion;
    }

    public void setNumeracion(String numeracion) {
        this.numeracion = numeracion;
    }
}
