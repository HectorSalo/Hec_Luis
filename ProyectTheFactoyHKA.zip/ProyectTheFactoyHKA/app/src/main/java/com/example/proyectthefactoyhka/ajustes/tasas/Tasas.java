package com.example.proyectthefactoyhka.ajustes.tasas;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTasa;

import io.realm.Realm;
import io.realm.RealmResults;

public class Tasas extends AppCompatActivity implements View.OnClickListener {

    private Realm realm;
    private RealmResults<ModelTasa> tasas;
    private EditText edi_tasa_1 ,edi_tasa_2,edi_tasa_3,edi_tasa_4,edi_tasa_5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasas);

        mostrarToolbar();
        cast();
        baseDeDatos();
        insercionDetasas();
        mostrarDatos();


    }

    private void mostrarDatos() {



        edi_tasa_1.setText(tasas.get(0).getPorcentajeDeImpuesto());
        edi_tasa_2.setText(tasas.get(1).getPorcentajeDeImpuesto());
        edi_tasa_3.setText(tasas.get(2).getPorcentajeDeImpuesto());
        edi_tasa_4.setText(tasas.get(3).getPorcentajeDeImpuesto());
        edi_tasa_5.setText(tasas.get(4).getPorcentajeDeImpuesto());


    }


    private void insercionDetasas() {
        if (tasas.size()==0){
            for (int i =0;i<=4;i++){
                ModelTasa nuevasTasas = new ModelTasa(0+"",0);
                realm.beginTransaction();
                realm.copyToRealm(nuevasTasas);
                realm.commitTransaction();
            }
        }
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.bt_tasa_1:

                agregarTasa(edi_tasa_1,0);
                break;

            case R.id.bt_tasa_2:

                agregarTasa(edi_tasa_2,1);
                break;


            case R.id.bt_tasa_3:
                agregarTasa(edi_tasa_3,2);
                break;

            case R.id.bt_tasa_4:
                agregarTasa(edi_tasa_4,3);
                break;

            case R.id.bt_tasa_5:
                agregarTasa(edi_tasa_5,4);
                break;
        }
    }




    private void baseDeDatos() {

        realm = Realm.getDefaultInstance();
        tasas = realm.where(ModelTasa.class).findAll();
    }



    private void agregarTasa(EditText ediTex_tasa,int posicion){

        double porcentajeEnDecimal =    Double.parseDouble(ediTex_tasa.getText().toString())/100;

        ModelTasa edi_tasa = tasas.get(posicion);
        if (edi_tasa != null ) {
            realm.beginTransaction();
            edi_tasa.setDecimaDelImpuesto(porcentajeEnDecimal);
            edi_tasa.setPorcentajeDeImpuesto(ediTex_tasa.getText().toString());
            realm.commitTransaction();
            ediTex_tasa.setText(edi_tasa.getPorcentajeDeImpuesto());
        }

        finish();

    }

    private void cast() {

        edi_tasa_1=findViewById(R.id.edi_tasa_1);
        edi_tasa_1.setEnabled(false);
        edi_tasa_2 = findViewById(R.id.edi_tasa_2);
        edi_tasa_2.setText("18");
        edi_tasa_3 = findViewById(R.id.edi_tasa_3);
        edi_tasa_4 = findViewById(R.id.edi_tasa_4);
        edi_tasa_5 = findViewById(R.id.edi_tasa_5);


        Button bt_tasa_1 = findViewById(R.id.bt_tasa_1);
        bt_tasa_1.setOnClickListener(this);

        Button bt_tasa_2 = findViewById(R.id.bt_tasa_2);
        bt_tasa_2.setOnClickListener(this);

        Button bt_tasa_3 = findViewById(R.id.bt_tasa_3);
        bt_tasa_3.setOnClickListener(this);

        Button bt_tasa_4 = findViewById(R.id.bt_tasa_4);
        bt_tasa_4.setOnClickListener(this);

        Button bt_tasa_5 = findViewById(R.id.bt_tasa_5);
        bt_tasa_5.setOnClickListener(this);

    }



    //configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_tasas);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Tasas.this.setTitle(R.string.toolbar_tasas);
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
