package com.example.proyectthefactoyhka.herramienta;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

/**
 * Created by OAVENDANO on 01/17/2018.
 */

public class FormatoMiles {

    private static NumberFormat nf = NumberFormat.getInstance(Locale.US);
    private static DecimalFormat df = (DecimalFormat) nf;

    public static String getFormattedString(String cadena)
    {

        return formatString(cadena);
    }

    public static String getFormattedString(CharSequence cadena)
    {
        return formatString(cadena.toString());
    }



    public static String getUnformattedString(CharSequence cadena)
    {
        return unformatString(cadena.toString());
    }

    public static String getUnformattedString(String cadena)
    {
        return unformatString(cadena);
    }


    public static String getFormattedString(double valor)
    {

        return formatString(String.valueOf(valor));
    }


    public static String getFormattedString(int valor)
    {

        df.applyPattern("#,##0");
        String strTmp ="0";
        try{
            strTmp = df.format(valor);
        }catch( Exception ex)
        {

        }
        return strTmp;
    }

    public static String getUnformattedString(double value){
        return String.format(Locale.US,"%.2f",value);
    }

    private static String formatString(String cadena)
    {
        df.applyPattern("#,##0.00");
        String strTmp ="0.00";
        try{
            strTmp = df.format(Double.parseDouble(cadena.replaceAll(",","").replaceAll("\\$", "")));
        }catch( Exception ex)
        {

        }
        return strTmp;
    }

    private static String unformatString(String cadena)
    {
        df.applyPattern("#,##0.00");
        String strTmp ="0.00";
        try{
            double valor = Double.parseDouble(cadena.replaceAll(",","").replaceAll("\\$", ""));
            strTmp = String.format(Locale.US,"%.2f",valor);//df.format(valor).replaceAll(",","");
        }catch( Exception ex)
        {

        }

        return strTmp;

    }

    public static double getValue(String cadena)
    {
        return parse(cadena);
    }

    public static double getValue(CharSequence cadena)
    {
        return parse(cadena.toString());
    }

    private static double parse(String cadena)
    {
        double valor = 0.00;
        try
        {
            valor = Double.parseDouble(cadena.replaceAll(",","").replaceAll("\\$", ""));
        }catch (Exception ex)
        {

        }

        return valor;

    }



}
