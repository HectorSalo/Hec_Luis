package com.example.proyectthefactoyhka.persistencia_de_datos;

import android.content.SharedPreferences;

import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelIdRuc;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerToken;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelInfoEmisor;

public class DatosTemporales {



    public static final String SHARED_PREFERENCES = "SHARED_PREFERENCES";
    private static final String SHARED_PREFERENCES_TOKEN_DE_ACCESO = "SHARED_PREFERENCES_TOKEN_DE_ACCESO";
    private static final String SHARED_PREFERENCES_REFRESCAR_TOKEN = "SHARED_PREFERENCES_REFRESCAR_TOKEN";

    private static final String SHARED_PREFERENCES_CODIGO_PAIS = "SHARED_PREFERENCES_CODIGO_PAIS";
    private static final String SHARED_PREFERENCES_DEPARTAMENTO = "SHARED_PREFERENCES_DEPARTAMENTO";
    private static final String SHARED_PREFERENCES_DISTRITO = "SHARED_PREFERENCES_DISTRITO";
    private static final String SHARED_PREFERENCES_DIRECCION = "SHARED_PREFERENCES_DIRECCION";
    private static final String SHARED_PREFERENCES_NOMBRE = "SHARED_PREFERENCES_NOMBRE";
    private static final String SHARED_PREFERENCES_IDENTIFICACION= "SHARED_PREFERENCES_IDENTIFICACION";
    private static final String SHARED_PREFERENCES_UBICACION = "SHARED_PREFERENCES_UBICACION";


    private static final String SHARED_PREFERENCES_USUARIO = "SHARED_PREFERENCES_USUARIO";
    private static final String SHARED_PREFERENCES_CLAVE = "SHARED_PREFERENCES_CLAVE";
    private static final String SHARED_PREFERENCES_RUC = "SHARED_PREFERENCES_RUC";
    private static final String SHARED_PREFERENCES_SERIAL = "SHARED_PREFERENCES_SERIAL";

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    private static DatosTemporales INSTANCE = null;

    private DatosTemporales(SharedPreferences sharedPreferences){
        this.sharedPreferences = sharedPreferences;
        this.editor = sharedPreferences.edit();
    }

    public static synchronized DatosTemporales getIntance(SharedPreferences sharedPreferences){
        if(INSTANCE == null){
            INSTANCE = new DatosTemporales(sharedPreferences);
        }
        return INSTANCE;
    }

    public void guardarToken(ModelObtenerToken token){
        editor.putString(SHARED_PREFERENCES_TOKEN_DE_ACCESO, token.getToken()).commit();
     //   editor.putString(SHARED_PREFERENCES_REFRESCAR_TOKEN, token.getRefreshToken()).commit();
    }

    public ModelObtenerToken obtenerTokeDeAcceso(){
        ModelObtenerToken token = new ModelObtenerToken();
        token.setToken(sharedPreferences.getString(SHARED_PREFERENCES_TOKEN_DE_ACCESO, null));
     //   token.setRefreshToken(sharedPreferences.getString(SHARED_PREFERENCES_REFRESCAR_TOKEN, null));
        return token;
    }

    public void guardarEmisor(ModelInfoEmisor emisor){

        editor.putString(SHARED_PREFERENCES_CODIGO_PAIS, emisor.getCodigoPais()).commit();
        editor.putString(SHARED_PREFERENCES_DEPARTAMENTO, emisor.getDepartamento()).commit();
        editor.putString(SHARED_PREFERENCES_DISTRITO,emisor.getDistrito()).commit();
        editor.putString(SHARED_PREFERENCES_DIRECCION,emisor.getDomicilioFiscal()).commit();
        editor.putString(SHARED_PREFERENCES_NOMBRE,emisor.getNombreComercial()).commit();
        editor.putString(SHARED_PREFERENCES_IDENTIFICACION,emisor.getRuc()).commit();
        editor.putString(SHARED_PREFERENCES_UBICACION,emisor.getUbigeo()).commit();


    }


    public ModelInfoEmisor obtenerInfoEmisor(){
        ModelInfoEmisor emisor = new ModelInfoEmisor();

        emisor.setCodigoPais(sharedPreferences.getString(SHARED_PREFERENCES_CODIGO_PAIS, null));
        emisor.setDepartamento(sharedPreferences.getString(SHARED_PREFERENCES_DEPARTAMENTO,null));
        emisor.setDistrito(sharedPreferences.getString(SHARED_PREFERENCES_DISTRITO, null));
        emisor.setDomicilioFiscal(sharedPreferences.getString(SHARED_PREFERENCES_DIRECCION, null));
        emisor.setNombreComercial(sharedPreferences.getString(SHARED_PREFERENCES_NOMBRE, null));
        emisor.setRuc(sharedPreferences.getString(SHARED_PREFERENCES_IDENTIFICACION, null));
        emisor.setUbigeo(sharedPreferences.getString(SHARED_PREFERENCES_UBICACION, null));
        return emisor;
    }



    public void guardarUsuario(ModelUsuario usuario){
        editor.putString(SHARED_PREFERENCES_USUARIO, usuario.getUsuario()).commit();
        editor.putString(SHARED_PREFERENCES_CLAVE, usuario.getClave()).commit();
        //   editor.putString(SHARED_PREFERENCES_REFRESCAR_TOKEN, token.getRefreshToken()).commit();
    }

    public ModelUsuario obtenerUsuario(){
        ModelUsuario usuario = new ModelUsuario();
        usuario.setUsuario(sharedPreferences.getString(SHARED_PREFERENCES_USUARIO, null));
        usuario.setClave(sharedPreferences.getString(SHARED_PREFERENCES_CLAVE, null));
        return usuario;
    }

    public void guardarRuc(String ruc){
        editor.putString(SHARED_PREFERENCES_RUC, ruc).commit();

    }

    public String odtenerRuc(){

        //  ruc.setRuc(sharedPreferences.getString(SHARED_PREFERENCES_RUC, null));
        return sharedPreferences.getString(SHARED_PREFERENCES_RUC, null);
    }

    public void guardarSerial(String serial){
        editor.putString(SHARED_PREFERENCES_SERIAL, serial).commit();

    }

    public String odtenerSerial(){

        //  ruc.setRuc(sharedPreferences.getString(SHARED_PREFERENCES_RUC, null));
        return sharedPreferences.getString(SHARED_PREFERENCES_SERIAL, null);
    }


}
