package com.example.proyectthefactoyhka.ajustes;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.adaptador.SettingListAdapter;
import com.example.proyectthefactoyhka.ajustes.adaptador.SettingListItem;
import com.example.proyectthefactoyhka.ajustes.impresoras.activity.Impresoras;
import com.example.proyectthefactoyhka.ajustes.opciones.Opciones;
import com.example.proyectthefactoyhka.ajustes.recibo.Recibo;
import com.example.proyectthefactoyhka.ajustes.tasas.Tasas;
import com.example.proyectthefactoyhka.ajustes.teclado.activity.Teclado;
import com.example.proyectthefactoyhka.ajustes.usuario.activity.UsuariosGuardados;

import java.util.ArrayList;

public class Ajustes extends AppCompatActivity implements View.OnClickListener{

    private int posicionUsuario;

    private RecyclerView rvAjustes;
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);

        cast();
        mostrarToolbar();
        iniciarLista();
        recibirDatosDeOtrosActivitys();
    }
    @Override
    public void onClick(View v) {

        RecyclerView.ViewHolder viewHolder = (RecyclerView.ViewHolder)v.getTag();
        switch (viewHolder.getAdapterPosition()){


            case 0:
                enviarDatos(Opciones.class);
                break;
            case 1:
                enviarDatos(Recibo.class);
                break;
            case 2:
                enviarDatos(Teclado.class);
                break;
            case 3:
                startActivity(new Intent(Ajustes.this, Impresoras.class));
                break;

            case 4:
                startActivity(new Intent(Ajustes.this, Tasas.class));
                break;
            case 5:
                startActivity(new Intent(Ajustes.this, UsuariosGuardados.class));
                break;
        }


    }

    private void enviarDatos(Class clase){
        Intent enviarCliente = new Intent(Ajustes.this, clase);
        enviarCliente.putExtra(getString(R.string.enviar_usuario),posicionUsuario);
        startActivity(enviarCliente);
    }


    private void recibirDatosDeOtrosActivitys() {

        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            posicionUsuario = extra.getInt(getString(R.string.enviar_usuario));
        }
    }

    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {
        rvAjustes = findViewById(R.id.rv_ajustes);


    }

    private void iniciarLista(){
        ArrayList<SettingListItem> preferences = new ArrayList<>();

        //todo: extraer strings
        preferences.add(new SettingListItem("Opciones","Opciones generales de Facturacion Electrónica"));
        preferences.add(new SettingListItem("Ticket","Datos de la representacion impresa"));
        preferences.add(new SettingListItem("Teclado","Ajustes del teclado plano"));
        preferences.add(new SettingListItem("Impresoras","Edicion y manejo de impresoras de punto de venta"));
        preferences.add(new SettingListItem("Tasas","Opciones de ajustes de tasas de impuesto"));
        preferences.add(new SettingListItem("Cuenta","Opciones de la cuenta de usuario"));




        SettingListAdapter adapter = new SettingListAdapter(preferences,this);
        LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
        rvAjustes.setLayoutManager(llm);
        //rvAjustes.addItemDecoration(new SimpleDividerItemDecoration(getApplicationContext()));

        rvAjustes.setAdapter(adapter);

    }

    private void mostrarToolbar() {
        toolbar = findViewById(R.id.toolbar_ajustes);
        setSupportActionBar(toolbar);
        //Habilitamos el home button (flecha hacia atras)
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Ajustes.this.setTitle(R.string.toolbar_ajustes);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }




}
