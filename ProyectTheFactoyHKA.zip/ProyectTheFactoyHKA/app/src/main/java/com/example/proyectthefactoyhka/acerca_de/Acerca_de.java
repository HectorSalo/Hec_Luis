package com.example.proyectthefactoyhka.acerca_de;

import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.proyectthefactoyhka.BuildConfig;
import com.example.proyectthefactoyhka.R;

public class Acerca_de extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca_de);

        TextView version =  findViewById(R.id.tversion);
        version.setText(String.format("%s%s", getString(R.string.About_version) + " ", BuildConfig.VERSION_NAME));


        TextView terminosCondiciones =  findViewById(R.id.terminos);
        terminosCondiciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.thefactoryhka.com";
                Uri uri = Uri.parse(url);
                Intent myIntent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(myIntent);
            }
        });
    }

    @Override
    public void onBackPressed() {
       finish();

    }
}
