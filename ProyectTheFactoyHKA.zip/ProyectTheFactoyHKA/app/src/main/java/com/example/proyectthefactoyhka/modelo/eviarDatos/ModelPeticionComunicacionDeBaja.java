package com.example.proyectthefactoyhka.modelo.eviarDatos;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ModelPeticionComunicacionDeBaja {


    @SerializedName("clave")
    @Expose
    private String clave;
    @SerializedName("documento")
    @Expose
    private String documento;
    @SerializedName("motivo")
    @Expose
    private String motivo;
    @SerializedName("ruc")
    @Expose
    private String ruc;
    @SerializedName("usuario")
    @Expose
    private String usuario;
    @SerializedName("usuarioId")
    @Expose
    private String usuarioId;

    public ModelPeticionComunicacionDeBaja() {
    }

    public ModelPeticionComunicacionDeBaja(String clave, String documento, String motivo, String ruc, String usuario, String usuarioId) {
        this.clave = clave;
        this.documento = documento;
        this.motivo = motivo;
        this.ruc = ruc;
        this.usuario = usuario;
        this.usuarioId = usuarioId;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }
}
