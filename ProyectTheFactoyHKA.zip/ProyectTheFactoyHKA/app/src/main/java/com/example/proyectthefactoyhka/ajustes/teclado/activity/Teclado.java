package com.example.proyectthefactoyhka.ajustes.teclado.activity;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;


import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.teclado.adaptador.TecladoAdaptador;
import com.example.proyectthefactoyhka.ajustes.teclado.comunicacion.Conexion;
import com.example.proyectthefactoyhka.ajustes.teclado.ventana_emergente.VentModificarTeclas;
import com.example.proyectthefactoyhka.modelo.ModelTeclas;

import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelTeclado;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;


import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;

import yuku.ambilwarna.AmbilWarnaDialog;

public class Teclado extends AppCompatActivity implements View.OnClickListener , Conexion {

    private RealmList<ModelTeclas> listaTeclas;
    private ModelTeclado teclado;
    private RecyclerView miRecicler;
    private RecyclerView.LayoutManager miLayoutManager;
    private RecyclerView.Adapter miAdapter;
    private Realm realm;
    private int colorPorDefecto;
    private Button bt_mostrar_opciones,bt_tecl_agregar_teclas;
    private Switch bt_teclado_usar_teclado;
    private LinearLayout layout_de_opciones;
    private int posicionDelBoton;
    private ModelUsuario usuarios;
    private int posicionUsuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teclado);

        mostrarToolbar();
        cast();
        recibirDatosDeOtrosActivitys();

        funcionDelAdaptador(listaTeclas);
        insercionDeTeclas();




    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.bt_mostrar_opciones:

                if(this.layout_de_opciones.getVisibility()== View.GONE){
                    layout_de_opciones.setVisibility(View.VISIBLE);
                    bt_mostrar_opciones.setText(R.string.ocultar);
                }else {
                    layout_de_opciones.setVisibility(View.GONE);
                    bt_mostrar_opciones.setText(R.string.mostrar);
                }

                break;

            case R.id.bt_cambiar_fondo:

                paletaDeColores();

                break;

            case R.id.bt_restaurar:
                restauraTodosLosDatosDatos();

                break;

            case R.id.bt_teclado_usar_teclado:

                if (bt_teclado_usar_teclado.isChecked()){

                realm.beginTransaction();
                usuarios.getTeclado().setTecladoPordefecto(true);
                realm.commitTransaction();
                }else {
                    realm.beginTransaction();
                    usuarios.getTeclado().setTecladoPordefecto(false);
                    realm.commitTransaction();

                }

            break;

            case  R.id.bt_tecl_agregar_teclas:

                AgregarTecla();

            break;

        }

    }

    @Override
    public void enviarDatos(String datos,String codigo,int color) {

        ModelTeclas editarTeclas = usuarios.getTeclado().getTeclas().get(posicionDelBoton);

        if (editarTeclas!=null){

            realm.beginTransaction();
            editarTeclas.setTexto(datos);
            editarTeclas.setCodigo1(codigo);
            editarTeclas.setFondo(color);
            usuarios.getTeclado().getTeclas().set(posicionDelBoton,editarTeclas);
            realm.commitTransaction();
            miAdapter.notifyDataSetChanged();
        }

    }


    private void insercionDeTeclas() {
        if (listaTeclas.size()==0){

            List<ModelTeclas> agregar = new RealmList<>();
            for (int i =0;i<=15;i++){
                agregar.add(new ModelTeclas(i+"","",-16757440));
            }


            realm.beginTransaction();
            listaTeclas.addAll(agregar);
            teclado.setTeclas(listaTeclas);
            realm.copyToRealm(teclado);
            realm.commitTransaction();

            miAdapter.notifyDataSetChanged();


        }
    }

    private void restauraTodosLosDatosDatos(){

        realm.beginTransaction();
        listaTeclas.deleteAllFromRealm();
        realm.commitTransaction();

        insercionDeTeclas();

    }



    private void AgregarTecla(){


        realm.beginTransaction();
        listaTeclas.add(new ModelTeclas(listaTeclas.size()+"","",-16757440));
        realm.copyToRealm(listaTeclas);
        realm.commitTransaction();
        miAdapter.notifyDataSetChanged();
    }


    private void funcionDelAdaptador(List<ModelTeclas> listaTeclas) {


        miAdapter = new TecladoAdaptador(listaTeclas, this, R.layout.card_tecla_ajuste_teclado, 0,new TecladoAdaptador.MyItemClick() {
            @Override
            public void listener(ModelTeclas modelTeclas, int position) {


                ModelTeclas color =usuarios.getTeclado().getTeclas().get(position);

                if (color!=null) {

                    new VentModificarTeclas(Teclado.this, Teclado.this, color.getFondo(),posicionUsuario);
                }



                posicionDelBoton=position;

            }
        });

        miRecicler.setHasFixedSize(true);
        miRecicler.setLayoutManager(miLayoutManager);
        miRecicler.setItemAnimator(new DefaultItemAnimator());
        miRecicler.setAdapter(miAdapter);

    }




    private void cast() {
        miRecicler=findViewById(R.id.mi_recicler_view_teclado);
        miLayoutManager = new GridLayoutManager(this,4);

        layout_de_opciones=findViewById(R.id.layout_de_opciones);
        colorPorDefecto= ContextCompat.getColor(Teclado.this,R.color.colorbotones);

        bt_mostrar_opciones=findViewById(R.id.bt_mostrar_opciones);
        bt_mostrar_opciones.setOnClickListener(this);


        bt_teclado_usar_teclado = findViewById(R.id.bt_teclado_usar_teclado);
        bt_teclado_usar_teclado.setOnClickListener(this);

        bt_tecl_agregar_teclas = findViewById(R.id.bt_tecl_agregar_teclas);
        bt_tecl_agregar_teclas.setOnClickListener(this);

        Button bt_restaurar = findViewById(R.id.bt_restaurar);
        bt_restaurar.setOnClickListener(this);

        Button bt_cambiar_fondo = findViewById(R.id.bt_cambiar_fondo);
        bt_cambiar_fondo.setOnClickListener(this);

    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id",posicionUsuario).findFirst();
        if (usuarios!=null)

            teclado = usuarios.getTeclado();
            listaTeclas = usuarios.getTeclado().getTeclas();

            if (teclado.isTecladoPordefecto()){
                bt_teclado_usar_teclado.setChecked(true);

            }
    }



    //esto se implenta gracias a la libreria com.github.yukuku:ambilwarna la cual llama una paleta de colores
    public void paletaDeColores(){

        AmbilWarnaDialog colorSeleccionado = new AmbilWarnaDialog(this, colorPorDefecto, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }
            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {

                colorPorDefecto = color;


                for (int i =0;i<listaTeclas.size();i++) {



                    ModelTeclas colorTeclas = usuarios.getTeclado().getTeclas().get(i);

                    if (colorTeclas != null) {

                        realm.beginTransaction();
                        colorTeclas.setFondo(colorPorDefecto);
                        realm.commitTransaction();
                    }
                    miAdapter.notifyDataSetChanged();
                }
            }
        });

        colorSeleccionado.show();
    }


    private void recibirDatosDeOtrosActivitys() {

        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            posicionUsuario = extra.getInt("usuario");
        }

        baseDeDatos();
    }

    //metodo que  configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_teclado);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Teclado.this.setTitle(R.string.toolbar_teclado);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}