package com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.ventana_emergente;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.example.proyectthefactoyhka.R;


public class Ventana_factura {

    private Dialog dialog;
    private EditText edi_descuento;
    private Button bt_aplicar_desc;

    public Ventana_factura(Context context) {

        configuracionDelaVentana(context);
        cast();

        dialog.show();

    }



    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {
        edi_descuento=dialog.findViewById(R.id.edi_descuento);
        bt_aplicar_desc=dialog.findViewById(R.id.bt_aplicar_desc);
    }

    //configuracion de la ventana para poder ser visualizada
    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_descuento);

    }


}
