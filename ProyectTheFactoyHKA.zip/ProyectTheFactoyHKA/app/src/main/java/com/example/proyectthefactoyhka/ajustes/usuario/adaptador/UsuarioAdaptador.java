package com.example.proyectthefactoyhka.ajustes.usuario.adaptador;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;

import java.util.List;


public class UsuarioAdaptador extends RecyclerView.Adapter<UsuarioAdaptador.MiViewHolder> {

    private List<ModelUsuario> usuarios;
    private int layout;


    public UsuarioAdaptador(List<ModelUsuario> usuarios, int layout) {
        this.usuarios = usuarios;
        this.layout = layout;

    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(usuarios.get(position));

    }

    @Override
    public int getItemCount() {
        return usuarios.size();
    }

    public class MiViewHolder extends RecyclerView.ViewHolder{

        private TextView item_usuario_texto;


        public MiViewHolder(View itemView) {
            super(itemView);

            item_usuario_texto = itemView.findViewById(R.id.item_usuario_texto);

        }

        public void bind(ModelUsuario usuario){
            item_usuario_texto.setText(usuario.getUsuario());


        }
    }




}


