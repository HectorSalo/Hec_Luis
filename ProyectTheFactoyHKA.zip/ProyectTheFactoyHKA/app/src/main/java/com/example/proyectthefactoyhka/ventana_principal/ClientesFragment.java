package com.example.proyectthefactoyhka.ventana_principal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.catalogo_cliente.activity.ClientesMain;
import com.example.proyectthefactoyhka.catalogo_cliente.adaptador.ClienteAdaptador;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion.Conexion_Cliente;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente.VentAddCliente;
import com.example.proyectthefactoyhka.catalogo_cliente.conexion_emergente.VentVerMasDetallesClient;
import com.example.proyectthefactoyhka.factura_notaCredito_notaDebito.factura.activity.Factura;
import com.example.proyectthefactoyhka.modelo.ModelCliente;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import java.util.Objects;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmList;


public class ClientesFragment extends Fragment implements Conexion_Cliente, RealmChangeListener<RealmList<ModelCliente>> {

    private OnFragmentInteractionListener mListener;

    private ProgressBar progressBar;
    private RecyclerView rvClientes;
    private TextView tvListaVacia;
    private int idUsuario;
    private Realm realm;
    private RealmList<ModelCliente> listacliente;
    private ClienteAdaptador clientesAdapter;
    private ModelUsuario usuarios;
    private final int CODIGO_PERMISO = 600;

    public ClientesFragment() {
        // Required empty public constructor
    }


    public static ClientesFragment newInstance(String param1, String param2) {
        ClientesFragment fragment = new ClientesFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_clientes, container, false);

        Bundle extra = getActivity().getIntent().getExtras();
        if (extra != null) {
            idUsuario = extra.getInt(getString(R.string.enviar_usuario));
        }

        rvClientes = view.findViewById(R.id.rv_cliente);
        progressBar = view.findViewById(R.id.progressBar_clientes);
        tvListaVacia = view.findViewById(R.id.tv_lista_vacia);

        FloatingActionButton fabAgregarCliente = view.findViewById(R.id.fab_agregar_cliente);
        fabAgregarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarCliente();
            }
        });

        baseDeDatos();
        funcionDelAdaptador(listacliente);
        verificarLista();

        return view;
    }


    private void baseDeDatos() {
        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();
        if (usuarios != null)
            listacliente = usuarios.getDatos_clientes();
        listacliente.addChangeListener(this);
    }


    private void verificarLista(){

        if (listacliente.size()==0){
            tvListaVacia.setVisibility(View.VISIBLE);
            rvClientes.setVisibility(View.GONE);
        }else {
            tvListaVacia.setVisibility(View.GONE);
            rvClientes.setVisibility(View.VISIBLE);
        }

    }


    private void funcionDelAdaptador(List<ModelCliente> cliente) {
        clientesAdapter = new ClienteAdaptador(cliente, R.layout.cardview_clientes, getActivity(), this);
        rvClientes.setHasFixedSize(true);
        rvClientes.setLayoutManager(new LinearLayoutManager(getContext()));
        rvClientes.setItemAnimator(new DefaultItemAnimator());
        rvClientes.setAdapter(clientesAdapter);
    }


    private void agregarCliente() {
        VentAddCliente ventanaDialogo = new VentAddCliente();
        Bundle datos = new Bundle();
        datos.putInt(getString(R.string.enviar_usuario), idUsuario);
        ventanaDialogo.setArguments(datos);
        ventanaDialogo.show(Objects.requireNonNull(getActivity()).getSupportFragmentManager(), "producto");
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onChange(RealmList<ModelCliente> modelClientes) {
        clientesAdapter.notifyDataSetChanged();
        verificarLista();
    }

    @Override
    public void generarFacturadeCliente(ModelCliente datoDelCliente) {
        Intent enviar = new Intent(getContext(), Factura.class);
        Bundle bundle = new Bundle();
        bundle.putInt(getString(R.string.enviar_usuario), idUsuario);
        bundle.putString("datoClien", datoDelCliente.getIdentificacion());
        bundle.putString("tipoDocumento","03");
        enviar.putExtras(bundle);
        startActivity(enviar);
    }

    @Override
    public void llamarVentanaEditarCliente(ModelCliente datoDelCliente) {
        VentAddCliente ventanaDialogo = new VentAddCliente();
        Bundle datosedi = new Bundle();
        datosedi.putInt(getString(R.string.enviar_usuario), idUsuario);
        datosedi.putString("ruc", datoDelCliente.getIdentificacion());
        ventanaDialogo.setArguments(datosedi);
        ventanaDialogo.show(Objects.requireNonNull(getActivity()).getSupportFragmentManager(), "editar");
    }

    @Override
    public void detallesDelCliente(ModelCliente datoDelCliente) {
        new VentVerMasDetallesClient(getContext(), datoDelCliente.getNombre(),
                datoDelCliente.getApellido(), datoDelCliente.getJurisdiccion(), datoDelCliente.getTelefono(),
                datoDelCliente.getIdentificacion(), datoDelCliente.getDatoVerificador(), datoDelCliente.getCorreo(),
                datoDelCliente.getCodigoPais(), datoDelCliente.getProvincia(), datoDelCliente.getDistrito(),
                datoDelCliente.getCorreginmiento(), datoDelCliente.getDireccion(), datoDelCliente.getJurisdiccion());
    }

    @Override
    public void borrarCliente(ModelCliente datoDelCliente) {
        realm.beginTransaction();
        datoDelCliente.deleteFromRealm();
        realm.commitTransaction();
    }


    public interface OnFragmentInteractionListener {

        void onFragmentInteraction(Uri uri);
    }
}
