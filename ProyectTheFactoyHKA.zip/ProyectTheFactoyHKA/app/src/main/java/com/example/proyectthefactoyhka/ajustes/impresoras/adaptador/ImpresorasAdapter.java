package com.example.proyectthefactoyhka.ajustes.impresoras.adaptador;

import android.app.Activity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.impresoras.comunicacion.Conexion_Impresora;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;
import java.util.List;


public class ImpresorasAdapter extends RecyclerView.Adapter<ImpresorasAdapter.MiViewHolder>  {

    private List<ModelImpresora> impresoras;
    private int layout;
    private Activity activity;
    private MyOnItemClick itemClick;
    private Conexion_Impresora conexion_impresora;

    public ImpresorasAdapter(List<ModelImpresora> impresoras, int layout, Activity activity,Conexion_Impresora conexion_impresora,MyOnItemClick itemClick) {
        this.impresoras = impresoras;
        this.layout = layout;
        this.activity = activity;
        this.conexion_impresora = conexion_impresora;
        this.itemClick = itemClick;
    }

    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(layout,parent,false);
        MiViewHolder vh = new MiViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MiViewHolder holder, int position) {
        holder.bind(impresoras.get(position),itemClick);

    }

    @Override
    public int getItemCount() { return impresoras.size(); }


    public class MiViewHolder extends RecyclerView.ViewHolder  implements View.OnClickListener {

        private TextView card_impr_tv_titulo;
        private Switch card_impr_activar_impr;


        public MiViewHolder(View itemView) {
            super(itemView);

            card_impr_tv_titulo = itemView.findViewById(R.id.card_impr_tv_titulo);

            card_impr_activar_impr = itemView.findViewById(R.id.card_impr_activar_impr);
            card_impr_activar_impr.setOnClickListener(this);


        }

        public void bind(final ModelImpresora impresoras, final MyOnItemClick itemClick){
            card_impr_tv_titulo.setText(impresoras.getNombre());
            card_impr_activar_impr.setChecked(impresoras.isEstado());

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {

                    itemClick.onItem(impresoras,getAdapterPosition());
                    return true;
                }





            });

        }


        @Override
        public void onClick(View v) {

            switch (v.getId()){

                case R.id.card_impr_activar_impr:

                    if (card_impr_activar_impr.isChecked()){

                        conexion_impresora.activar_impresora(true,getAdapterPosition());

                    }else {

                        conexion_impresora.activar_impresora(false,getAdapterPosition());

                    }

                    break;

            }

        }
    }

    public interface MyOnItemClick{
        void onItem(ModelImpresora impresoras, int position);
    }

}
