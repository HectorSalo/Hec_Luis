package com.example.proyectthefactoyhka.modelo.modelos_APP;

import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelDocumento;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

public class ModelListaDeDocumentos {

    private String codigo;
    private List<ModelDocumento> documento;
    private String mensaje;
    private boolean procesado;
    private String tipoDocumento;

    public ModelListaDeDocumentos(String codigo, List<ModelDocumento> documento, String mensaje, boolean procesado, String tipoDocumento) {
        this.codigo = codigo;
        this.documento = documento;
        this.mensaje = mensaje;
        this.procesado = procesado;
        this.tipoDocumento = tipoDocumento;
    }

    public String getId() {
        return codigo;
    }

    public void setId(String id) {
        this.codigo = id;
    }

    public List<ModelDocumento> getDocumento() {
        return documento;
    }

    public void setDocumento(List<ModelDocumento> documento) {
        this.documento = documento;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public boolean isProcesado() {
        return procesado;
    }

    public void setProcesado(boolean procesado) {
        this.procesado = procesado;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public static ModelDocumento documento (String response){
        Gson gson = new GsonBuilder().create();
        ModelDocumento documento = gson.fromJson(response,ModelDocumento.class);
        return documento;

    }


}
