package com.example.proyectthefactoyhka.ajustes.impresoras.ventana_emergente;

import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.ajustes.impresoras.comunicacion.Conexion_Impresora;
import com.example.proyectthefactoyhka.modelo.ModelImpresora;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import io.realm.Realm;
import io.realm.RealmResults;

public class VentAddImpresora implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    private Dialog dialog;
    private RealmResults<ModelImpresora> impresoras;
    private TextView tv_imprimir_direccion, edi_imprimir_direccion;
    private EditText edi_imprimir_nombre;
    private Conexion_Impresora conexion_impresora;
    private Spinner sp_imprimir_interface, sp_imprimir_nombre, sp_imprimir_ancho_papel, sp_imprimir_caracter_linea, sp_imprimir_cod_pagina, sp_imprimir_tipo_de_QR;
    private String imprimir_interface, imprimir_nombre, imprimir_ancho_papel, imprimir_caracter_linea, imprimir_cod_pagina, imprimir_tipo_de_QR;

    private Set<BluetoothDevice> btDevices;
    private BluetoothAdapter mBluetoothAdapter;
    private List<String> btDevicesNames;
    private List<String> btDevicesAddresses;


    public VentAddImpresora(final Context context, Conexion_Impresora conexion_impresora) {
        this.conexion_impresora = conexion_impresora;

        configuracionDelaVentana(context);
        cast();
        baseDeDatos();
        implementarSpiner();
        implementacionBluetooth();
        implementarSpinerBluetooth(R.layout.support_simple_spinner_dropdown_item, btDevicesNames);

        dialog.show();


    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btn_ok:

                if (tieneCamposVacios()) {

                    mostrarToast(R.string.validar_campos);

                } else {

                    if (verificaSiElCodigoExiste()) {
                        mostrarToast(R.string.validarImpresora);
                    } else {

                        if (imprimir_interface.equals("Bluetooth")) {
                            conexion_impresora.crear_impresora(imprimir_interface, imprimir_nombre, tv_imprimir_direccion.getText().toString(), imprimir_ancho_papel, imprimir_caracter_linea, "", imprimir_cod_pagina, imprimir_tipo_de_QR, "");

                        } else {
                            conexion_impresora.crear_impresora(imprimir_interface, edi_imprimir_nombre.getText().toString(), edi_imprimir_direccion.getText().toString(), imprimir_ancho_papel, imprimir_caracter_linea, "", imprimir_cod_pagina, imprimir_tipo_de_QR, "");
                        }
                        dialog.dismiss();
                    }

                }
                break;

            case R.id.btn_cancel:

                dialog.dismiss();

                break;
        }

    }


    //metodo que obtiene el dato que esta seleccionado en los spinner y los envia a una variable
    //global String
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()) {

            case R.id.sp_imprimir_interface:

                imprimir_interface = parent.getItemAtPosition(position).toString();

                if (imprimir_interface.equals("Bluetooth")) {


                    if (btDevicesAddresses.size() > 0) {
                        tv_imprimir_direccion.setText(btDevicesAddresses.get(position));
                    }

                    sp_imprimir_nombre.setVisibility(View.VISIBLE);
                    tv_imprimir_direccion.setVisibility(View.VISIBLE);

                    edi_imprimir_nombre.setVisibility(View.GONE);
                    edi_imprimir_direccion.setVisibility(View.GONE);

                } else {
                    sp_imprimir_nombre.setVisibility(View.GONE);
                    tv_imprimir_direccion.setVisibility(View.GONE);

                    edi_imprimir_nombre.setVisibility(View.VISIBLE);
                    edi_imprimir_direccion.setVisibility(View.VISIBLE);
                }

                break;

            case R.id.sp_imprimir_nombre:

                imprimir_nombre = parent.getItemAtPosition(position).toString();

                break;

            case R.id.sp_imprimir_ancho_papel:

                imprimir_ancho_papel = parent.getItemAtPosition(position).toString();

                break;

            case R.id.sp_imprimir_caracter_linea:

                imprimir_caracter_linea = parent.getItemAtPosition(position).toString();

                break;

            case R.id.sp_imprimir_cod_pagina:

                imprimir_cod_pagina = parent.getItemAtPosition(position).toString();

                break;

            case R.id.sp_imprimir_tipo_de_QR:

                imprimir_tipo_de_QR = parent.getItemAtPosition(position).toString();

                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    private void implementarSpinerBluetooth(int tipoSpiner, List<String> dato) {

        ArrayAdapter<String> stringArrayAdapter = new ArrayAdapter<>(dialog.getContext(), tipoSpiner, dato);
        sp_imprimir_nombre.setAdapter(stringArrayAdapter);
    }

    private void implementacionBluetooth() {

        BtService btService = new BtService();

        btDevices = btService.listPairedBtDevices(dialog.getContext(), mBluetoothAdapter);

        btDevicesNames = new ArrayList<>();
        btDevicesAddresses = new ArrayList<>();

        if (btDevices.size() > 0) {
            for (BluetoothDevice bluetoothDevice : btDevices) {
                btDevicesNames.add(bluetoothDevice.getName());
                btDevicesAddresses.add(bluetoothDevice.getAddress());
            }
        }
    }


    //metodo principal utilizado para verificar si algun campo esta vacio al presionar el boton registrar
    private boolean tieneCamposVacios() {
        return edi_imprimir_nombre.getText().toString().isEmpty() && imprimir_interface.equals("Ethernet") ||
                edi_imprimir_direccion.getText().toString().isEmpty() && imprimir_interface.equals("Ethernet") ||
                tv_imprimir_direccion.getText().toString().isEmpty() && imprimir_interface.equals("Bluetooth");
    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {
        Realm realm = Realm.getDefaultInstance();
        impresoras = realm.where(ModelImpresora.class).findAll();
    }


    //metodo para verificar si el nombre de la impresora esta en existencia en la base de datos

    private boolean verificaSiElCodigoExiste() {

        for (int i = 0; i < impresoras.size(); ) {

            ModelImpresora verificar = impresoras.get(i);

            if (verificar != null) {

                if (!imprimir_nombre.equals(verificar.getNombre()) && imprimir_interface.equals("Bluetooth") ||
                        !edi_imprimir_nombre.getText().toString().equals(verificar.getNombre()) && imprimir_interface.equals("Ethernet")) {
                    i++;
                } else {
                    return true;
                }
            }
        }

        return false;

    }


    //metodo para rellenar los spinner la opcion 1 sera de donde vendra los datos del spinner
    // la opcion 2 sera en donde seran ubicados
    private void implementarSpiner() {

        adapterDelosSpiner(R.array.printerinterface, sp_imprimir_interface);
        adapterDelosSpiner(R.array.printerpapersize, sp_imprimir_ancho_papel);
        adapterDelosSpiner(R.array.printercharsperline, sp_imprimir_caracter_linea);
        adapterDelosSpiner(R.array.printercodepage, sp_imprimir_cod_pagina);
        adapterDelosSpiner(R.array.printerqrtype, sp_imprimir_tipo_de_QR);

    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        sp_imprimir_nombre = dialog.findViewById(R.id.sp_imprimir_nombre);
        sp_imprimir_nombre.setOnItemSelectedListener(this);

        edi_imprimir_nombre = dialog.findViewById(R.id.edi_imprimir_nombre);

        tv_imprimir_direccion = dialog.findViewById(R.id.tv_imprimir_direccion);

        edi_imprimir_direccion = dialog.findViewById(R.id.edi_imprimir_direccion);

        sp_imprimir_interface = dialog.findViewById(R.id.sp_imprimir_interface);
        sp_imprimir_interface.setOnItemSelectedListener(this);

        sp_imprimir_ancho_papel = dialog.findViewById(R.id.sp_imprimir_ancho_papel);
        sp_imprimir_ancho_papel.setOnItemSelectedListener(this);

        sp_imprimir_caracter_linea = dialog.findViewById(R.id.sp_imprimir_caracter_linea);
        sp_imprimir_caracter_linea.setOnItemSelectedListener(this);

        sp_imprimir_cod_pagina = dialog.findViewById(R.id.sp_imprimir_cod_pagina);
        sp_imprimir_cod_pagina.setOnItemSelectedListener(this);

        sp_imprimir_tipo_de_QR = dialog.findViewById(R.id.sp_imprimir_tipo_de_QR);
        sp_imprimir_tipo_de_QR.setOnItemSelectedListener(this);

        Button btn_ok = dialog.findViewById(R.id.btn_ok);
        btn_ok.setOnClickListener(this);

        Button btn_cancel = dialog.findViewById(R.id.btn_cancel);
        btn_cancel.setOnClickListener(this);
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(dialog.getContext(), mensaje, Toast.LENGTH_SHORT).show();
    }


    //metodo singleton para los spinner
    private void adapterDelosSpiner(int array, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (dialog.getContext(), array, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
    }


    //configuracion de la ventana para poder ser visualizada
    private void configuracionDelaVentana(Context context) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.setContentView(R.layout.ventana_agregar_impresora);
    }

}
