package com.example.proyectthefactoyhka.herramienta;

public interface Conexion_calendario {
    void datosDelCalendario(String dia, String mes, String year);

}
