package com.example.proyectthefactoyhka.login;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import androidx.annotation.NonNull;

import com.example.proyectthefactoyhka.ventana_principal.TestVariablesGenerales;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.configuracion_realm_dataBase.RealmImporter;
import com.example.proyectthefactoyhka.herramienta.AjustesDeConexion;
import com.example.proyectthefactoyhka.herramienta.ArrayGeneralApp;
import com.example.proyectthefactoyhka.herramienta.ConexionInternet;
import com.example.proyectthefactoyhka.modelo.ModelUnidad;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelAutentificar;
import com.example.proyectthefactoyhka.modelo.eviarDatos.ModelPeticionDeEmisor;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelIdRuc;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelMunicipios;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerEmisor;
import com.example.proyectthefactoyhka.modelo.recibirDatos.ModelObtenerToken;
import com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales;
import com.example.proyectthefactoyhka.retrofic.MyApi;
import com.example.proyectthefactoyhka.retrofic.WebServiceApi;
import com.example.proyectthefactoyhka.ventana_principal.PrincipalActivity;

import java.io.File;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.Manifest.permission.INTERNET;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static com.example.proyectthefactoyhka.herramienta.AjustesDeConexion.IS_NETWORK_AVAILABLE;
import static com.example.proyectthefactoyhka.persistencia_de_datos.DatosTemporales.SHARED_PREFERENCES;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //  private Spinner spinner_login_usuario;
    private final int CODIGO_PERMISO = 100;


    public static final String PREFERENCE_DIR_JSON = "dir_json";
    public static final String PREFERENCE_DIR_XML = "dir_xml";
    public static final String PREFERENCE_DIR_CONT = "dir_cont";
    public static final String PREFERENCE_DIR_PDF = "dir_pdf";

    private RealmResults<ModelIdRuc> listaDeRuc;
    private RealmList<ModelUsuario> listaDeUsuario;
    private ProgressBar progressBar;
    private Button bt_login_ingresar, bt_login_registrar;
    private DatosTemporales datosTemporales;
    private Realm realm;

    private EditText edi_login_usu;
    private EditText edi_login_pass;
    private EditText edi_login_ruc;

    private ModelIdRuc modelIdRuc;
    private ModelUsuario modelUsuario;


    private ModelObtenerToken token = new ModelObtenerToken();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        cast();
        baseDeDatos();
        permisos();

        datosTemporales = DatosTemporales.getIntance(getSharedPreferences(SHARED_PREFERENCES, MODE_PRIVATE));
        conexionDeRed();
        serial();


        int people = realm.where(ModelMunicipios.class).findAll().size();
        if (people== 0) {
            RealmImporter.importFromJson(getResources());
        }


    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.bt_login_ingresar: {
                if (!ConexionInternet.checkConnection(getApplicationContext())) {

                    Snackbar.make(findViewById(R.id.login_layout), "No tiene conexion ", Snackbar.LENGTH_INDEFINITE).show();
                } else {

                    ModelAutentificar aut = new ModelAutentificar(edi_login_pass.getText().toString(), edi_login_ruc.getText().toString(), "M", edi_login_usu.getText().toString());

                    servicioRetrofit2(aut);
                }

            }

            break;

            case R.id.bt_login_registrar:

                permisos();

                break;
        }

    }

    private void esperaDeDatos() {

        if (progressBar.getVisibility() == View.GONE) {
            progressBar.setVisibility(View.VISIBLE);

            edi_login_usu.setEnabled(false);
            edi_login_pass.setEnabled(false);
            edi_login_ruc.setEnabled(false);

            bt_login_ingresar.setEnabled(false);
            bt_login_registrar.setEnabled(false);
        } else {

            progressBar.setVisibility(View.GONE);

            edi_login_usu.setEnabled(true);
            edi_login_pass.setEnabled(true);
            edi_login_ruc.setEnabled(true);

            bt_login_ingresar.setEnabled(true);
            bt_login_registrar.setEnabled(true);

        }

    }


    private void enviarDatos(ModelUsuario usuario) {


        //iniciamos las preferencias de almacenamiento de archivos
        iniciarCarpetas(usuario);

        TestVariablesGenerales.idUsuario = usuario.getId();
        Intent enviar = new Intent(this, PrincipalActivity.class);
        enviar.putExtra(getString(R.string.enviar_usuario), usuario.getId());
        startActivity(enviar);
        esperaDeDatos();
    }


    private void servicioRetrofit2(final ModelAutentificar autentificar) {

        esperaDeDatos();

        WebServiceApi service = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelObtenerToken> obtenerToken = service.hacerLlamada(autentificar);
        obtenerToken.enqueue(new Callback<ModelObtenerToken>() {

            @Override
            public void onResponse(Call<ModelObtenerToken> call, Response<ModelObtenerToken> response) {
                token = response.body();
                if (token.getToken() != null) {

                    datosTemporales.guardarToken(token);

                    //------------------------------------------------------------------------------------------------------------------------------------------------
                    //todo: estos datos seran removidos en un futuro

                    modelUsuario = new ModelUsuario(autentificar.getUsuario(), autentificar.getClave(), "Desconocido", insercionDeunidades());
                    modelIdRuc = new ModelIdRuc(autentificar.getRuc(), new RealmList<ModelUsuario>(modelUsuario));
                    RealmQuery<ModelIdRuc> existenciaDelRuc = listaDeRuc.where().equalTo("ruc", autentificar.getRuc());


                    datosTemporales.guardarRuc(autentificar.getRuc());
                    datosTemporales.guardarUsuario(new ModelUsuario(autentificar.getUsuario(), autentificar.getClave()));

                    if (ElRucExiste(autentificar.getRuc())) {

                        listaDeUsuario = existenciaDelRuc.findFirst().getListaUsuarios();

                        if (ElUsusarioExiste(autentificar.getUsuario())) {

                            ModelUsuario existenciaDelUsuario = listaDeUsuario.where().equalTo(getString(R.string.enviar_usuario), autentificar.getUsuario()).findFirst();
                            if (existenciaDelUsuario != null)
                                enviarDatos(existenciaDelUsuario);


                        } else {


                            realm.beginTransaction();
                            listaDeUsuario.add(modelUsuario);
                            realm.commitTransaction();
                            enviarDatos(modelUsuario);
                        }

                    } else {

                        realm.beginTransaction();
                        realm.copyToRealmOrUpdate(modelIdRuc);
                        realm.commitTransaction();
                        enviarDatos(modelUsuario);

                    }


                    //------------------------------------------------------------------------------------------------------------------------------------------------

                    obtenerDatosEmisor(token.getToken());

                } else {

                    Toast.makeText(MainActivity.this, token.getMensaje(), Toast.LENGTH_SHORT).show();
                    esperaDeDatos();
                }
            }

            @Override
            public void onFailure(Call<ModelObtenerToken> call, Throwable t) {

                esperaDeDatos();
                mostrarToast(R.string.fallo_retroit);
            }
        });
    }


    private void obtenerDatosEmisor(String token) {

        ModelPeticionDeEmisor datosEmisor = new ModelPeticionDeEmisor(modelIdRuc.getRuc(), token, modelUsuario.getSerial());

        WebServiceApi service2 = MyApi.getInstacia().crearServicio(WebServiceApi.class);
        Call<ModelObtenerEmisor> infoEmisor = service2.peticionDeEmisor(datosEmisor);
        infoEmisor.enqueue(new Callback<ModelObtenerEmisor>() {

            ModelObtenerEmisor emisor = new ModelObtenerEmisor();

            @Override
            public void onResponse(Call<ModelObtenerEmisor> call, Response<ModelObtenerEmisor> response) {

                emisor = response.body();
                datosTemporales.guardarEmisor(emisor.getModelInfoEmisor());
            }

            @Override
            public void onFailure(Call<ModelObtenerEmisor> call, Throwable t) {

            }
        });

    }


    private void conexionDeRed() {

        IntentFilter intentFilter = new IntentFilter(AjustesDeConexion.NETWORK_AVAILABLE_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                boolean isNetworkAvailable = intent.getBooleanExtra(IS_NETWORK_AVAILABLE, false);
                String networkStatus = isNetworkAvailable ? "conectado" : "Por favor conectar a la red";

                if (networkStatus.equals("Por favor conectar a la red")) {
                    Snackbar.make(findViewById(R.id.login_layout), networkStatus, Snackbar.LENGTH_INDEFINITE).show();
                    bt_login_ingresar.setEnabled(false);

                } else {

                    Snackbar.make(findViewById(R.id.login_layout), networkStatus, Snackbar.LENGTH_LONG).show();
                    bt_login_ingresar.setEnabled(true);
                }

            }
        }, intentFilter);
    }


    //variables utilizada para obtener acesso a la base de datos Realm ubicada en la caperta
    //configuracion_realm_dataBase y luego buscar los campos dependiendo el modelo
    private void baseDeDatos() {

        realm = Realm.getDefaultInstance();
        listaDeRuc = realm.where(ModelIdRuc.class).findAll();
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        //spinner_login_usuario = findViewById(R.id.spinner_login_usuario);


        //----------------------------------------------------

        edi_login_usu = findViewById(R.id.edi_login_usu);
        edi_login_pass = findViewById(R.id.edi_login_pass);
        edi_login_ruc = findViewById(R.id.edi_login_ruc);

        //todo: eliminar
        edi_login_usu.setText("20123889610_M");
        edi_login_pass.setText("ph0n13x");
        edi_login_ruc.setText("20123889610");

        //----------------------------------------------------

        progressBar = findViewById(R.id.login_progressBar);
        progressBar.setVisibility(View.GONE);

        bt_login_ingresar = findViewById(R.id.bt_login_ingresar);
        bt_login_ingresar.setOnClickListener(this);

        bt_login_registrar = findViewById(R.id.bt_login_registrar);
        bt_login_registrar.setOnClickListener(this);
    }


    private void permisos() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso(INTERNET) && chequearPermiso(READ_PHONE_STATE) && chequearPermiso(WRITE_EXTERNAL_STORAGE)) {
                //ha aceptado
                //startActivity(new Intent(this, Registrar.class));

            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(INTERNET) || !shouldShowRequestPermissionRationale(READ_PHONE_STATE) || !shouldShowRequestPermissionRationale(WRITE_EXTERNAL_STORAGE)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{INTERNET, READ_PHONE_STATE, WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                } else {
                    // ha rechazado
                    requestPermissions(new String[]{INTERNET, READ_PHONE_STATE, WRITE_EXTERNAL_STORAGE}, CODIGO_PERMISO);
                }
            }
        } else {
            viejaVersion();
        }
    }


// este metodo sera llamado por el metodo permisos si la version es menor a la version 25

    private void viejaVersion() {

        if (chequearPermiso(INTERNET) && chequearPermiso(READ_PHONE_STATE)&& chequearPermiso(WRITE_EXTERNAL_STORAGE)) {
//            startActivity(new Intent(this, Registrar.class));
        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso(String permiso) {

        int result = this.checkCallingOrSelfPermission(permiso);
        return result == PackageManager.PERMISSION_GRANTED;
    }


    //este metodo sera llamado  si la version es mayor a la 25 es un metodo para identificar que tipo
    // de permiso esta pidiendo en tiempo de ejecucion la app y asi ejecutar la peticion a travez de
    // un codigo ya declarado de manera global

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        if (requestCode == CODIGO_PERMISO) {
            if (grantResults.length > 0) {

                String permission = permissions[0];
                int result = grantResults[0];

                if (permission.equals(INTERNET)) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(this, INTERNET) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso(INTERNET);
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }


                String permission2 = permissions[1];
                int result2 = grantResults[1];

                if (permission2.equals(READ_PHONE_STATE)) {
                    if (result2 == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(this, READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso(READ_PHONE_STATE);
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }


                String permission3 = permissions[2];
                int result3 = grantResults[2];

                if (permission3.equals(WRITE_EXTERNAL_STORAGE)) {
                    if (result3 == PackageManager.PERMISSION_GRANTED) {
                        if (ActivityCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            chequearPermiso(WRITE_EXTERNAL_STORAGE);
                        }

                    } else {
                        mostrarToast(R.string.login_validar_permiso_denegado);
                    }
                }


            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {

        Toast.makeText(MainActivity.this, mensaje, Toast.LENGTH_SHORT).show();
    }

    //metodo para obtener las unidades y registrarla en la base de datos
    private RealmList<ModelUnidad> insercionDeunidades() {

        RealmList<ModelUnidad> listaunidades = new RealmList<>();

        listaunidades.addAll(ArrayGeneralApp.todasLasUnidades());

        return listaunidades;
    }


    private boolean ElRucExiste(String numeroDeRuc) {

        for (int i = 0; i < listaDeRuc.size(); ) {

            ModelIdRuc verificar = listaDeRuc.get(i);

            if (verificar != null) {

                if (!numeroDeRuc.equals(verificar.getRuc())) {
                    i++;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean ElUsusarioExiste(String nombreUsuario) {

        for (int i = 0; i < listaDeUsuario.size(); ) {

            ModelUsuario verificar = listaDeUsuario.get(i);

            if (verificar != null) {

                if (!nombreUsuario.equals(verificar.getUsuario())) {
                    i++;
                } else {
                    return true;
                }
            }
        }
        return false;
    }


    private void serial() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            datosTemporales.guardarSerial(Build.getSerial());
        } else {
            datosTemporales.guardarSerial(Build.SERIAL);
        }
    }


    private void iniciarCarpetas(ModelUsuario usuario) {

        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        //Verificamos si existe el directorio raiz de la aplicación y si no lo creamos
        File f = new File(Environment.getExternalStorageDirectory(), "AppFel");
        if (!f.exists()) {
            f.mkdirs();
        }
        //Verificamos si existe el directorio correspondiente al pais de la aplicación y si no lo creamos
        File fCountry = new File(f.getPath(), "PE");
        if (!fCountry.exists()) {
            fCountry.mkdirs();
        }

        //Verificamos si existe el directorio correspondiente al usuario y si no lo creamos
        File fUser = new File(fCountry.getPath(), usuario.getUsuario());
        if (!fUser.exists()) {
            fUser.mkdirs();
        }

        //Verificamos si existe el directorio correspondiente al almacenamiento de los archivos JSON y si no lo creamos
        File fjson = new File(fUser.getPath(), "json");
        if (!fjson.exists()) {
            fjson.mkdirs();
        }

        //Verificamos si existe el directorio correspondiente al almacenamiento de los archivos XML y si no lo creamos
        File fxml = new File(fUser.getPath(), "xml");
        if (!fxml.exists()) {
            fxml.mkdirs();
        }

        //Verificamos si existe el directorio correspondiente al almacenamiento de los archivos XML contenedores de la Factura electrónica y si no lo creamos
        File fcont = new File(fUser.getPath(), "cont");
        if (!fcont.exists()) {
            fcont.mkdirs();
        }

        //Verificamos si existe el directorio correspondiente al almacenamiento de los archivos PDF y si no lo creamos
        File fpdf = new File(fUser.getPath(), "pdf");
        if (!fpdf.exists()) {
            fpdf.mkdirs();
        }
        editor.putString(PREFERENCE_DIR_JSON, fjson.getPath());
        editor.putString(PREFERENCE_DIR_XML, fxml.getPath());
        editor.putString(PREFERENCE_DIR_CONT, fcont.getPath());
        editor.putString(PREFERENCE_DIR_PDF, fpdf.getPath());
        editor.commit();

    }


}
