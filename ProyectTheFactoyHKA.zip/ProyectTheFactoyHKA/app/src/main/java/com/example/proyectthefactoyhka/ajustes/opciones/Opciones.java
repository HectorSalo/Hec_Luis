package com.example.proyectthefactoyhka.ajustes.opciones;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.example.proyectthefactoyhka.R;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelOpciones;
import com.example.proyectthefactoyhka.modelo.modelos_APP.ModelUsuario;
import java.util.Locale;
import io.realm.Realm;
import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class Opciones extends AppCompatActivity implements View.OnClickListener ,LocationListener,AdapterView.OnItemSelectedListener{

    private ArrayAdapter<CharSequence> adapter;
    private Realm realm;
    private ModelUsuario usuarios;

    private ModelOpciones modelOpciones;
    private Spinner spinner_opc_tipoDispositivo;
    private SwitchCompat switch_opc_enviar_correo;
    private TextView spinnercust_sucursal1;
    private EditText edi_opc_boleta,edi_opc_factura,edi_opc_nota_cre, edi_opc_nota_deb,edi_geolocation;
    private String tipoDispositivo;
    private ImageButton bt_localizacion;
    private final int CODIGO_PERMISO = 309;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opciones);


        mostrarToolbar();
        recibirDatosDeOtrosActivitys();
        cast();
        implementarSpiner();



    }


    private void recibirDatosDeOtrosActivitys() {
        Bundle extra = getIntent().getExtras();
        if (extra != null) {
            int idUsuario = extra.getInt(getString(R.string.enviar_usuario));

            baseDeDatos(idUsuario);


        }

    }
        private void baseDeDatos(int idUsuario) {

        realm = Realm.getDefaultInstance();
        usuarios = realm.where(ModelUsuario.class).equalTo("id", idUsuario).findFirst();

        if (usuarios != null)
        modelOpciones = usuarios.getOpciones();
    }


    //metodo onClick en el cual asignaremos una accion a cada boton correspondiente
    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case  R.id.bt_localizacion:

                permisos();

                break;

            case  R.id.bt_guardar_opciones:


                    realm.beginTransaction();
                    modelOpciones.setTipo_de_dispositivo(tipoDispositivo);
                    if (switch_opc_enviar_correo.isChecked()){ modelOpciones.setEnviar_correo(true);
                    }else { modelOpciones.setEnviar_correo(false); }

                    modelOpciones.setCodigo_boleta_de_venta(edi_opc_boleta.getText().toString());
                    modelOpciones.setCodigo_facturas(edi_opc_factura.getText().toString());
                    modelOpciones.setCodigo_nota_credito(edi_opc_nota_cre.getText().toString());
                    modelOpciones.setCodigo_nota_debito(edi_opc_nota_deb.getText().toString());
                    realm.commitTransaction();
                    mostrarToast(R.string.titulo_bt_guardar_cambios);

                    finish();

                break;

        }

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (parent.getId()){

            case R.id.spinner_opc_tipoDispositivo:

                tipoDispositivo = parent.getItemAtPosition(position).toString();

                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    //metodo para rellenar los spinner la opcion 1 sera de donde vendra los datos del spinner
    // la opcion 2 sera en donde seran ubicados
    private void implementarSpiner() {
        adapterDelosSpiner(R.array.dispositivos, spinner_opc_tipoDispositivo);

    }

    private void permisos() {

        //comprobar la version actual
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            //Comprobar si ha aceptado , no ha aceptado , o nunca se le ha preguntado
            if (chequearPermiso(WRITE_EXTERNAL_STORAGE)&&chequearPermiso(ACCESS_COARSE_LOCATION)&&chequearPermiso(ACCESS_FINE_LOCATION)) {
                //ha aceptado

                //llama a la accion del gps en nuevas versiones
                gps();


            } else {
                //no ha aceptado , o es la primera vez que se le pregunta
                if (!shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)&&!shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION)&&!shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    // no se le ha preguntado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE,ACCESS_COARSE_LOCATION,ACCESS_FINE_LOCATION}, CODIGO_PERMISO);
                } else {
                    // a rechazado
                    requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE,ACCESS_COARSE_LOCATION,ACCESS_FINE_LOCATION}, CODIGO_PERMISO);
                }
            }

        } else {
            viejaVersion();
        }
    }


// este metodo sera llamado por el metodo permisos si la version es menor a la version 25

    private void viejaVersion() {

        if (chequearPermiso(WRITE_EXTERNAL_STORAGE)&&chequearPermiso(ACCESS_COARSE_LOCATION)&&chequearPermiso(ACCESS_FINE_LOCATION)) {

            //llama a la accion del gps en versiones antiguas
            gps();

        } else {
            mostrarToast(R.string.login_validar_permiso_denegado);
        }
    }


    //metodo que comprueba que el usuario haya aceptado el permiso
    private boolean chequearPermiso(String permiso) {

        int result = this.checkCallingOrSelfPermission(permiso);
        return result == PackageManager.PERMISSION_GRANTED;

    }


    //este metodo sera llamado  si la version es mayor a la 25 es un metodo para identificar que tipo
    // de permiso esta pidiendo en tiempo de ejecucion la app y asi ejecutar la peticion a travez de
    // un codigo ya declarado de manera global

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {


        switch (requestCode) {
            case CODIGO_PERMISO:

                if (grantResults.length > 0) {

                    String permission = permissions[0];
                    int result = grantResults[0];

                    if (permission.equals(WRITE_EXTERNAL_STORAGE)) {
                        if (result == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso(WRITE_EXTERNAL_STORAGE);
                            }

                        } else {
                            mostrarToast(R.string.login_validar_permiso_denegado);
                        }
                    }

                    String permission2 = permissions[1];
                    int result2 = grantResults[1];

                    if (permission2.equals(ACCESS_COARSE_LOCATION)) {
                        if (result2 == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso(ACCESS_COARSE_LOCATION);
                            }

                        } else {
                            mostrarToast(R.string.login_validar_permiso_denegado);
                        }
                    }

                    String permission3 = permissions[2];
                    int result3 = grantResults[2];

                    if (permission3.equals(ACCESS_FINE_LOCATION)) {
                        if (result3 == PackageManager.PERMISSION_GRANTED) {
                            if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                return;
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                chequearPermiso(ACCESS_FINE_LOCATION);
                            }

                        } else {
                            mostrarToast(R.string.login_validar_permiso_denegado);
                        }
                    }
                }
                break;

            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                break;
        }
    }


    //metodo donde se castea todos los elementos que tendran interacion con el usuario
    private void cast() {

        spinner_opc_tipoDispositivo=findViewById(R.id.spinner_opc_tipoDispositivo);
        spinner_opc_tipoDispositivo.setOnItemSelectedListener(this);

        switch_opc_enviar_correo=findViewById(R.id.switch_opc_enviar_correo);
        spinnercust_sucursal1=findViewById(R.id.spinnercust_sucursal1);
        edi_opc_boleta=findViewById(R.id.edi_opc_boleta);
        edi_opc_factura=findViewById(R.id.edi_opc_factura);
        edi_opc_nota_cre=findViewById(R.id.edi_opc_nota_cre);

        edi_opc_nota_deb=findViewById(R.id.edi_opc_nota_deb);
        edi_geolocation=findViewById(R.id.edi_geolocation);

        bt_localizacion=findViewById(R.id.bt_localizacion);
        bt_localizacion.setOnClickListener(this);

        Button bt_guardar_opciones=findViewById(R.id.bt_guardar_opciones);
        bt_guardar_opciones.setOnClickListener(this);


        if (modelOpciones.getCodigo_boleta_de_venta()!=null) { edi_opc_boleta.setText(modelOpciones.getCodigo_boleta_de_venta()); }

        if (modelOpciones.getCodigo_facturas()!=null) { edi_opc_factura.setText(modelOpciones.getCodigo_facturas()); }

        if (modelOpciones.getCodigo_nota_credito()!=null) { edi_opc_nota_cre.setText(modelOpciones.getCodigo_nota_credito()); }

        if (modelOpciones.getCodigo_nota_debito()!=null) { edi_opc_nota_deb.setText(modelOpciones.getCodigo_nota_debito()); }

        switch_opc_enviar_correo.setChecked(modelOpciones.isEnviar_correo());

    }





    private void adapterDelosSpiner(int array, Spinner spinner) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource
                (this, array, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
    }



    private void gps(){

        //aqui obtiene informacion del gps del dispositivo
        LocationManager lm = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);



        if (lm!=null) {

            //verifica si la accion de GPS se encuentra activo
            boolean isGPSEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            if (isGPSEnabled) {


                LocationManager locationManager = (LocationManager) Opciones.this.getSystemService(LOCATION_SERVICE);


                int permissionCheck = ContextCompat.checkSelfPermission(Opciones.this,
                        Manifest.permission.ACCESS_FINE_LOCATION);

                if (locationManager!=null)
                    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);

            } else {

                mostrarToast(R.string.validar_gps);
            }
        }



    }



    @Override
    public void onLocationChanged(Location location) {
        edi_geolocation.setText(String.format(Locale.US,"%s%.4f,%.4f",location.getLatitude()>0?"+":"",location.getLatitude(),location.getLongitude()));
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }




    // metodo singleton para reutilizar el toast
    private void mostrarToast(int mensaje) {
        Toast.makeText(Opciones.this, mensaje, Toast.LENGTH_SHORT).show();
    }


    //metodo que  configura el toolbar
    private void mostrarToolbar(){
        Toolbar toolbar= findViewById(R.id.toolbar_opciones);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Opciones.this.setTitle(R.string.toolbar_opciones);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
