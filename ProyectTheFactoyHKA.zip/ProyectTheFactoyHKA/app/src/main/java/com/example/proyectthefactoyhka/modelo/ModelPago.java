package com.example.proyectthefactoyhka.modelo;

public class ModelPago {

    private String metodoPago;
    private String moneda;

    public ModelPago(String metodoPago, String moneda) {
        this.metodoPago = metodoPago;
        this.moneda = moneda;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }
}
